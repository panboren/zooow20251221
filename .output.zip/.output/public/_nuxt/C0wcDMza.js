import{a$ as y,a9 as g,D as x,C as a,b as C,A,B,c as E,P,d as U,g as M}from"./Di3biKPp.js";function z(r,T={}){const{waveSize:l=100,waveSegments:h=256,auroraBandCount:S=8}=T,f=new y(l,l,h,h);f.rotateX(-Math.PI/2);const m=new g({uniforms:{uTime:{value:0},uDeepColor:{value:new a(6707)},uSurfaceColor:{value:new a(26316)},uFoamColor:{value:new a(16777215)}},vertexShader:`
      uniform float uTime;
      varying vec2 vUv;
      varying float vElevation;
      
      void main() {
        vUv = uv;
        vec3 pos = position;
        
        // 多层波浪
        float wave1 = sin(pos.x * 0.1 + uTime * 1.0) * 2.0;
        float wave2 = sin(pos.z * 0.15 + uTime * 1.2) * 1.5;
        float wave3 = sin((pos.x + pos.z) * 0.05 + uTime * 0.8) * 3.0;
        
        pos.y += wave1 + wave2 + wave3;
        vElevation = (wave1 + wave2 + wave3) / 6.5;
        
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform vec3 uDeepColor;
      uniform vec3 uSurfaceColor;
      uniform vec3 uFoamColor;
      uniform float uTime;
      varying vec2 vUv;
      varying float vElevation;
      
      void main() {
        // 深浅渐变
        vec3 color = mix(uDeepColor, uSurfaceColor, vElevation * 0.5 + 0.5);
        
        // 泡沫
        float foam = step(0.7, vElevation);
        color = mix(color, uFoamColor, foam * 0.3);
        
        // 闪烁
        float shimmer = sin(uTime * 3.0 + vUv.x * 10.0) * 0.05 + 0.95;
        color *= shimmer;
        
        gl_FragColor = vec4(color, 0.95);
      }
    `,transparent:!0,side:x}),s=new C(f,m);s.position.y=-10,r.add(s);const t=[],w=[new a(65280),new a(16711935),new a(65535),new a(26367)];for(let o=0;o<S;o++){const e=new y(l,l*.6,128,64);e.rotateX(Math.PI/3);const i=w[o%w.length],v=new g({uniforms:{uTime:{value:0},uColor:{value:i},uBandIndex:{value:o}},vertexShader:`
        uniform float uTime;
        uniform float uBandIndex;
        varying vec2 vUv;
        varying float vAlpha;
        
        void main() {
          vUv = uv;
          vec3 pos = position;
          
          // 波浪形
          pos.x += sin(uv.y * 10.0 + uTime * 0.5 + uBandIndex) * 5.0;
          pos.y += cos(uv.y * 8.0 + uTime * 0.6 + uBandIndex) * 3.0;
          
          // 高度渐变
          float height = sin(uv.y * 3.14159) * 20.0;
          pos.y += height;
          
          vAlpha = height / 20.0;
          
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform vec3 uColor;
        uniform float uTime;
        varying vec2 vUv;
        varying float vAlpha;
        
        void main() {
          // 渐变透明度
          float alpha = vAlpha * 0.4 * (1.0 - abs(vUv.x - 0.5) * 2.0);
          
          // 闪烁
          float shimmer = sin(uTime * 2.0 + vUv.y * 5.0) * 0.2 + 0.8;
          
          gl_FragColor = vec4(uColor * shimmer, alpha);
        }
      `,transparent:!0,blending:A,side:x,depthWrite:!1}),n=new C(e,v);n.position.y=30+o*8,n.position.z=-20,r.add(n),t.push(n)}const c=new B,u=new Float32Array(3e3*3);for(let o=0;o<3e3;o++)u[o*3]=(Math.random()-.5)*500,u[o*3+1]=Math.random()*200+50,u[o*3+2]=(Math.random()-.5)*500;c.setAttribute("position",new E(u,3));const d=new P({color:16777215,size:.5,transparent:!0,opacity:.8,sizeAttenuation:!0}),p=new U(c,d);return r.add(p),{ocean:s,auroraBands:t,stars:p,update(o,e){m.uniforms.uTime.value=e,t.forEach((i,v)=>{i.material.uniforms.uTime.value=e+v*.5}),Math.random()<.05&&(d.opacity=.5+Math.random()*.5)},animate(o,e){const i=M.timeline({onComplete:e});return t.forEach((v,n)=>{M.to(v.material.uniforms,{value:o*(n+1)*.2,duration:2,ease:"power2.inOut"})}),i.to(s.scale,{y:1.2,duration:3,ease:"power2.inOut",yoyo:!0,repeat:1}),i},destroy(){r.remove(s),r.remove(p),t.forEach(o=>r.remove(o)),f.dispose(),m.dispose(),c.dispose(),d.dispose(),t.forEach(o=>{o.geometry.dispose(),o.material.dispose()})}}}export{z as createOceanAurora};

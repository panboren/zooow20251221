import{_ as o,c as r,d as t,e as s,o as i}from"./CeLQrDbc.js";const n={class:"loading-indicator",role:"status","aria-live":"polite"},d={class:"loading-progress"},l={__name:"LoadingIndicator",props:{text:{type:String,default:"正在加载..."},progress:{type:String,default:""}},setup(e){/**
 * LoadingIndicator Component
 * 加载指示器组件，提供友好的加载状态展示
 *
 * @component LoadingIndicator
 * @author ZOOOW-AI Team
 * @version 1.0.0
 * @license MIT
 */return(c,a)=>(i(),r("div",n,[a[0]||(a[0]=t("div",{class:"loading-spinner","aria-hidden":"true"},null,-1)),t("p",null,s(e.text),1),t("div",d,s(e.progress),1)]))}},g=o(l,[["__scopeId","data-v-3d23a14f"]]);export{g as default};

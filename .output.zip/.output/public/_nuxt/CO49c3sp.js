import{C as g,T as I,a9 as w,D as P,A as h,b,S as z,B as E,V as N,c as C,P as W,d as A,g as R}from"./Di3biKPp.js";function V(u,T={}){const{ringCount:S=6,maxRadius:c=80,baseColor:y=new g(65535),secondaryColor:x=new g(16711935)}=T,m=[],t=[];for(let o=0;o<S;o++){const a=10+o*12,e=2-o*.2,i=new I(a,e,16,100),r=new w({uniforms:{uTime:{value:0},uColor1:{value:y.clone()},uColor2:{value:x.clone()},uRingIndex:{value:o}},vertexShader:`
        uniform float uTime;
        uniform float uRingIndex;
        varying vec2 vUv;
        varying vec3 vPosition;
        varying vec3 vNormal;
        varying float vPulse;

        void main() {
          vUv = uv;
          vPosition = position;
          vNormal = normalize(normalMatrix * normal);

          // 脉冲变形
          float pulse = sin(uTime * 3.0 + vPosition.y * 0.5) * 0.5 + 0.5;
          vPulse = pulse;

          vec3 pos = position;
          pos += normal * pulse * (2.0 - uRingIndex * 0.3);

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        uniform float uRingIndex;

        varying vec2 vUv;
        varying vec3 vPosition;
        varying vec3 vNormal;
        varying float vPulse;

        void main() {
          // 能量流动
          float flow = sin(vUv.x * 20.0 - uTime * 4.0) * 0.5 + 0.5;

          // 菲涅尔效应
          float fresnel = pow(1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0))), 2.0);

          // 颜色混合
          vec3 color = mix(uColor1, uColor2, flow + uRingIndex * 0.15);

          // 脉冲光晕
          color *= 1.0 + fresnel * 3.0 + vPulse * 2.0;

          // 能量线
          float energyLine = step(0.9, sin(vUv.x * 40.0 + uTime * 5.0));
          color += vec3(1.0) * energyLine * 0.5;

          // 透明度
          float alpha = 0.4 + fresnel * 0.3 + vPulse * 0.2;

          gl_FragColor = vec4(color, alpha);
        }
      `,transparent:!0,blending:h,depthWrite:!1,side:P}),v=new b(i,r);v.rotation.x=Math.PI/2,v.position.y=-20+o*5,u.add(v),m.push(v)}for(let o=0;o<3;o++){const a=new z(5,64,64),e=new w({uniforms:{uTime:{value:0},uColor:{value:y.clone()},uWaveIndex:{value:o},uMaxRadius:{value:c}},vertexShader:`
        uniform float uTime;
        uniform float uWaveIndex;
        varying vec3 vPosition;
        varying vec3 vNormal;
        varying float vRipple;

        void main() {
          vPosition = position;
          vNormal = normalize(normalMatrix * normal);

          // 波纹变形
          float ripple = sin(length(position) * 2.0 - uTime * 3.0 - uWaveIndex * 2.0);
          vRipple = ripple;

          vec3 pos = position;
          pos += normal * ripple * 2.0;

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform vec3 uColor;
        uniform float uWaveIndex;
        uniform float uMaxRadius;

        varying vec3 vPosition;
        varying vec3 vNormal;
        varying float vRipple;

        void main() {
          // 冲击波纹
          float wave = sin(vRipple * 3.0) * 0.5 + 0.5;

          // 边缘发光
          float edge = pow(1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0))), 3.0);

          // 能量强度
          float intensity = wave * edge;

          vec3 color = uColor * (1.0 + intensity * 4.0);

          // 透明度渐变
          float alpha = intensity * 0.6 * (1.0 - smoothstep(0.0, uMaxRadius, length(vPosition)));

          gl_FragColor = vec4(color, alpha);
        }
      `,transparent:!0,blending:h,depthWrite:!1,side:P}),i=new b(a,e);i.visible=!1,u.add(i),t.push(i)}const f=500,n=new E,l=new Float32Array(f*3),d=new Float32Array(f*3),p=[];for(let o=0;o<f;o++){const a=Math.random()*Math.PI*2,e=Math.random()*Math.PI,i=Math.random()*30;l[o*3]=i*Math.sin(e)*Math.cos(a),l[o*3+1]=i*Math.cos(e),l[o*3+2]=i*Math.sin(e)*Math.sin(a);const r=new g().lerpColors(y,x,Math.random());d[o*3]=r.r,d[o*3+1]=r.g,d[o*3+2]=r.b;const v=new N(l[o*3],l[o*3+1],l[o*3+2]).normalize().multiplyScalar(.5+Math.random());p.push(v)}n.setAttribute("position",new C(l,3)),n.setAttribute("color",new C(d,3));const M=new W({size:1.5,vertexColors:!0,transparent:!0,opacity:.8,blending:h,depthWrite:!1}),s=new A(n,M);return s.visible=!1,u.add(s),{rings:m,shockwaves:t,particles:s,particleGeometry:n,particleVelocities:p,update(o){if(m.forEach((a,e)=>{a.material.uniforms.uTime.value=o,a.rotation.z=o*.1*(e%2===0?1:-1)}),t.forEach((a,e)=>{a.visible&&(a.material.uniforms.uTime.value=o,a.rotation.y+=o*.02)}),s.visible){const a=n.attributes.position.array;for(let e=0;e<f;e++)a[e*3]+=p[e].x,a[e*3+1]+=p[e].y,a[e*3+2]+=p[e].z,Math.sqrt(a[e*3]**2+a[e*3+1]**2+a[e*3+2]**2)>c&&(a[e*3]=0,a[e*3+1]=0,a[e*3+2]=0);n.attributes.position.needsUpdate=!0}},animate(o,a){const e=R.timeline({onComplete:a});return m.forEach((i,r)=>{R.to(i.scale,{x:2,y:2,z:2,duration:.4,delay:r*.08,ease:"power2.out",yoyo:!0,repeat:1})}),e.call(()=>{t.forEach((i,r)=>{i.visible=!0,i.scale.setScalar(.1)}),s.visible=!0},null,.5),e.to(t,{scale:{x:c/5,y:c/5,z:c/5},duration:1.5,ease:"power2.out"},.5),e.to(t,{material:{opacity:0},duration:1,ease:"power2.in",onComplete:()=>{t.forEach(i=>{i.visible=!1,i.material.opacity=1,i.scale.setScalar(.1)})}},"<"),e.to(s.scale,{x:3,y:3,z:3,duration:.5,ease:"power2.out"},.5),e},destroy(){m.forEach(o=>{u.remove(o),o.geometry.dispose(),o.material.dispose()}),t.forEach(o=>{u.remove(o),o.geometry.dispose(),o.material.dispose()}),u.remove(s),n.dispose(),M.dispose()}}}export{V as createEnergyPulseRing};

import{C as u,S,a9 as E,A as w,t as U,b as z,B,c as M,P as F,d as G,cu as N,f as T,g as y}from"./Di3biKPp.js";function W(s,A={}){const{nebulaCount:P=5,starCount:d=3e3,vortexRadius:g=60}=A,i=[new u(16738740),new u(9662683),new u(49151),new u(16752762),new u(10025880)],f=[];for(let t=0;t<P;t++){const r=i[t%i.length],a=g+t*10,o=new S(a,48,48),e=new E({uniforms:{uTime:{value:0},uColor:{value:r}},vertexShader:`    uniform float uTime;
    varying vec2 vUv;
    varying vec3 vNormal;

    void main() {
      vUv = uv;
      vNormal = normalize(normalMatrix * normal);
      gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
    }
  `,fragmentShader:`
        uniform vec3 uColor;
        uniform float uTime;
        varying vec2 vUv;
        varying vec3 vNormal;

        void main() {
          float viewDot = abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
          float fresnel = pow(1.0 - viewDot, 3.0);
          float flow = sin(vUv.y * 10.0 + uTime * 0.5) * 0.5 + 0.5;
          float edge = 1.0 - smoothstep(0.3, 0.5, abs(vUv.y - 0.5) * 2.0);
          vec3 glow = uColor * (0.3 + fresnel * 0.5);
          vec3 dreamColor = uColor * 1.3;
          dreamColor += vec3(0.5, 0.3, 0.8) * fresnel * 0.3;
          vec3 finalColor = mix(glow, dreamColor, flow);
          finalColor *= edge;
          float alpha = 0.2 + fresnel * 0.4;
          alpha *= edge * (0.5 + flow * 0.5);
          gl_FragColor = vec4(finalColor, alpha);
        }
      `,transparent:!0,side:U,depthWrite:!1,blending:w}),c=new z(o,e);c.position.y=-20+t*10,s.add(c),f.push(c)}const n=new B,m=new Float32Array(d*3),v=new Float32Array(d*3),x=new Float32Array(d);for(let t=0;t<d;t++){const r=Math.random()*Math.PI*2,a=Math.random()*Math.PI,o=Math.random()*g;m[t*3]=o*Math.sin(a)*Math.cos(r),m[t*3+1]=o*Math.cos(a),m[t*3+2]=o*Math.sin(a)*Math.sin(r);const e=i[Math.floor(Math.random()*i.length)];v[t*3]=e.r,v[t*3+1]=e.g,v[t*3+2]=e.b,x[t]=Math.random()*1.5+.5}n.setAttribute("position",new M(m,3)),n.setAttribute("color",new M(v,3)),n.setAttribute("size",new M(x,1));const p=new F({size:1.5,vertexColors:!0,transparent:!0,opacity:.8,blending:w,depthWrite:!1,sizeAttenuation:!0}),l=new G(n,p);s.add(l);const h=[];for(let t=0;t<12;t++){const r=new N(.1,2,80,8),a=new T({color:i[t%i.length],transparent:!0,opacity:.3,blending:w}),o=new z(r,a);o.position.set(0,0,0),o.rotation.x=(Math.random()-.5)*Math.PI,o.rotation.z=(Math.random()-.5)*Math.PI,s.add(o),h.push(o)}return{nebulas:f,stars:l,starGeometry:n,starMaterial:p,lightRays:h,update(t){f.forEach((a,o)=>{a.material.uniforms.uTime.value=t,a.rotation.y=t*.05*(o%2===0?1:-1),a.rotation.z=Math.sin(t*.1+o)*.1});const r=n.attributes.position.array;for(let a=0;a<d;a++){const o=r[a*3],e=r[a*3+2],c=Math.sqrt(o*o+e*e),C=Math.atan2(e,o)+t*.02/(c*.02+1),b=c*(1+Math.sin(t*.5)*.001);r[a*3]=Math.cos(C)*b,r[a*3+2]=Math.sin(C)*b}n.attributes.position.needsUpdate=!0,l.rotation.y=t*.01,h.forEach((a,o)=>{a.rotation.y+=t*.02*(o%2===0?1:-1),a.material.opacity=.2+Math.sin(t*2+o)*.1})},animate(t,r){const a=y.timeline({onComplete:r});return f.forEach((o,e)=>{y.to(o.scale,{x:.5,y:.5,z:.5,duration:t*.3,ease:"power2.in",delay:e*.05}),y.to(o.scale,{x:1.5,y:1.5,z:1.5,duration:t*.7,ease:"elastic.out(1, 0.4)",delay:t*.3+e*.05})}),a.to(l.scale,{x:2,y:2,z:2,duration:.5,ease:"power2.out"},0),a.to(l.scale,{x:1,y:1,z:1,duration:1,ease:"power2.in"},.5),h.forEach((o,e)=>{y.to(o.material,{opacity:.8,duration:.3,delay:e*.05,yoyo:!0,repeat:1})}),a},destroy(){f.forEach(t=>{s.remove(t),t.geometry.dispose(),t.material.dispose()}),s.remove(l),h.forEach(t=>{s.remove(t),t.geometry.dispose(),t.material.dispose()}),n.dispose(),p&&p.dispose()}}}export{W as createNebulaVortex};

import{B as z,C as u,c as w,P as N,A as M,d as V,cs as _,a9 as L,D as j,b as E,S as D,V as F,L as W,h as O,g as s}from"./Di3biKPp.js";function Y(c,B={}){const{particleCount:l=2e4,waveLayers:G=5}=B,n=new z,y=new Float32Array(l*3),g=new Float32Array(l*3),P=new Float32Array(l),C=new Float32Array(l),S=new Float32Array(l),v=[new u(16739179),new u(5164484),new u(16770669),new u(9822675),new u(15958401),new u(11179738),new u(16562899),new u(11065578)];for(let e=0;e<l;e++){const a=Math.random()*Math.PI*2,i=30+Math.random()*50;y[e*3]=Math.cos(a)*i,y[e*3+1]=(Math.random()-.5)*60,y[e*3+2]=Math.sin(a)*i;const o=v[Math.floor(Math.random()*v.length)];g[e*3]=o.r,g[e*3+1]=o.g,g[e*3+2]=o.b,P[e]=.5+Math.random()*1.5,C[e]=Math.random()*Math.PI*2,S[e]=5+Math.random()*15}n.setAttribute("position",new w(y,3)),n.setAttribute("color",new w(g,3)),n.setAttribute("size",new w(P,1)),n.setAttribute("phase",new w(C,1)),n.setAttribute("amplitude",new w(S,1));const f=new N({size:1.5,vertexColors:!0,transparent:!0,opacity:0,blending:M,depthWrite:!1}),x=new V(n,f);c.add(x);const b=new Float32Array(l*3);for(let e=0;e<l*3;e++)b[e]=y[e];const m=[];for(let e=0;e<G;e++){const a=new _(20+e*15,22+e*15,64),i=new L({uniforms:{uTime:{value:0},uColor:{value:v[e%v.length]},uLayer:{value:e}},vertexShader:`
        uniform float uTime;
        uniform float uLayer;
        varying vec2 vUv;
        varying vec3 vPos;

        void main() {
          vUv = uv;
          vec3 pos = position;

          // 波浪变形
          float wave = sin(uTime * 3.0 + uLayer * 0.5) * 3.0;
          float ripple = sin(length(pos.xz) * 0.5 - uTime * 5.0) * 2.0;
          pos.y += wave + ripple;

          vPos = pos;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform float uLayer;
        uniform vec3 uColor;
        varying vec2 vUv;
        varying vec3 vPos;

        void main() {
          // 同心圆波纹
          float dist = length(vPos.xz);
          float ripple = sin(dist * 0.3 - uTime * 5.0) * 0.5 + 0.5;

          // 边缘发光
          float edge = 1.0 - abs(vUv.y - 0.5) * 2.0;
          edge = pow(edge, 2.0);

          vec3 color = uColor * (0.5 + ripple * 0.5);
          float alpha = edge * 0.6;

          gl_FragColor = vec4(color, alpha);
        }
      `,transparent:!0,side:j,blending:M}),o=new E(a,i);o.rotation.x=Math.PI/2,o.position.y=-10-e*5,o.scale.setScalar(0),c.add(o),m.push(o)}const A=new D(10,32,32),T=new L({uniforms:{uTime:{value:0},uColor:{value:new u(16777215)}},vertexShader:`
      uniform float uTime;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPos = position;

        // 脉动效果
        float pulse = sin(uTime * 8.0 + length(position) * 0.5) * 0.5;
        vec3 pos = position + normal * pulse;

        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        float fresnel = pow(1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0))), 3.0);
        float pulse = sin(uTime * 10.0) * 0.3 + 0.7;

        // 多彩渐变
        float hue = (uTime * 0.1 + length(vPos) * 0.05);
        vec3 color = uColor * (0.5 + fresnel * 0.5);
        color += vec3(0.5, 0.3, 0.8) * fresnel * pulse;

        float alpha = fresnel * 0.8;
        gl_FragColor = vec4(color, alpha);
      }
    `,transparent:!0,blending:M}),d=new E(A,T);d.scale.setScalar(0),c.add(d);const h=[],U=100;for(let e=0;e<U;e++){const a=new z,i=[],o=Math.random()*Math.PI*2,t=10+Math.random()*40;i.push(new F(Math.cos(o)*t,(Math.random()-.5)*60,Math.sin(o)*t)),i.push(new F(0,0,0)),a.setFromPoints(i);const r=new W({color:v[Math.floor(Math.random()*v.length)],transparent:!0,opacity:0,blending:M}),p=new O(a,r);c.add(p),h.push(p)}return{notes:x,noteGeometry:n,noteMaterial:f,waveLayersMeshes:m,noteSphere:d,connections:h,originalPositions:b,update(e,a){m.forEach((r,p)=>{r.material.uniforms.uTime.value=a,r.rotation.z+=e*.2*(p%2===0?1:-1)}),d.material.uniforms.uTime.value=a;const i=n.attributes.position.array,o=n.attributes.phase.array,t=n.attributes.amplitude.array;for(let r=0;r<l;r++)if(f.opacity>0){const p=b[r*3+1];i[r*3+1]=p+Math.sin(a*3+o[r])*t[r]*.3}n.attributes.position.needsUpdate=!0,h.forEach((r,p)=>{if(r.material.opacity>0){const I=Math.sin(a*5+p*.1)*.5+.5;r.material.opacity=I*.3}})},animate(e,a){const i=s.timeline({onComplete:a});return m.forEach((o,t)=>{s.to(o.scale,{x:1,y:1,z:1,duration:1,delay:t*.15,ease:"elastic.out(1, 0.5)"})}),s.to(d.scale,{x:1,y:1,z:1,duration:1,delay:1,ease:"elastic.out(1, 0.5)"}),s.to(f,{opacity:1,duration:1.5,delay:1.5,ease:"power2.out"}),h.forEach((o,t)=>{s.to(o.material,{opacity:.3,duration:.5,delay:2+t*.005,ease:"power2.out"})}),s.to(d.scale,{x:1.5,y:1.5,z:1.5,duration:1,delay:3,ease:"power2.inOut",yoyo:!0,repeat:1}),m.forEach((o,t)=>{s.to(o.material.uniforms.uColor.value,{r:1,g:1,b:1,duration:.5,delay:3+t*.1,yoyo:!0,repeat:1})}),s.to(f,{opacity:0,duration:2,delay:5,ease:"power2.in"}),h.forEach((o,t)=>{s.to(o.material,{opacity:0,duration:1,delay:5+t*.005,ease:"power2.in"})}),s.to(d.scale,{x:0,y:0,z:0,duration:1.5,delay:5.5,ease:"power2.in"}),m.forEach((o,t)=>{s.to(o.scale,{x:0,y:0,z:0,duration:1.5,delay:6-t*.1,ease:"power2.in"})}),i},destroy(){c.remove(x),m.forEach(e=>{c.remove(e),e.geometry.dispose(),e.material.dispose()}),c.remove(d),h.forEach(e=>{c.remove(e),e.geometry.dispose(),e.material.dispose()}),n.dispose(),f.dispose(),A.dispose(),T.dispose()}}}export{Y as createCosmicParticleSymphony};

import{C as s,a$ as B,a9 as T,D as U,A as p,b as w,S as G,f as I,s as F,B as E,c as A,P as W,d as N,g as y}from"./Di3biKPp.js";function _(n,z={}){const{bandCount:g=8,galaxyRadius:x=80}=z,u=[],M=[new s(65280),new s(16711935),new s(65535),new s(16737792),new s(33023),new s(16766720),new s(9662683),new s(65407)];for(let e=0;e<g;e++){const a=new B(x*2,40,128,64);a.rotateX(-Math.PI/5);const r=M[e%M.length],o=new T({uniforms:{uTime:{value:0},uColor:{value:r},uBandIndex:{value:e},uGalaxyRadius:{value:x}},vertexShader:`
        uniform float uTime;
        uniform float uBandIndex;
        uniform float uGalaxyRadius;  // 🔧 修复：声明 uniform
        varying vec2 vUv;
        varying float vAlpha;
        varying vec3 vPos;

        void main() {
          vUv = uv;
          vec3 pos = position;

          // 漩涡形状 - 使用径向坐标
          float dist = length(pos.xz);
          float angle = atan(pos.z, pos.x);

          // 螺旋扭曲
          float spiral = dist * 0.05;
          angle += spiral + uTime * 0.3 + uBandIndex * 0.2;

          // 更新的位置
          pos.x = cos(angle) * dist;
          pos.z = sin(angle) * dist;

          // 垂直波动 - 多层波浪
          float wave1 = sin(dist * 0.2 + uTime * 0.5);
          float wave2 = sin(dist * 0.3 + uTime * 0.7 + uBandIndex * 0.1);
          float wave3 = cos(uv.y * 4.0 + uTime * 0.6);

          pos.y += (wave1 + wave2 + wave3) * 6.0;

          // 距离衰减 - 中心更亮
          float fade = 1.0 - smoothstep(0.0, uGalaxyRadius, dist);  // 🔧 修复：使用 uniform
          pos.y += fade * 15.0;

          vAlpha = fade;
          vPos = pos;

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform vec3 uColor;
        uniform float uTime;
        uniform float uBandIndex;
        varying vec2 vUv;
        varying float vAlpha;
        varying vec3 vPos;

        void main() {
          // 透明度渐变 - 中心亮，边缘淡
          float alpha = vAlpha * 0.45 * (1.0 - abs(vUv.x - 0.5) * 1.6);

          // 流动效果 - 更强的对比
          float flow = sin(uTime * 3.0 + vUv.y * 5.0 + vPos.x * 0.05) * 0.25 + 0.85;

          // 边缘柔化
          float edge = 1.0 - smoothstep(0.2, 0.4, abs(vUv.x - 0.5));

          // 高光效果
          float highlight = pow(flow, 2.5) * 0.4;

          // 径向渐变 - 更清晰的颜色
          float radialFade = 1.0 - smoothstep(0.0, 0.8, vUv.y);

          vec3 finalColor = uColor * flow + vec3(highlight);
          finalColor *= radialFade;

          gl_FragColor = vec4(finalColor, alpha * edge);
        }
      `,transparent:!0,blending:p,side:U,depthWrite:!1}),i=new w(a,o);i.position.z=-30+e*5,i.position.y=10+e*3,i.rotation.y=e/g*Math.PI*.5,n.add(i),u.push(i)}const f=[];for(let e=0;e<3;e++){const a=10+e*8,r=.25-e*.08,o=new s(16775388),i=new G(a,64,64),l=new I({color:o,transparent:!0,opacity:r,blending:p,depthWrite:!1,side:F}),S=new w(i,l);n.add(S),f.push(S)}const d=new E,h=500,v=new Float32Array(h*3),m=new Float32Array(h*3);for(let e=0;e<h;e++){v[e*3]=(Math.random()-.5)*200,v[e*3+1]=Math.random()*100,v[e*3+2]=(Math.random()-.5)*200;const a=new s().setHSL(Math.random(),.7,.6);m[e*3]=a.r,m[e*3+1]=a.g,m[e*3+2]=a.b}d.setAttribute("position",new A(v,3)),d.setAttribute("color",new A(m,3));const C=new W({size:2,vertexColors:!0,transparent:!0,opacity:.7,blending:p,depthWrite:!1,sizeAttenuation:!0}),c=new N(d,C);n.add(c);const b=new G(3,32,32),P=new T({uniforms:{uTime:{value:0},uColor:{value:new s(16766720)}},vertexShader:`
      uniform float uTime;
      varying vec3 vNormal;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec3 vNormal;

      void main() {
        float intensity = pow(0.7 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
        float pulse = sin(uTime * 8.0) * 0.3 + 0.7;
        gl_FragColor = vec4(uColor * pulse, intensity * 0.8);
      }
    `,transparent:!0,blending:p,depthWrite:!1}),t=new w(b,P);return t.visible=!1,n.add(t),{bands:u,centerLayers:f,stars:c,starGeometry:d,starMaterial:C,energy:t,update(e,a){u.forEach((o,i)=>{o.material.uniforms.uTime.value=a+i*.2}),f.forEach((o,i)=>{const l=Math.sin(a*(1.5+i*.5))*.15+1;o.scale.setScalar(l)});const r=this.starGeometry.attributes.position.array;for(let o=0;o<500;o++)Math.random()<.01&&(r[o*3+1]+=(Math.random()-.5)*.5);this.starGeometry.attributes.position.needsUpdate=!0,c.rotation.y+=e*.01,t.visible&&(t.material.uniforms.uTime.value=a)},animate(e,a){const r=y.timeline({onComplete:a});return u.forEach((o,i)=>{const l=i*.06;y.to(o.scale,{y:1.8,duration:2.5,delay:l,ease:"power2.inOut",yoyo:!0,repeat:1}),y.to(o.material,{opacity:.95,duration:1.8,delay:l,ease:"power2.out",yoyo:!0,repeat:1})}),y.to(f[0].scale,{x:2.5,y:2.5,z:2.5,duration:2,ease:"elastic.out(1, 0.5)"}),r.call(()=>{t.visible=!0,t.scale.setScalar(.01)},null,2),r.to(t.scale,{x:40,y:40,z:40,duration:1.5,ease:"elastic.out(1, 0.5)"}),r.to(t.material,{opacity:0,duration:2.5,ease:"power2.in"}),r.to(t.scale,{x:.01,y:.01,z:.01,duration:2.5,ease:"power2.in",onComplete:()=>{t.visible=!1,t.material.opacity=.8}},"<"),r},destroy(){u.forEach(e=>{n.remove(e),e.geometry.dispose(),e.material.dispose()}),f.forEach(e=>{n.remove(e),e.geometry.dispose(),e.material.dispose()}),n.remove(c),n.remove(t),this.starGeometry.dispose(),this.starMaterial.dispose(),b.dispose(),P.dispose()}}}export{_ as createGalaxyVortex};

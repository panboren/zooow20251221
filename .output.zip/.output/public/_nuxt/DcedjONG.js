import{_ as s,c as e,d as o,o as n}from"./CeLQrDbc.js";const r={class:"controls-hint"},a={__name:"ControlsHint",setup(_){/**
 * ControlsHint Component
 * 控制提示组件，显示用户交互提示
 *
 * @component ControlsHint
 * @author ZOOOW-AI Team
 * @version 1.0.0
 * @license MIT
 */return(c,t)=>(n(),e("div",r,[...t[0]||(t[0]=[o("p",null,"🖱️ 左键拖拽旋转 | 🔍 滚轮缩放 | 📱 触摸手势控制",-1),o("p",null,"🔄 双击切换自动旋转 | 🎯 使用视角按钮快速定位",-1)])]))}},p=s(a,[["__scopeId","data-v-b5b4b6e2"]]);export{p as default};

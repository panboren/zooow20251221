import{E as O,f as N,D as I,b as M,V as A,T as B,a9 as S,A as g,C as x,e as G,B as U,c as T,P as V,d as F,g as i}from"./Di3biKPp.js";function j(s,E={}){const{shardCount:R=3e3,timelineRings:w=7}=E,l=[],P=[65535,16711935,65280,16737792,39423,16763904];for(let o=0;o<R;o++){const r=.5+Math.random()*1.5,e=new O(r,r,r*.1),a=new N({color:P[Math.floor(Math.random()*P.length)],transparent:!0,opacity:0,side:I}),t=new M(e,a),h=20+Math.random()*50,b=Math.random()*Math.PI*2,y=Math.random()*Math.PI;t.position.set(h*Math.sin(y)*Math.cos(b),h*Math.cos(y),h*Math.sin(y)*Math.sin(b)),t.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,Math.random()*Math.PI),t.userData.originalPos=t.position.clone(),t.userData.originalRot=t.rotation.clone(),t.userData.targetPos=t.position.clone().multiplyScalar(2),t.userData.targetRot=new A(Math.random()*Math.PI*2,Math.random()*Math.PI*2,Math.random()*Math.PI*2),t.userData.speed=.5+Math.random()*1.5,t.userData.delay=Math.random()*2,s.add(t),l.push(t)}const c=[];for(let o=0;o<w;o++){const r=15+o*8,e=new B(r,.3,16,100),a=new S({uniforms:{uTime:{value:0},uColor:{value:new x().setHSL(o/w,1,.5)},uOpacity:{value:0}},vertexShader:`
        uniform float uTime;
        varying vec3 vNormal;
        varying vec3 vPos;

        void main() {
          vNormal = normalize(normalMatrix * normal);
          vPos = position;
          vec3 pos = position;
          float wave = sin(uTime * 3.0 + length(pos) * 0.1) * 0.5;
          pos += normal * wave;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform vec3 uColor;
        uniform float uOpacity;
        varying vec3 vNormal;
        varying vec3 vPos;

        void main() {
          float edge = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
          float pulse = sin(uTime * 5.0 + length(vPos) * 0.1) * 0.5 + 0.5;
          vec3 color = uColor * (0.5 + pulse * 0.5);
          float alpha = edge * uOpacity;
          gl_FragColor = vec4(color, alpha);
        }
      `,transparent:!0,blending:g}),t=new M(e,a);t.rotation.x=Math.PI/2,s.add(t),c.push(t)}const D=new G(5,15,32,1,!0),C=new S({uniforms:{uTime:{value:0},uColor:{value:new x(65535)}},vertexShader:`
      uniform float uTime;
      varying vec2 vUv;
      varying vec3 vNormal;

      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vec3 pos = position;

        // 螺旋扭曲
        float angle = atan(pos.z, pos.x);
        float twist = uTime * 2.0 * (1.0 - uv.y);
        angle += twist;

        float radius = length(pos.xz);
        pos.x = cos(angle) * radius;
        pos.z = sin(angle) * radius;

        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec2 vUv;
      varying vec3 vNormal;

      void main() {
        float flow = sin(vUv.y * 20.0 - uTime * 10.0) * 0.5 + 0.5;
        float edge = 1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0)));
        vec3 color = uColor * (0.5 + flow * 0.5);
        float alpha = edge * (1.0 - vUv.y) * 0.8;
        gl_FragColor = vec4(color, alpha);
      }
    `,transparent:!0,side:I,blending:g}),n=new M(D,C);n.rotation.x=Math.PI,n.visible=!1,s.add(n);const u=new U,m=2e3,p=new Float32Array(m*3),v=new Float32Array(m*3);for(let o=0;o<m;o++){p[o*3]=0,p[o*3+1]=0,p[o*3+2]=0;const r=new x().setHSL(Math.random(),1,.6);v[o*3]=r.r,v[o*3+1]=r.g,v[o*3+2]=r.b}u.setAttribute("position",new T(p,3)),u.setAttribute("color",new T(v,3));const d=new V({size:2,vertexColors:!0,transparent:!0,opacity:0,blending:g,depthWrite:!1}),f=new F(u,d);s.add(f);const z=[];for(let o=0;o<m;o++)z.push({theta:Math.random()*Math.PI*2,phi:Math.random()*Math.PI,radius:5+Math.random()*10,speed:2+Math.random()*3});return{shards:l,timelineRingsMeshes:c,vortex:n,particles:f,particleGeometry:u,update(o,r){if(c.forEach((e,a)=>{e.rotation.z+=o*(.5+a*.2)*(a%2===0?1:-1),e.material.uniforms.uTime.value=r}),n.visible&&(n.material.uniforms.uTime.value=r),l.forEach(e=>{e.rotation.x+=o*e.userData.speed,e.rotation.y+=o*e.userData.speed*.7}),d.opacity>0){const e=u.attributes.position.array;for(let a=0;a<m;a++){const t=z[a];t.theta+=o*t.speed,t.radius+=o*5,e[a*3]=Math.cos(t.theta)*Math.sin(t.phi)*t.radius,e[a*3+1]=Math.cos(t.phi)*t.radius*.5,e[a*3+2]=Math.sin(t.theta)*Math.sin(t.phi)*t.radius,t.radius>100&&(t.radius=5,t.theta=Math.random()*Math.PI*2,t.phi=Math.random()*Math.PI)}u.attributes.position.needsUpdate=!0}},animate(o,r){const e=i.timeline({onComplete:r});return l.forEach((a,t)=>{i.to(a.material,{opacity:.8,duration:.5,delay:t*.001,ease:"power2.out"})}),c.forEach((a,t)=>{i.to(a.material.uniforms.uOpacity,{value:.6,duration:.5,delay:.5+t*.1,ease:"power2.out"})}),i.delayedCall(1.5,()=>{n.visible=!0,n.scale.setScalar(0)}),i.to(n.scale,{x:1,y:1,z:1,duration:1,delay:1.5,ease:"elastic.out(1, 0.5)"}),i.to(d,{opacity:1,duration:.5,delay:2}),l.forEach((a,t)=>{i.to(a.position,{x:a.userData.targetPos.x,y:a.userData.targetPos.y,z:a.userData.targetPos.z,duration:2,delay:2.5+a.userData.delay,ease:"power2.inOut"}),i.to(a.rotation,{x:a.userData.targetRot.x,y:a.userData.targetRot.y,z:a.userData.targetRot.z,duration:2,delay:2.5+a.userData.delay,ease:"power2.inOut"})}),l.forEach((a,t)=>{i.to(a.position,{x:a.userData.originalPos.x,y:a.userData.originalPos.y,z:a.userData.originalPos.z,duration:1.5,delay:5,ease:"power2.inOut"}),i.to(a.rotation,{x:a.userData.originalRot.x,y:a.userData.originalRot.y,z:a.userData.originalRot.z,duration:1.5,delay:5,ease:"power2.inOut"}),i.to(a.material,{opacity:0,duration:1,delay:6})}),i.to(d,{opacity:0,duration:1,delay:6}),c.forEach((a,t)=>{i.to(a.material.uniforms.uOpacity,{value:0,duration:1,delay:6})}),i.to(n.scale,{x:0,y:0,z:0,duration:.5,delay:6,ease:"power2.in",onComplete:()=>{n.visible=!1}}),e},destroy(){l.forEach(o=>{s.remove(o),o.geometry.dispose(),o.material.dispose()}),c.forEach(o=>{s.remove(o),o.geometry.dispose(),o.material.dispose()}),s.remove(n),s.remove(f),D.dispose(),C.dispose(),u.dispose(),d.dispose()}}}export{j as createTimeShards};

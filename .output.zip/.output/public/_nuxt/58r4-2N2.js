import{C as v,B as z,c as p,a9 as T,A,d as B,cz as F,cC as U,S as _,s as D,b as G,g as L,cD as N}from"./Di3biKPp.js";function I(){const o=document.createElement("canvas");o.width=64,o.height=64;const r=o.getContext("2d"),n=r.createRadialGradient(32,32,0,32,32,32);n.addColorStop(0,"rgba(255, 255, 255, 1)"),n.addColorStop(.5,"rgba(255, 220, 225, 0.8)"),n.addColorStop(1,"rgba(255, 200, 210, 0)"),r.fillStyle=n,r.beginPath(),r.moveTo(32,8),r.bezierCurveTo(56,8,56,32,56,48),r.bezierCurveTo(56,56,48,64,32,56),r.bezierCurveTo(16,64,8,56,8,48),r.bezierCurveTo(8,32,8,8,32,8),r.fill();const l=new N(o);return l.needsUpdate=!0,l}function k(o,r={}){const{petalCount:n=2e3,treeRadius:l=30,fallHeight:W=100}=r,M=[new v(16758725),new v(16756409),new v(16764117),new v(16777215)],i=new z,u=new Float32Array(n*3),d=new Float32Array(n*3),x=new Float32Array(n),m=new Float32Array(n);for(let e=0;e<n;e++){const s=Math.random()*Math.PI*2,a=Math.random()*l;u[e*3]=a*Math.cos(s),u[e*3+1]=20+Math.random()*30,u[e*3+2]=a*Math.sin(s);const t=M[Math.floor(Math.random()*M.length)];d[e*3]=t.r,d[e*3+1]=t.g,d[e*3+2]=t.b,x[e]=.3+Math.random()*.7,m[e]=Math.random()*Math.PI*2}i.setAttribute("position",new p(u,3)),i.setAttribute("color",new p(d,3)),i.setAttribute("scale",new p(x,1)),i.setAttribute("phase",new p(m,1));const g=I(),h=new T({uniforms:{uTime:{value:0},uTexture:{value:g}},vertexShader:`
      attribute float scale;
      attribute float phase;
      attribute vec3 color;
      varying vec2 vUv;
      varying vec3 vColor;
      varying float vPhase;

      void main() {
        vUv = uv;
        vColor = color;
        vPhase = phase;

        vec3 pos = position;
        pos *= scale;

        vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
        gl_PointSize = 30.0 * scale * (300.0 / -mvPosition.z);
        gl_Position = projectionMatrix * mvPosition;
      }
    `,fragmentShader:`
      uniform sampler2D uTexture;
      uniform float uTime;
      varying vec2 vUv;
      varying vec3 vColor;
      varying float vPhase;

      void main() {
        vec4 texColor = texture2D(uTexture, vUv);
        float shimmer = sin(uTime * 2.0 + vPhase) * 0.1 + 0.9;
        gl_FragColor = vec4(vColor * shimmer, texColor.a * 0.9);
      }
    `,transparent:!0,depthWrite:!1,blending:A}),w=new B(i,h);o.add(w);const b=new F(16758725,.4);o.add(b);const c=new U(16770229,1.2);c.position.set(50,80,50),o.add(c);const C=new _(40,32,32),y=new T({uniforms:{uColor:{value:new v(16758725)}},vertexShader:`
      varying vec3 vNormal;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }
    `,fragmentShader:`
      uniform vec3 uColor;
      varying vec3 vNormal;
      void main() {
        float intensity = pow(0.7 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.0);
        gl_FragColor = vec4(uColor, intensity * 0.15);
      }
    `,transparent:!0,side:D,blending:A,depthWrite:!1}),f=new G(C,y);return o.add(f),{petals:w,geometry:i,material:h,glow:f,petalTexture:g,ambientLight:b,sunLight:c,update(e,s){const a=i.attributes.position.array;for(let t=0;t<n;t++)if(a[t*3+1]-=e*8,a[t*3]+=Math.sin(s*2+m[t])*e*5,a[t*3+2]+=Math.cos(s*2+m[t])*e*5,a[t*3+1]<-50){const P=Math.random()*Math.PI*2,S=Math.random()*l;a[t*3]=S*Math.cos(P),a[t*3+1]=50,a[t*3+2]=S*Math.sin(P)}i.attributes.position.needsUpdate=!0,h.uniforms.uTime.value=s,f.scale.setScalar(1+Math.sin(s*.5)*.05)},animate(e,s){const a=L.timeline({onComplete:s});return a.to(c,{intensity:2,duration:e*.5,ease:"power2.inOut",yoyo:!0,repeat:1}),a},destroy(){o.remove(w),o.remove(b),o.remove(c),o.remove(f),i.dispose(),h.dispose(),C.dispose(),y.dispose(),g.dispose()}}}export{k as createCherryBlossom};

import{C as p,a$ as C,a9 as M,A as g,D as w,b as y,cs as A,f as E,g as F}from"./Di3biKPp.js";const q=`
  uniform float uTime;
  uniform float uAmplitude;
  uniform float uFrequency;
  uniform float uSpeed;
  
  varying vec2 vUv;
  varying float vElevation;
  
  void main() {
    vUv = uv;
    
    vec3 position = position;
    
    // 计算距离中心的距离
    float dist = distance(position.xy, vec2(0.0));
    
    // 波浪效果
    float wave = sin(dist * uFrequency - uTime * uSpeed);
    
    // 衰减
    float attenuation = 1.0 - smoothstep(0.0, 50.0, dist);
    
    // 应用高度变化
    position.z += wave * uAmplitude * attenuation;
    vElevation = wave * attenuation;
    
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`,G=`
  uniform float uTime;
  uniform vec3 uColor;
  uniform vec3 uGlowColor;
  
  varying vec2 vUv;
  varying float vElevation;
  
  void main() {
    // 基础颜色
    vec3 color = uColor;
    
    // 根据高度添加发光
    float glowIntensity = smoothstep(-0.5, 1.0, vElevation);
    color = mix(color, uGlowColor, glowIntensity);
    
    // 添加能量脉冲效果
    float pulse = sin(uTime * 2.0) * 0.5 + 0.5;
    color *= (1.0 + pulse * 0.3);
    
    // 边缘渐变
    float dist = distance(vUv, vec2(0.5));
    float alpha = 1.0 - smoothstep(0.3, 0.5, dist);
    
    gl_FragColor = vec4(color, alpha);
  }
`;function b(n,h={}){const{size:r=60,segments:m=128,color:f=new p(65416),glowColor:S=new p(65535),amplitude:v=5,frequency:c=.3,speed:x=2}=h,l=new C(r,r,m,m);l.rotateX(-Math.PI/2);const t=new M({uniforms:{uTime:{value:0},uAmplitude:{value:v},uFrequency:{value:c},uSpeed:{value:x},uColor:{value:f},uGlowColor:{value:S}},vertexShader:q,fragmentShader:G,transparent:!0,side:w,blending:g,depthWrite:!1}),s=new y(l,t);s.position.y=-20,n.add(s);const u=[];for(let e=0;e<5;e++){const i=new A(r*(e+1)*.2,r*(e+1)*.25,64),o=new E({color:f,transparent:!0,opacity:.3,side:w,blending:g}),a=new y(i,o);a.rotation.x=-Math.PI/2,a.position.y=-20,a.userData.originalScale=1,n.add(a),u.push(a)}return{wave:s,rings:u,material:t,geometry:l,update(e){t.uniforms.uTime.value=e,u.forEach((i,o)=>{const a=o*.5,d=(e*2+a)%3;i.scale.setScalar(1+d),i.material.opacity=Math.max(0,.5-d*.15)})},animate(e,i){const o=F.timeline({onComplete:i});return o.to(t.uniforms.uAmplitude,{value:v*3,duration:e*.3,ease:"power2.in"}),o.to(t.uniforms.uFrequency,{value:c*2,duration:e*.3},"<"),o.to(t.uniforms.uAmplitude,{value:v,duration:e*.4,ease:"power2.out"}),o.to(t.uniforms.uFrequency,{value:c,duration:e*.4},"<"),o},destroy(){n.remove(s),u.forEach(e=>n.remove(e)),l.dispose(),t.dispose()}}}export{b as createEnergyWave};

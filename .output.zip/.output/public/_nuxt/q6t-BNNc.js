import{C as i,a$ as A,a9 as P,D as b,A as y,b as T,B,c as g,P as S,d as I,g as p}from"./Di3biKPp.js";function U(u,x={}){const{fluidCount:h=12,fluidRadius:C=60}=x,n=[],c=[new i(65280),new i(16711935),new i(65535),new i(16737792),new i(33023)];for(let e=0;e<h;e++){const o=new A(C*2,50,128,64);o.rotateX(-Math.PI/4);const a=c[e%c.length],r=new P({uniforms:{uTime:{value:0},uColor:{value:a},uBandIndex:{value:e}},vertexShader:`
        uniform float uTime;
        uniform float uBandIndex;
        varying vec2 vUv;
        varying float vAlpha;
        varying vec3 vPos;
        
        void main() {
          vUv = uv;
          vec3 pos = position;
          
          // 更复杂的波动效果
          float wave1 = sin(uv.x * 8.0 + uTime * 0.4 + uBandIndex * 0.3);
          float wave2 = sin(uv.x * 4.0 + uTime * 0.6 + uBandIndex * 0.2);
          float wave3 = cos(uv.y * 3.0 + uTime * 0.5);
          float wave4 = sin(uv.x * 6.0 + uTime * 0.7 + uBandIndex * 0.4);
          
          // 垂直波动
          pos.y += (wave1 * 0.5 + wave2 * 0.3 + wave3 * 0.2) * 12.0;
          
          // 水平波动
          pos.x += (wave4 + wave1) * 6.0;
          
          // 高度渐变 - 使用更平滑的曲线
          float height = pow(sin(uv.y * 3.14159 * 0.5 + 0.5), 2.0);
          pos.y += height * 25.0;
          
          vAlpha = height;
          vPos = pos;
          
          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform vec3 uColor;
        uniform float uTime;
        varying vec2 vUv;
        varying float vAlpha;
        varying vec3 vPos;
        
        void main() {
          // 增强透明度 - 更清晰
          float alpha = vAlpha * 0.5 * (1.0 - abs(vUv.x - 0.5) * 1.8);
          
          // 流动效果 - 更强的对比
          float flow = sin(uTime * 3.0 + vUv.y * 6.0 + vPos.x * 0.1) * 0.2 + 0.9;
          
          // 边缘柔化 - 更锐利的边缘
          float edge = 1.0 - smoothstep(0.25, 0.45, abs(vUv.x - 0.5));
          
          // 添加高光
          float highlight = pow(flow, 3.0) * 0.3;
          
          vec3 finalColor = uColor * flow + vec3(highlight);
          
          gl_FragColor = vec4(finalColor, alpha * edge);
        }
      `,transparent:!0,blending:y,side:b,depthWrite:!1}),t=new T(o,r);t.position.z=-25+e*4,t.position.y=20+e*5,t.rotation.y=e/h*Math.PI*.4,u.add(t),n.push(t)}const s=new B,l=300,v=new Float32Array(l*3),M=new Float32Array(l),f=new Float32Array(l*3);for(let e=0;e<l;e++){v[e*3]=(Math.random()-.5)*150,v[e*3+1]=Math.random()*80+10,v[e*3+2]=(Math.random()-.5)*150,M[e]=Math.random()*3+1;const o=new i().setHSL(Math.random(),.8,.7);f[e*3]=o.r,f[e*3+1]=o.g,f[e*3+2]=o.b}s.setAttribute("position",new g(v,3)),s.setAttribute("color",new g(f,3));const d=new S({size:2,vertexColors:!0,transparent:!0,opacity:.8,blending:y,depthWrite:!1,sizeAttenuation:!0}),m=new I(s,d);return u.add(m),{fluids:n,stars:m,update(e,o){n.forEach((a,r)=>{a.material.uniforms.uTime.value=o+r*.2}),s.attributes.position.array;for(let a=0;a<l;a++)Math.random()<.02&&(d.size=2+Math.random()*2)},animate(e,o){const a=p.timeline({onComplete:o});return n.forEach((r,t)=>{const w=t*.08;p.to(r.scale,{y:1.8,duration:2.5,delay:w,ease:"power2.inOut",yoyo:!0,repeat:1}),p.to(r.material,{opacity:.9,duration:1.5,delay:w,ease:"power2.out",yoyo:!0,repeat:1})}),a.to(d,{size:5,duration:1,ease:"power2.inOut",yoyo:!0,repeat:2}),a},destroy(){n.forEach(e=>{u.remove(e),e.geometry.dispose(),e.material.dispose()}),u.remove(m),s.dispose(),d.dispose()}}}export{U as createAuroraFluid};

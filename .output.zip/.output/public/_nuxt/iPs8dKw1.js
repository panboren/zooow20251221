import{cw as N,f as y,b as x,V as B,cs as V,A as b,D,C as g,T as H,a9 as L,B as R,c as P,P as T,d as W,g as l}from"./Di3biKPp.js";function j(i,U={}){const{segmentCount:C=12,shardCount:F=2e3}=U,u=[],h=[],z=new N(1,0),v=[new y({color:65535,transparent:!0,opacity:.9,wireframe:!0}),new y({color:16711935,transparent:!0,opacity:.9,wireframe:!0}),new y({color:16776960,transparent:!0,opacity:.9,wireframe:!0})];for(let o=0;o<F;o++){const e=v[Math.floor(Math.random()*v.length)],a=new x(z,e),t=30+Math.random()*40,r=Math.random()*Math.PI*2,p=Math.random()*Math.PI;a.position.set(t*Math.sin(p)*Math.cos(r),t*Math.cos(p),t*Math.sin(p)*Math.sin(r)),a.rotation.set(Math.random()*Math.PI,Math.random()*Math.PI,Math.random()*Math.PI),a.scale.setScalar(.5+Math.random()*1.5),a.userData.originalPos=a.position.clone(),a.userData.velocity=new B,i.add(a),u.push(a)}for(let o=0;o<C;o++){const e=new V(10+o*3,11+o*3,64),a=new y({color:new g().setHSL(o/C,1,.6),transparent:!0,opacity:.4,side:D,blending:b}),t=new x(e,a);t.rotation.x=Math.PI/2,t.visible=!1,i.add(t),h.push(t)}const S=new H(20,3,16,100),I=new L({uniforms:{uTime:{value:0},uColor:{value:new g(16777215)}},vertexShader:`
      uniform float uTime;
      varying vec2 vUv;
      varying vec3 vNormal;

      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vec3 pos = position;
        pos += normal * sin(uTime * 5.0 + pos.x * 0.5) * 2.0;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec2 vUv;
      varying vec3 vNormal;

      void main() {
        float edge = 1.0 - abs(vUv.x - 0.5) * 2.0;
        float pulse = sin(uTime * 10.0) * 0.5 + 0.5;
        vec3 color = mix(uColor * 0.5, uColor * 1.5, pulse);
        float alpha = edge * (0.3 + pulse * 0.7);
        gl_FragColor = vec4(color, alpha);
      }
    `,transparent:!0,side:D,blending:b}),s=new x(S,I);s.rotation.x=Math.PI/2,s.scale.setScalar(0),i.add(s);const n=new R,c=5e3,m=new Float32Array(c*3),f=new Float32Array(c*3),A=new Float32Array(c);for(let o=0;o<c;o++){m[o*3]=0,m[o*3+1]=0,m[o*3+2]=0;const e=Math.random(),a=new g().setHSL(e,1,.6);f[o*3]=a.r,f[o*3+1]=a.g,f[o*3+2]=a.b,A[o]=Math.random()*2+.5}n.setAttribute("position",new P(m,3)),n.setAttribute("color",new P(f,3)),n.setAttribute("size",new P(A,1));const d=new T({size:2,vertexColors:!0,transparent:!0,opacity:0,blending:b,depthWrite:!1}),w=new W(n,d);i.add(w);const M=[];for(let o=0;o<c;o++){const e=Math.random()*Math.PI*2,a=Math.random()*Math.PI,t=20+Math.random()*40;M.push(new B(Math.sin(a)*Math.cos(e)*t,Math.cos(a)*t,Math.sin(a)*Math.sin(e)*t))}return{shards:u,energyRings:h,rift:s,particles:w,particleGeometry:n,update(o,e){u.forEach((t,r)=>{t.rotation.x+=o*.5,t.rotation.y+=o*.3,t.position.y+=Math.sin(e*2+r*.1)*.01}),h.forEach((t,r)=>{t.visible&&(t.rotation.z+=o*(1+r*.2),t.scale.multiplyScalar(1+o*.3),t.material.opacity-=o*.1,t.material.opacity<0&&(t.material.opacity=0,t.visible=!1))}),s.material.uniforms.uTime.value=e;const a=n.attributes.position.array;for(let t=0;t<c;t++)a[t*3]+=M[t].x*o,a[t*3+1]+=M[t].y*o,a[t*3+2]+=M[t].z*o;n.attributes.position.needsUpdate=!0},animate(o,e){const a=l.timeline({onComplete:e});return l.to(s.scale,{x:1,y:1,z:1,duration:1,ease:"power2.out"}),u.forEach((t,r)=>{const p=Math.random()*.5,E=Math.atan2(t.position.z,t.position.x),G=Math.sqrt(t.position.x*t.position.x+t.position.z*t.position.z);l.to(t.position,{x:Math.cos(E)*(G*3),z:Math.sin(E)*(G*3),duration:2,delay:p,ease:"power2.out"}),l.to(t.rotation,{x:t.rotation.x+Math.PI*4,y:t.rotation.y+Math.PI*4,duration:2,delay:p,ease:"power2.inOut"})}),h.forEach((t,r)=>{l.delayedCall(.3+r*.1,()=>{t.visible=!0,t.scale.setScalar(.5),t.material.opacity=.8})}),l.to(d,{opacity:1,duration:.5,delay:.5}),l.to(d,{opacity:0,duration:1.5,delay:1.5,ease:"power2.in"}),l.to(s.scale,{x:.1,y:.1,z:.1,duration:1,delay:2,ease:"power2.in"}),a},destroy(){u.forEach(o=>{i.remove(o),z.dispose(),v.forEach(e=>e.dispose())}),h.forEach(o=>{i.remove(o),o.geometry.dispose(),o.material.dispose()}),i.remove(s),i.remove(w),S.dispose(),I.dispose(),n.dispose(),d.dispose()}}}export{j as createQuantumDimensionBreak};

import{C as r,cu as P,a9 as z,A as M,D as A,b as T,B as U,c as g,P as I,d as D,g as h}from"./Di3biKPp.js";function F(p,S={}){const{radius:w=25,length:s=150,segmentCount:C=8,speed:y=3}=S,f=[new r(16711680),new r(16744192),new r(16776960),new r(65280),new r(255),new r(4915330),new r(9699539)],l=[];for(let e=0;e<C;e++){const t=f[e%f.length],o=w+e*3,i=new P(o,o,s,64,100,!0),n=new z({uniforms:{uTime:{value:0},uSpeed:{value:y},uColor:{value:t},uSegmentIndex:{value:e}},vertexShader:`
        uniform float uTime;
        uniform float uSegmentIndex;
        varying vec2 vUv;
        varying vec3 vPosition;
        varying float vDist;

        void main() {
          vUv = uv;
          vPosition = position;
          vDist = length(position.xz);

          // 螺旋扭曲
          float angle = atan(position.z, position.x);
          float spiral = sin(angle * 6.0 + uTime * 0.5 + uSegmentIndex * 0.5) * 2.0;
          
          vec3 pos = position;
          pos.y += spiral;

          gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
        }
      `,fragmentShader:`
        uniform float uTime;
        uniform float uSpeed;
        uniform vec3 uColor;
        uniform float uSegmentIndex;
        
        varying vec2 vUv;
        varying vec3 vPosition;
        varying float vDist;

        void main() {
          // 速度线效果
          float speedLine = sin(vUv.y * 50.0 - uTime * uSpeed * 5.0);
          
          // 螺旋光带
          float spiral = sin(atan(vPosition.z, vPosition.x) * 8.0 + uTime * 0.3 + vUv.y * 10.0);
          
          // 霓虹发光
          float glow = pow(spiral * 0.5 + 0.5, 3.0);
          
          // 速度模糊
          float motion = smoothstep(0.3, 0.7, abs(speedLine));
          
          vec3 color = uColor * (1.0 + glow * 2.0);
          color *= 1.0 + motion * 0.5;
          
          // 透明度渐变
          float alpha = 0.3 + glow * 0.4;
          alpha *= 1.0 - smoothstep(0.4, 0.5, abs(vUv.x - 0.5) * 2.0);
          
          gl_FragColor = vec4(color, alpha);
        }
      `,transparent:!0,side:A,depthWrite:!1,blending:M}),m=new T(i,n);m.rotation.x=Math.PI/2,m.position.y=-s/2+e*2,p.add(m),l.push(m)}const u=2e3,a=new U,d=new Float32Array(u*3),v=new Float32Array(u*3),x=new Float32Array(u);for(let e=0;e<u;e++){const t=Math.random()*Math.PI*2,o=Math.random()*w*1.5,i=(Math.random()-.5)*s;d[e*3]=Math.cos(t)*o,d[e*3+1]=i,d[e*3+2]=Math.sin(t)*o;const n=f[Math.floor(Math.random()*f.length)];v[e*3]=n.r,v[e*3+1]=n.g,v[e*3+2]=n.b,x[e]=Math.random()*2+.5}a.setAttribute("position",new g(d,3)),a.setAttribute("color",new g(v,3)),a.setAttribute("size",new g(x,1));const b=new I({size:2,vertexColors:!0,transparent:!0,opacity:.8,blending:M,depthWrite:!1}),c=new D(a,b);return p.add(c),{tunnels:l,particles:c,particleGeometry:a,update(e){l.forEach((o,i)=>{o.material.uniforms.uTime.value=e,o.rotation.z=e*.1*(i%2===0?1:-1)});const t=a.attributes.position.array;for(let o=0;o<u;o++)t[o*3+1]+=y*2,t[o*3+1]>s/2&&(t[o*3+1]=-s/2);a.attributes.position.needsUpdate=!0},animate(e,t){const o=h.timeline({onComplete:t});return l.forEach((i,n)=>{h.to(i.scale,{x:.5,y:.5,z:.5,duration:e*.3,ease:"power2.in",delay:n*.05}),h.to(i.scale,{x:1.5,y:1.5,z:1.5,duration:e*.7,ease:"elastic.out(1, 0.3)",delay:e*.3+n*.05})}),o.to(c.scale,{x:3,y:3,z:3,duration:.5,ease:"power2.out"},0),o.to(c.scale,{x:1,y:1,z:1,duration:1,ease:"power2.in"},.5),o},destroy(){l.forEach(e=>{p.remove(e),e.geometry.dispose(),e.material.dispose()}),p.remove(c),a.dispose(),b.dispose()}}}export{F as createQuantumRainbowTunnel};

import{S as E,a9 as G,A as M,C as y,b as w,B,c as g,P as T,d as F,T as N,f as I,D as k,cu as D,g as i}from"./Di3biKPp.js";function _(n,z={}){const{particleCount:u=15e3,shockwaveCount:A=5}=z,b=new E(5,64,64),C=new G({uniforms:{uTime:{value:0},uColor:{value:new y(16737792)},uIntensity:{value:1}},vertexShader:`
      uniform float uTime;
      uniform float uIntensity;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPos = position;
        vec3 pos = position;
        float noise = sin(pos.x * 3.0 + uTime * 10.0) * cos(pos.y * 3.0 + uTime * 8.0) * 0.3;
        pos += normal * noise * uIntensity;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      uniform float uIntensity;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        float fresnel = pow(1.0 - abs(dot(vNormal, vec3(0.0, 0.0, 1.0))), 2.0);
        float pulse = sin(uTime * 20.0) * 0.3 + 0.7;
        float turbulence = sin(vPos.x * 5.0 + uTime * 15.0) * sin(vPos.y * 5.0 + uTime * 12.0) * 0.5 + 0.5;
        vec3 color = uColor * (1.0 + turbulence * 0.5);
        color += vec3(1.0, 0.8, 0.5) * fresnel * pulse * uIntensity;
        float alpha = 0.8 + fresnel * 0.2;
        gl_FragColor = vec4(color, alpha);
      }
    `,transparent:!0,blending:M}),r=new w(b,C);r.scale.setScalar(0),n.add(r);const l=new B,d=new Float32Array(u*3),v=new Float32Array(u*3),S=new Float32Array(u),h=[];for(let t=0;t<u;t++){d[t*3]=0,d[t*3+1]=0,d[t*3+2]=0;const s=Math.random()*.3,a=new y().setHSL(s,1,.6);v[t*3]=a.r,v[t*3+1]=a.g,v[t*3+2]=a.b,S[t]=Math.random()*3+1;const o=Math.random()*Math.PI*2,e=Math.random()*Math.PI,c=30+Math.random()*50;h.push({x:Math.sin(e)*Math.cos(o)*c,y:Math.cos(e)*c,z:Math.sin(e)*Math.sin(o)*c})}l.setAttribute("position",new g(d,3)),l.setAttribute("color",new g(v,3)),l.setAttribute("size",new g(S,1));const f=new T({size:2,vertexColors:!0,transparent:!0,opacity:0,blending:M,depthWrite:!1}),x=new F(l,f);n.add(x);const p=[];for(let t=0;t<A;t++){const s=new N(20,1,32,100),a=new I({color:16737792,transparent:!0,opacity:0,side:k,blending:M}),o=new w(s,a);o.rotation.x=Math.PI/2,o.visible=!1,n.add(o),p.push(o)}const m=[],P=24;for(let t=0;t<P;t++){const s=new D(.5,3,150,8),a=new I({color:16755200,transparent:!0,opacity:0,blending:M}),o=new w(s,a);o.position.y=75,o.rotation.x=Math.PI/2,o.rotation.z=t/P*Math.PI*2,o.visible=!1,n.add(o),m.push(o)}return{core:r,particles:x,particleGeometry:l,shockwaves:p,beams:m,update(t,s){r.material.uniforms.uTime.value=s;const a=l.attributes.position.array;for(let o=0;o<u;o++)f.opacity>0&&(a[o*3]+=h[o].x*t,a[o*3+1]+=h[o].y*t,a[o*3+2]+=h[o].z*t);l.attributes.position.needsUpdate=!0,p.forEach((o,e)=>{o.visible&&(o.scale.multiplyScalar(1+t*2),o.material.opacity-=t*.3,o.material.opacity<0&&(o.material.opacity=0,o.visible=!1))}),m.forEach((o,e)=>{o.visible&&(o.rotation.z+=t*.5,o.material.opacity-=t*.2,o.material.opacity<0&&(o.material.opacity=0,o.visible=!1))})},animate(t,s){const a=i.timeline({onComplete:s});return i.to(r.scale,{x:.3,y:.3,z:.3,duration:.5,ease:"power2.in"}),i.to(r.material.uniforms.uIntensity,{value:3,duration:.5}),i.to(r.scale,{x:3,y:3,z:3,duration:.3,delay:.5,ease:"power4.out"}),[{t:0,color:16711680},{t:.2,color:16737792},{t:.4,color:16776960},{t:.6,color:16777215},{t:.8,color:65535},{t:1,color:16711935}].forEach(e=>{i.to(r.material.uniforms.uColor.value,{r:new y(e.color).r,g:new y(e.color).g,b:new y(e.color).b,duration:.2,delay:.5+e.t*t*.5})}),i.to(f,{opacity:1,duration:.2,delay:.5}),i.to(f,{opacity:0,duration:2,delay:.7,ease:"power2.in"}),p.forEach((e,c)=>{i.delayedCall(.5+c*.15,()=>{e.visible=!0,e.scale.setScalar(.1),e.material.opacity=.8})}),m.forEach((e,c)=>{i.delayedCall(.5+c*.02,()=>{e.visible=!0,e.material.opacity=.6})}),i.to(r.scale,{x:.1,y:.1,z:.1,duration:1.5,delay:1.5,ease:"power2.in"}),i.to(r.material.uniforms.uIntensity,{value:.5,duration:1.5,delay:1.5}),a},destroy(){n.remove(r),n.remove(x),p.forEach(t=>{n.remove(t),t.geometry.dispose(),t.material.dispose()}),m.forEach(t=>{n.remove(t),t.geometry.dispose(),t.material.dispose()}),b.dispose(),C.dispose(),l.dispose(),f.dispose()}}}export{_ as createCosmicSupernova};

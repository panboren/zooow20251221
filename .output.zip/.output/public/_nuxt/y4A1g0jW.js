import{B as U,C as S,c as b,P as D,A as h,d as W,cu as T,a9 as A,s as N,b as x,S as _,f as L,g as a}from"./Di3biKPp.js";function H(s,F={}){const{starCount:m=1e4,tunnelLength:f=200}=F,n=new U,u=new Float32Array(m*3),c=new Float32Array(m*3),w=new Float32Array(m),B=[];for(let e=0;e<m;e++){u[e*3]=(Math.random()-.5)*100,u[e*3+1]=(Math.random()-.5)*100,u[e*3+2]=(Math.random()-.5)*f;const r=new S().setHSL(Math.random()*.2+.5,.8,.6);c[e*3]=r.r,c[e*3+1]=r.g,c[e*3+2]=r.b,w[e]=50+Math.random()*100,B.push({x:u[e*3],y:u[e*3+1],z:u[e*3+2]})}n.setAttribute("position",new b(u,3)),n.setAttribute("color",new b(c,3)),n.setAttribute("speed",new b(w,1));const p=new D({size:3,vertexColors:!0,transparent:!0,opacity:0,blending:h,depthWrite:!1}),M=new W(n,p);s.add(M);const C=new T(40,40,f,32,20,!0),l=new A({uniforms:{uTime:{value:0},uSpeed:{value:1},uColor:{value:new S(43775)}},vertexShader:`
      uniform float uTime;
      uniform float uSpeed;
      varying vec2 vUv;
      varying float vDist;

      void main() {
        vUv = uv;
        vec3 pos = position;
        vDist = uv.y;

        // 螺旋扭曲效果
        float twist = uv.y * uSpeed * 0.5 + uTime * 5.0;
        float angle = atan(pos.z, pos.x) + twist;

        // 呼吸效果
        float breathe = sin(uTime * 10.0 + uv.y * 10.0) * 5.0;
        pos.x = cos(angle) * (40.0 + breathe);
        pos.z = sin(angle) * (40.0 + breathe);

        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform float uSpeed;
      uniform vec3 uColor;
      varying vec2 vUv;
      varying float vDist;

      void main() {
        // 条纹效果
        float stripe = sin(vUv.y * 50.0 + uTime * 20.0 * uSpeed) * 0.5 + 0.5;
        float alpha = stripe * 0.3;

        // 边缘发光
        float edge = 1.0 - abs(vUv.x - 0.5) * 2.0;
        alpha *= edge;

        // 距离衰减
        float fade = 1.0 - smoothstep(0.3, 0.7, abs(vDist - 0.5) * 2.0);
        alpha *= fade;

        // 颜色变化
        vec3 color = uColor * (1.0 + stripe * 0.5);
        color += vec3(0.5, 0.7, 1.0) * stripe * 0.3;

        gl_FragColor = vec4(color, alpha);
      }
    `,transparent:!0,side:N,blending:h,depthWrite:!1}),v=new x(C,l);v.rotation.x=Math.PI/2,v.scale.setScalar(0),s.add(v);const z=new _(30,32,32),P=new A({uniforms:{uTime:{value:0},uColor:{value:new S(65535)}},vertexShader:`
      uniform float uTime;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        vNormal = normalize(normalMatrix * normal);
        vPos = position;
        vec3 pos = position;
        float wave = sin(uTime * 15.0 + length(pos) * 0.5) * 2.0;
        pos += normal * wave;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor;
      varying vec3 vNormal;
      varying vec3 vPos;

      void main() {
        float fresnel = pow(1.0 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 3.0);
        float pulse = sin(uTime * 20.0) * 0.3 + 0.7;
        vec3 color = uColor * pulse;
        color += vec3(0.8, 0.9, 1.0) * fresnel * 0.5;
        gl_FragColor = vec4(color, fresnel * 0.8);
      }
    `,transparent:!0,blending:h,depthWrite:!1}),t=new x(z,P);t.scale.setScalar(0),s.add(t);const y=[],G=50;for(let e=0;e<G;e++){const r=new T(.1,.1,200,4),g=new L({color:16777215,transparent:!0,opacity:0,blending:h}),i=new x(r,g);i.position.set((Math.random()-.5)*80,(Math.random()-.5)*80,0),i.visible=!1,s.add(i),y.push(i)}let d=1;return{stars:M,starGeometry:n,tunnel:v,energyField:t,speedLines:y,update(e,r){d+=(d-l.uniforms.uSpeed.value)*e*2,l.uniforms.uSpeed.value=d,l.uniforms.uTime.value=r,t.material.uniforms.uTime.value=r;const i=n.attributes.position.array;for(let o=0;o<m;o++)p.opacity>0&&(i[o*3+2]+=w[o]*e*d,i[o*3+2]>f/2&&(i[o*3+2]=-f/2,i[o*3]=(Math.random()-.5)*100,i[o*3+1]=(Math.random()-.5)*100));n.attributes.position.needsUpdate=!0,y.forEach((o,j)=>{o.visible&&o.material.opacity>0?(o.position.z+=300*e*d,o.material.opacity-=e*.5,(o.position.z>100||o.material.opacity<=0)&&(o.visible=!1,o.position.z=-100,o.position.x=(Math.random()-.5)*80,o.position.y=(Math.random()-.5)*80)):Math.random()<.1*d&&(o.visible=!0,o.material.opacity=.8)})},animate(e,r){const g=a.timeline({onComplete:r});return a.to(v.scale,{x:1,y:1,z:1,duration:.5,ease:"power2.out"}),a.to(p,{opacity:.8,duration:.5}),a.to(t.scale,{x:1,y:1,z:1,duration:.3,delay:.5}),d=1,a.to(l.uniforms.uSpeed,{value:10,duration:1,delay:.5,ease:"power2.in"}),a.to(t.material.uniforms.uColor.value,{r:.5,g:.2,b:1,duration:.5,delay:1}),a.to(l.uniforms.uSpeed,{value:25,duration:1.5,delay:1.5,ease:"power3.in"}),a.to(t.scale,{x:2,y:2,z:2,duration:1.5,delay:1.5,ease:"power3.in"}),a.to(p,{size:8,duration:1.5,delay:1.5}),a.to(l.uniforms.uSpeed,{value:2,duration:2,delay:3,ease:"power2.out"}),a.to(t.scale,{x:.5,y:.5,z:.5,duration:2,delay:3,ease:"power2.out"}),a.to(t.material.uniforms.uColor.value,{r:0,g:1,b:1,duration:2,delay:3}),a.to(p,{size:3,duration:2,delay:3}),g},destroy(){s.remove(M),s.remove(v),s.remove(t),y.forEach(e=>{s.remove(e),e.geometry.dispose(),e.material.dispose()}),n.dispose(),p.dispose(),C.dispose(),l.dispose(),z.dispose(),P.dispose()}}}export{H as createHyperspaceWarpDrive};

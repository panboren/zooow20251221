import{C as c,G,a$ as S,a9 as T,A as P,D as U,b as E,B,c as M,P as D,d as L,g as w}from"./Di3biKPp.js";function j(d,A={}){const{wingCount:W=8,featherCount:s=15,wingSpan:i=60,featherLength:x=12}=A,p=[new c(16777215),new c(16775388),new c(16770273),new c(15132410),new c(16775885)],l=[],h=[];for(let o=0;o<W;o++){const t=new G,e=p[o%p.length],n=[];for(let a=0;a<s;a++){const g=a/s*Math.PI*.8-Math.PI*.4,I=a/s*i*.5,z=(a/s-.5)*x*2,k=new S(x*(1-a/s*.5),x*.15,16,4),F=new T({uniforms:{uTime:{value:0},uColor:{value:e},uFeatherIndex:{value:a},uWingIndex:{value:o}},vertexShader:`
          uniform float uTime;
          uniform float uFeatherIndex;
          uniform float uWingIndex;
          varying vec2 vUv;
          varying vec3 vPosition;
          varying float vWave;

          void main() {
            vUv = uv;
            vPosition = position;
            
            // 羽毛波动
            float wave1 = sin(position.x * 2.0 + uTime * 3.0 + uFeatherIndex * 0.5);
            float wave2 = sin(position.y * 3.0 + uTime * 4.0 + uWingIndex * 0.3);
            vWave = wave1 + wave2;
            
            vec3 pos = position;
            pos.z += vWave * 0.3;
            pos.x += sin(uTime * 2.0 + uWingIndex) * 0.2;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
          }
        `,fragmentShader:`
          uniform float uTime;
          uniform vec3 uColor;
          uniform float uFeatherIndex;
          uniform float uWingIndex;
          
          varying vec2 vUv;
          varying vec3 vPosition;
          varying float vWave;

          void main() {
            // 羽毛渐变
            float gradient = smoothstep(0.0, 1.0, vUv.x);
            
            // 光泽
            float shine = pow(1.0 - abs(vUv.y - 0.5) * 2.0, 3.0);
            
            // 流动光效
            float flow = sin(vUv.x * 10.0 - uTime * 2.0 + vWave) * 0.5 + 0.5;
            
            // 梦幻色彩
            vec3 color = uColor;
            color += vec3(0.5, 0.6, 1.0) * flow * 0.3;
            color += vec3(1.0, 0.9, 0.8) * shine * 0.5;
            
            // 透明度
            float alpha = (1.0 - gradient * 0.8) * (0.6 + flow * 0.3);
            
            gl_FragColor = vec4(color, alpha);
          }
        `,transparent:!0,side:U,depthWrite:!1,blending:P}),v=new E(k,F);v.position.set(Math.cos(g)*I,z,Math.sin(g)*I*.3),v.rotation.z=g,v.rotation.x=(a/s-.5)*.5,t.add(v),n.push(v)}t.position.y=-i*.3+o*8,t.rotation.y=o/W*Math.PI*2,d.add(t),l.push(t),h.push(n)}const f=300,r=new B,m=new Float32Array(f*3),y=new Float32Array(f*3),b=new Float32Array(f);for(let o=0;o<f;o++){m[o*3]=(Math.random()-.5)*i*2,m[o*3+1]=(Math.random()-.5)*i,m[o*3+2]=(Math.random()-.5)*i;const t=p[Math.floor(Math.random()*p.length)];y[o*3]=t.r,y[o*3+1]=t.g,y[o*3+2]=t.b,b[o]=Math.random()*1.5+.3}r.setAttribute("position",new M(m,3)),r.setAttribute("color",new M(y,3)),r.setAttribute("size",new M(b,1));const C=new D({size:1,vertexColors:!0,transparent:!0,opacity:.7,blending:P,depthWrite:!1,sizeAttenuation:!0}),u=new L(r,C);return d.add(u),{wings:l,featherGroups:h,sparkles:u,sparkleGeometry:r,update(o){l.forEach((e,n)=>{h[n].forEach((a,g)=>{a.material.uniforms.uTime.value=o}),e.rotation.y+=o*.02,e.position.y+=Math.sin(o+n)*.01});const t=r.attributes.position.array;for(let e=0;e<f;e++)t[e*3+1]+=Math.sin(o*2+e)*.02,t[e*3+1]>i/2&&(t[e*3+1]=-i/2);r.attributes.position.needsUpdate=!0,u.rotation.y=o*.01},animate(o,t){const e=w.timeline({onComplete:t});return l.forEach((n,a)=>{w.to(n.scale,{x:0,y:0,z:0,duration:0,ease:"none"}),w.to(n.scale,{x:1,y:1,z:1,duration:1,delay:a*.1,ease:"back.out(1.7)"})}),l.forEach((n,a)=>{w.to(n.rotation,{z:a%2===0?.5:-.5,duration:2,delay:.5,ease:"sine.inOut",yoyo:!0,repeat:1})}),e.to(u.material,{opacity:1,duration:.3,ease:"power2.out"},0),e.to(u.material,{opacity:.5,duration:1,ease:"power2.in"},.3),e},destroy(){l.forEach((o,t)=>{h[t].forEach(e=>{o.remove(e),e.geometry.dispose(),e.material.dispose()}),d.remove(o)}),d.remove(u),r.dispose(),C.dispose()}}}export{j as createLightWings};

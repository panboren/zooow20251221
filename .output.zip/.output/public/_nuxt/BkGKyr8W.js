import{C as A,B as j,c as C,cM as q,P as R,A as U,d as V,S as k,a9 as D,b as E,cA as H,g as J}from"./Di3biKPp.js";function Q(n,W={}){const{particleCount:u=5e3,radius:y=30,height:z=60,color1:h=new A(16729344),color2:g=new A(16753920),color3:S=new A(16776960)}=W,s=new j,p=new Float32Array(u*3),M=new Float32Array(u*3),P=new Float32Array(u),f=[],v=[];for(let o=0;o<u;o++){const a=Math.random()*Math.PI*2,e=Math.random()*y;p[o*3]=Math.cos(a)*e,p[o*3+1]=Math.random()*5-2.5,p[o*3+2]=Math.sin(a)*e;const l=Math.random();let t;l<.33?t=h:l<.66?t=g:t=S,M[o*3]=t.r,M[o*3+1]=t.g,M[o*3+2]=t.b,P[o]=Math.random()*3+1,f.push({x:(Math.random()-.5)*.5,y:Math.random()*.5+.5,z:(Math.random()-.5)*.5}),v.push(Math.random())}s.setAttribute("position",new C(p,3)),s.setAttribute("color",new C(M,3)),s.setAttribute("size",new C(P,1));const _=new q().load("textures/particle.png"),m=new R({size:2,vertexColors:!0,map:_,transparent:!0,opacity:.8,blending:U,depthWrite:!1,sizeAttenuation:!0}),r=new V(s,m);n.add(r);const F=new k(10,32,32),N=new D({uniforms:{uTime:{value:0},uColor1:{value:h},uColor2:{value:g}},vertexShader:`
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(vec3(normalMatrix * vec4(normal, 0.0)));
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,fragmentShader:`
      uniform float uTime;
      uniform vec3 uColor1;
      uniform vec3 uColor2;
      varying vec3 vNormal;

      // 简单噪声
      float random(vec2 st) {
        return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
      }

      void main() {
        float intensity = dot(vNormal, vec3(0.0, 1.0, 0.0));
        vec3 color = mix(uColor1, uColor2, intensity * 0.5 + 0.5);

        // 添加动态效果
        float noise = random(vNormal.xy + uTime);
        color *= (0.8 + noise * 0.4);

        gl_FragColor = vec4(color, 0.6);
      }
    `,transparent:!0,blending:U}),i=new E(F,N);n.add(i);const d=new H(h,3,100);return d.position.set(0,z/2,0),n.add(d),{particles:r,core:i,light:d,geometry:s,material:m,update(o,a){const e=r.geometry.attributes.position.array,l=r.geometry.attributes.color.array;for(let t=0;t<u;t++){e[t*3]+=f[t].x*o*10,e[t*3+1]+=f[t].y*o*20,e[t*3+2]+=f[t].z*o*10;const w=e[t*3],x=e[t*3+2],b=Math.sqrt(w*w+x*x),B=Math.atan2(x,w),L=(1-b/y)*o*2;if(e[t*3]=Math.cos(B+L)*b,e[t*3+2]=Math.sin(B+L)*b,v[t]-=o*.5,v[t]<0||e[t*3+1]>z){const G=Math.random()*Math.PI*2,I=Math.random()*y;e[t*3]=Math.cos(G)*I,e[t*3+1]=-5,e[t*3+2]=Math.sin(G)*I,v[t]=Math.random();const T=Math.random();let c;T<.33?c=h:T<.66?c=g:c=S,l[t*3]=c.r,l[t*3+1]=c.g,l[t*3+2]=c.b}}r.geometry.attributes.position.needsUpdate=!0,r.geometry.attributes.color.needsUpdate=!0,r.rotation.y+=o*.5,i.material.uniforms.uTime.value=a,i.scale.setScalar(1+Math.sin(a*3)*.1),d.intensity=3+Math.sin(a*5)*1},animate(o,a){const e=J.timeline({onComplete:a});return e.to(m,{size:5,duration:o*.2,ease:"power2.in"}),e.to(m,{size:2,duration:o*.8,ease:"power2.out"}),e.to(i.scale,{x:1.5,y:1.5,z:1.5,duration:o*.3,ease:"power2.in",yoyo:!0,repeat:1},"<"),e},destroy(){n.remove(r),n.remove(i),n.remove(d),s.dispose(),m.dispose(),F.dispose(),N.dispose()}}}export{Q as createFireStorm};

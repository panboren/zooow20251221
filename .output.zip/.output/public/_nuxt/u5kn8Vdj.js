import{U as Tt,i as ir,N as At,j as ar,C as Je,F as xa,k as Yt,V as Be,R as rr,l as Qe,w as Ye,m as pt,n as fi,o as Vn,W as di,p as Pt,q as it,r as en,H as wt,D as bt,s as St,t as an,u as xn,v as or,x as rn,y as qt,b as It,B as Mn,O as Ma,z as pn,E as Ta,f as sr,I as ui,J as lr,K as Ze,Q as cr,X as ht,Y as fr,Z as Ln,_ as Ct,$ as Xt,a0 as Kt,a1 as on,a2 as Vt,a3 as vn,a4 as dr,a5 as ur,a6 as sn,a7 as vt,a8 as Wn,a9 as Nt,aa as Ut,ab as Tn,c as hn,ac as zt,ad as Sn,ae as pr,af as hr,ag as Qt,ah as mr,ai as _r,aj as gr,ak as vr,al as Sr,am as Er,an as xr,ao as Mr,ap as Tr,aq as Ar,ar as Rr,as as br,at as Cr,au as Pr,av as Lr,aw as Dr,ax as Ur,ay as Dn,az as fn,aA as wr,aB as Ht,aC as Ir,aD as Nr,aE as ei,aF as yr,aG as ti,aH as Fr,aI as Or,aJ as Br,aK as Gr,aL as Fe,aM as Hr,aN as Vr,aO as mn,aP as Wr,aQ as tn,aR as Lt,aS as Aa,aT as kr,aU as Ra,aV as ba,aW as Ca,aX as En,aY as Pa,aZ as La,a_ as Da,a$ as Ua,b0 as zr,b1 as Xr,b2 as Yr,b3 as qr,b4 as wa,b5 as Kr,b6 as $r,b7 as Zr,b8 as Un,b9 as wn,ba as In,bb as Nn,bc as pi,bd as hi,be as mi,bf as _i,bg as gi,bh as vi,bi as Si,bj as Ei,bk as xi,bl as Mi,bm as Ti,bn as Ai,bo as Ri,bp as bi,bq as Ci,br as Pi,bs as Li,bt as Di,bu as Ui,bv as wi,bw as Ii,bx as Ni,by as yi,bz as Fi,bA as Oi,bB as Bi,bC as Gi,bD as Hi,bE as Vi,bF as Wi,bG as ki,bH as zi,bI as kn,bJ as zn,bK as Xn,bL as Yn,bM as qn,bN as Kn,bO as $n,bP as Qr,bQ as Xi,bR as Jr,bS as _n,bT as jr,bU as Yi,bV as qi,A as Ki,bW as Zn,bX as Qn,bY as Ia,bZ as eo,b_ as ut,b$ as to,c0 as no,c1 as Na,c2 as $i,c3 as ya,c4 as Fa,c5 as Oa,c6 as Ba,c7 as Ga,c8 as Ha,c9 as Va,ca as Wa,cb as Zi,cc as ka,cd as io,ce as ao,cf as ro,cg as Qi,ch as oo,ci as so,cj as lo,ck as co,cl as fo,cm as uo,cn as po,co as ho,cp as mo,cq as _o}from"./Di3biKPp.js";/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function za(){let e=null,n=!1,t=null,i=null;function l(r,h){t(r,h),i=e.requestAnimationFrame(l)}return{start:function(){n!==!0&&t!==null&&(i=e.requestAnimationFrame(l),n=!0)},stop:function(){e.cancelAnimationFrame(i),n=!1},setAnimationLoop:function(r){t=r},setContext:function(r){e=r}}}function go(e){const n=new WeakMap;function t(d,b){const x=d.array,w=d.usage,g=x.byteLength,S=e.createBuffer();e.bindBuffer(b,S),e.bufferData(b,x,w),d.onUploadCallback();let R;if(x instanceof Float32Array)R=e.FLOAT;else if(typeof Float16Array<"u"&&x instanceof Float16Array)R=e.HALF_FLOAT;else if(x instanceof Uint16Array)d.isFloat16BufferAttribute?R=e.HALF_FLOAT:R=e.UNSIGNED_SHORT;else if(x instanceof Int16Array)R=e.SHORT;else if(x instanceof Uint32Array)R=e.UNSIGNED_INT;else if(x instanceof Int32Array)R=e.INT;else if(x instanceof Int8Array)R=e.BYTE;else if(x instanceof Uint8Array)R=e.UNSIGNED_BYTE;else if(x instanceof Uint8ClampedArray)R=e.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+x);return{buffer:S,type:R,bytesPerElement:x.BYTES_PER_ELEMENT,version:d.version,size:g}}function i(d,b,x){const w=b.array,g=b.updateRanges;if(e.bindBuffer(x,d),g.length===0)e.bufferSubData(x,0,w);else{g.sort((R,O)=>R.start-O.start);let S=0;for(let R=1;R<g.length;R++){const O=g[S],U=g[R];U.start<=O.start+O.count+1?O.count=Math.max(O.count,U.start+U.count-O.start):(++S,g[S]=U)}g.length=S+1;for(let R=0,O=g.length;R<O;R++){const U=g[R];e.bufferSubData(x,U.start*w.BYTES_PER_ELEMENT,w,U.start,U.count)}b.clearUpdateRanges()}b.onUploadCallback()}function l(d){return d.isInterleavedBufferAttribute&&(d=d.data),n.get(d)}function r(d){d.isInterleavedBufferAttribute&&(d=d.data);const b=n.get(d);b&&(e.deleteBuffer(b.buffer),n.delete(d))}function h(d,b){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const w=n.get(d);(!w||w.version<d.version)&&n.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const x=n.get(d);if(x===void 0)n.set(d,t(d,b));else if(x.version<d.version){if(x.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");i(x.buffer,d,b),x.version=d.version}}return{get:l,remove:r,update:h}}var vo=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,So=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Eo=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,xo=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Mo=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,To=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ao=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Ro=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,bo=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Co=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,Po=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Lo=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Do=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Uo=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,wo=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Io=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,No=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,yo=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Fo=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Oo=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Bo=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Go=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Ho=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Vo=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Wo=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,ko=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,zo=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Xo=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Yo=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,qo=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Ko="gl_FragColor = linearToOutputTexel( gl_FragColor );",$o=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,Zo=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,Qo=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,Jo=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,jo=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,es=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,ts=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,ns=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,is=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,as=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,rs=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,os=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,ss=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,ls=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,cs=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,fs=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,ds=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,us=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,ps=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,hs=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,ms=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,_s=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return v;
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( vec3( 1.0 ) - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,gs=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,vs=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,Ss=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,Es=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,xs=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ms=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,Ts=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,As=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,Rs=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,bs=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,Cs=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ps=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,Ls=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,Ds=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,Us=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,ws=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,Is=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Ns=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,ys=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Fs=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Os=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Bs=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Gs=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,Hs=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,Vs=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Ws=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,ks=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,zs=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,Xs=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,Ys=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,qs=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,Ks=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,$s=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,Zs=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,Qs=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Js=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,js=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * 6.28318530718;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * 6.28318530718;
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * vogelDiskSample( 0, 5, phi ).x + bitangent * vogelDiskSample( 0, 5, phi ).y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * vogelDiskSample( 1, 5, phi ).x + bitangent * vogelDiskSample( 1, 5, phi ).y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * vogelDiskSample( 2, 5, phi ).x + bitangent * vogelDiskSample( 2, 5, phi ).y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * vogelDiskSample( 3, 5, phi ).x + bitangent * vogelDiskSample( 3, 5, phi ).y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * vogelDiskSample( 4, 5, phi ).x + bitangent * vogelDiskSample( 4, 5, phi ).y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadow = step( depth, dp );
			#else
				shadow = step( dp, depth );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,el=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,tl=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,nl=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,il=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,al=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,rl=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,ol=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,sl=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,ll=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,cl=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,fl=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,dl=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,ul=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,pl=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,hl=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ml=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,_l=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const gl=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,vl=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Sl=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,El=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,xl=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Ml=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Tl=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Al=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Rl=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,bl=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,Cl=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,Pl=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ll=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Dl=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,Ul=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,wl=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Il=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Nl=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,yl=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Fl=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Ol=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Bl=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,Gl=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Hl=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Vl=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Wl=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,kl=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,zl=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Xl=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,Yl=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,ql=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Kl=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,$l=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Zl=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Pe={alphahash_fragment:vo,alphahash_pars_fragment:So,alphamap_fragment:Eo,alphamap_pars_fragment:xo,alphatest_fragment:Mo,alphatest_pars_fragment:To,aomap_fragment:Ao,aomap_pars_fragment:Ro,batching_pars_vertex:bo,batching_vertex:Co,begin_vertex:Po,beginnormal_vertex:Lo,bsdfs:Do,iridescence_fragment:Uo,bumpmap_pars_fragment:wo,clipping_planes_fragment:Io,clipping_planes_pars_fragment:No,clipping_planes_pars_vertex:yo,clipping_planes_vertex:Fo,color_fragment:Oo,color_pars_fragment:Bo,color_pars_vertex:Go,color_vertex:Ho,common:Vo,cube_uv_reflection_fragment:Wo,defaultnormal_vertex:ko,displacementmap_pars_vertex:zo,displacementmap_vertex:Xo,emissivemap_fragment:Yo,emissivemap_pars_fragment:qo,colorspace_fragment:Ko,colorspace_pars_fragment:$o,envmap_fragment:Zo,envmap_common_pars_fragment:Qo,envmap_pars_fragment:Jo,envmap_pars_vertex:jo,envmap_physical_pars_fragment:fs,envmap_vertex:es,fog_vertex:ts,fog_pars_vertex:ns,fog_fragment:is,fog_pars_fragment:as,gradientmap_pars_fragment:rs,lightmap_pars_fragment:os,lights_lambert_fragment:ss,lights_lambert_pars_fragment:ls,lights_pars_begin:cs,lights_toon_fragment:ds,lights_toon_pars_fragment:us,lights_phong_fragment:ps,lights_phong_pars_fragment:hs,lights_physical_fragment:ms,lights_physical_pars_fragment:_s,lights_fragment_begin:gs,lights_fragment_maps:vs,lights_fragment_end:Ss,logdepthbuf_fragment:Es,logdepthbuf_pars_fragment:xs,logdepthbuf_pars_vertex:Ms,logdepthbuf_vertex:Ts,map_fragment:As,map_pars_fragment:Rs,map_particle_fragment:bs,map_particle_pars_fragment:Cs,metalnessmap_fragment:Ps,metalnessmap_pars_fragment:Ls,morphinstance_vertex:Ds,morphcolor_vertex:Us,morphnormal_vertex:ws,morphtarget_pars_vertex:Is,morphtarget_vertex:Ns,normal_fragment_begin:ys,normal_fragment_maps:Fs,normal_pars_fragment:Os,normal_pars_vertex:Bs,normal_vertex:Gs,normalmap_pars_fragment:Hs,clearcoat_normal_fragment_begin:Vs,clearcoat_normal_fragment_maps:Ws,clearcoat_pars_fragment:ks,iridescence_pars_fragment:zs,opaque_fragment:Xs,packing:Ys,premultiplied_alpha_fragment:qs,project_vertex:Ks,dithering_fragment:$s,dithering_pars_fragment:Zs,roughnessmap_fragment:Qs,roughnessmap_pars_fragment:Js,shadowmap_pars_fragment:js,shadowmap_pars_vertex:el,shadowmap_vertex:tl,shadowmask_pars_fragment:nl,skinbase_vertex:il,skinning_pars_vertex:al,skinning_vertex:rl,skinnormal_vertex:ol,specularmap_fragment:sl,specularmap_pars_fragment:ll,tonemapping_fragment:cl,tonemapping_pars_fragment:fl,transmission_fragment:dl,transmission_pars_fragment:ul,uv_pars_fragment:pl,uv_pars_vertex:hl,uv_vertex:ml,worldpos_vertex:_l,background_vert:gl,background_frag:vl,backgroundCube_vert:Sl,backgroundCube_frag:El,cube_vert:xl,cube_frag:Ml,depth_vert:Tl,depth_frag:Al,distance_vert:Rl,distance_frag:bl,equirect_vert:Cl,equirect_frag:Pl,linedashed_vert:Ll,linedashed_frag:Dl,meshbasic_vert:Ul,meshbasic_frag:wl,meshlambert_vert:Il,meshlambert_frag:Nl,meshmatcap_vert:yl,meshmatcap_frag:Fl,meshnormal_vert:Ol,meshnormal_frag:Bl,meshphong_vert:Gl,meshphong_frag:Hl,meshphysical_vert:Vl,meshphysical_frag:Wl,meshtoon_vert:kl,meshtoon_frag:zl,points_vert:Xl,points_frag:Yl,shadow_vert:ql,shadow_frag:Kl,sprite_vert:$l,sprite_frag:Zl},re={common:{diffuse:{value:new Je(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Fe},alphaMap:{value:null},alphaMapTransform:{value:new Fe},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Fe}},envmap:{envMap:{value:null},envMapRotation:{value:new Fe},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Fe}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Fe}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Fe},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Fe},normalScale:{value:new ht(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Fe},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Fe}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Fe}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Fe}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Je(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Je(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Fe},alphaTest:{value:0},uvTransform:{value:new Fe}},sprite:{diffuse:{value:new Je(16777215)},opacity:{value:1},center:{value:new ht(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Fe},alphaMap:{value:null},alphaMapTransform:{value:new Fe},alphaTest:{value:0}}},Mt={basic:{uniforms:ut([re.common,re.specularmap,re.envmap,re.aomap,re.lightmap,re.fog]),vertexShader:Pe.meshbasic_vert,fragmentShader:Pe.meshbasic_frag},lambert:{uniforms:ut([re.common,re.specularmap,re.envmap,re.aomap,re.lightmap,re.emissivemap,re.bumpmap,re.normalmap,re.displacementmap,re.fog,re.lights,{emissive:{value:new Je(0)}}]),vertexShader:Pe.meshlambert_vert,fragmentShader:Pe.meshlambert_frag},phong:{uniforms:ut([re.common,re.specularmap,re.envmap,re.aomap,re.lightmap,re.emissivemap,re.bumpmap,re.normalmap,re.displacementmap,re.fog,re.lights,{emissive:{value:new Je(0)},specular:{value:new Je(1118481)},shininess:{value:30}}]),vertexShader:Pe.meshphong_vert,fragmentShader:Pe.meshphong_frag},standard:{uniforms:ut([re.common,re.envmap,re.aomap,re.lightmap,re.emissivemap,re.bumpmap,re.normalmap,re.displacementmap,re.roughnessmap,re.metalnessmap,re.fog,re.lights,{emissive:{value:new Je(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Pe.meshphysical_vert,fragmentShader:Pe.meshphysical_frag},toon:{uniforms:ut([re.common,re.aomap,re.lightmap,re.emissivemap,re.bumpmap,re.normalmap,re.displacementmap,re.gradientmap,re.fog,re.lights,{emissive:{value:new Je(0)}}]),vertexShader:Pe.meshtoon_vert,fragmentShader:Pe.meshtoon_frag},matcap:{uniforms:ut([re.common,re.bumpmap,re.normalmap,re.displacementmap,re.fog,{matcap:{value:null}}]),vertexShader:Pe.meshmatcap_vert,fragmentShader:Pe.meshmatcap_frag},points:{uniforms:ut([re.points,re.fog]),vertexShader:Pe.points_vert,fragmentShader:Pe.points_frag},dashed:{uniforms:ut([re.common,re.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Pe.linedashed_vert,fragmentShader:Pe.linedashed_frag},depth:{uniforms:ut([re.common,re.displacementmap]),vertexShader:Pe.depth_vert,fragmentShader:Pe.depth_frag},normal:{uniforms:ut([re.common,re.bumpmap,re.normalmap,re.displacementmap,{opacity:{value:1}}]),vertexShader:Pe.meshnormal_vert,fragmentShader:Pe.meshnormal_frag},sprite:{uniforms:ut([re.sprite,re.fog]),vertexShader:Pe.sprite_vert,fragmentShader:Pe.sprite_frag},background:{uniforms:{uvTransform:{value:new Fe},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Pe.background_vert,fragmentShader:Pe.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Fe}},vertexShader:Pe.backgroundCube_vert,fragmentShader:Pe.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Pe.cube_vert,fragmentShader:Pe.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Pe.equirect_vert,fragmentShader:Pe.equirect_frag},distance:{uniforms:ut([re.common,re.displacementmap,{referencePosition:{value:new Be},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Pe.distance_vert,fragmentShader:Pe.distance_frag},shadow:{uniforms:ut([re.lights,re.fog,{color:{value:new Je(0)},opacity:{value:1}}]),vertexShader:Pe.shadow_vert,fragmentShader:Pe.shadow_frag}};Mt.physical={uniforms:ut([Mt.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Fe},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Fe},clearcoatNormalScale:{value:new ht(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Fe},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Fe},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Fe},sheen:{value:0},sheenColor:{value:new Je(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Fe},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Fe},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Fe},transmissionSamplerSize:{value:new ht},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Fe},attenuationDistance:{value:0},attenuationColor:{value:new Je(0)},specularColor:{value:new Je(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Fe},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Fe},anisotropyVector:{value:new ht},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Fe}}]),vertexShader:Pe.meshphysical_vert,fragmentShader:Pe.meshphysical_frag};const dn={r:0,b:0,g:0},Ot=new ya,Ql=new Yt;function Jl(e,n,t,i,l,r,h){const d=new Je(0);let b=r===!0?0:1,x,w,g=null,S=0,R=null;function O(M){let A=M.isScene===!0?M.background:null;return A&&A.isTexture&&(A=(M.backgroundBlurriness>0?t:n).get(A)),A}function U(M){let A=!1;const C=O(M);C===null?o(d,b):C&&C.isColor&&(o(C,1),A=!0);const T=e.xr.getEnvironmentBlendMode();T==="additive"?i.buffers.color.setClear(0,0,0,1,h):T==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,h),(e.autoClear||A)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function f(M,A){const C=O(A);C&&(C.isCubeTexture||C.mapping===Tn)?(w===void 0&&(w=new It(new Ta(1,1,1),new Nt({name:"BackgroundCubeMaterial",uniforms:$i(Mt.backgroundCube.uniforms),vertexShader:Mt.backgroundCube.vertexShader,fragmentShader:Mt.backgroundCube.fragmentShader,side:St,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),w.geometry.deleteAttribute("normal"),w.geometry.deleteAttribute("uv"),w.onBeforeRender=function(T,N,q){this.matrixWorld.copyPosition(q.matrixWorld)},Object.defineProperty(w.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),l.update(w)),Ot.copy(A.backgroundRotation),Ot.x*=-1,Ot.y*=-1,Ot.z*=-1,C.isCubeTexture&&C.isRenderTargetTexture===!1&&(Ot.y*=-1,Ot.z*=-1),w.material.uniforms.envMap.value=C,w.material.uniforms.flipEnvMap.value=C.isCubeTexture&&C.isRenderTargetTexture===!1?-1:1,w.material.uniforms.backgroundBlurriness.value=A.backgroundBlurriness,w.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,w.material.uniforms.backgroundRotation.value.setFromMatrix4(Ql.makeRotationFromEuler(Ot)),w.material.toneMapped=it.getTransfer(C.colorSpace)!==Ze,(g!==C||S!==C.version||R!==e.toneMapping)&&(w.material.needsUpdate=!0,g=C,S=C.version,R=e.toneMapping),w.layers.enableAll(),M.unshift(w,w.geometry,w.material,0,0,null)):C&&C.isTexture&&(x===void 0&&(x=new It(new Ua(2,2),new Nt({name:"BackgroundMaterial",uniforms:$i(Mt.background.uniforms),vertexShader:Mt.background.vertexShader,fragmentShader:Mt.background.fragmentShader,side:an,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),x.geometry.deleteAttribute("normal"),Object.defineProperty(x.material,"map",{get:function(){return this.uniforms.t2D.value}}),l.update(x)),x.material.uniforms.t2D.value=C,x.material.uniforms.backgroundIntensity.value=A.backgroundIntensity,x.material.toneMapped=it.getTransfer(C.colorSpace)!==Ze,C.matrixAutoUpdate===!0&&C.updateMatrix(),x.material.uniforms.uvTransform.value.copy(C.matrix),(g!==C||S!==C.version||R!==e.toneMapping)&&(x.material.needsUpdate=!0,g=C,S=C.version,R=e.toneMapping),x.layers.enableAll(),M.unshift(x,x.geometry,x.material,0,0,null))}function o(M,A){M.getRGB(dn,Na(e)),i.buffers.color.setClear(dn.r,dn.g,dn.b,A,h)}function P(){w!==void 0&&(w.geometry.dispose(),w.material.dispose(),w=void 0),x!==void 0&&(x.geometry.dispose(),x.material.dispose(),x=void 0)}return{getClearColor:function(){return d},setClearColor:function(M,A=1){d.set(M),b=A,o(d,b)},getClearAlpha:function(){return b},setClearAlpha:function(M){b=M,o(d,b)},render:U,addToRenderList:f,dispose:P}}function jl(e,n){const t=e.getParameter(e.MAX_VERTEX_ATTRIBS),i={},l=S(null);let r=l,h=!1;function d(p,L,W,G,z){let K=!1;const B=g(G,W,L);r!==B&&(r=B,x(r.object)),K=R(p,G,W,z),K&&O(p,G,W,z),z!==null&&n.update(z,e.ELEMENT_ARRAY_BUFFER),(K||h)&&(h=!1,A(p,L,W,G),z!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,n.get(z).buffer))}function b(){return e.createVertexArray()}function x(p){return e.bindVertexArray(p)}function w(p){return e.deleteVertexArray(p)}function g(p,L,W){const G=W.wireframe===!0;let z=i[p.id];z===void 0&&(z={},i[p.id]=z);let K=z[L.id];K===void 0&&(K={},z[L.id]=K);let B=K[G];return B===void 0&&(B=S(b()),K[G]=B),B}function S(p){const L=[],W=[],G=[];for(let z=0;z<t;z++)L[z]=0,W[z]=0,G[z]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:L,enabledAttributes:W,attributeDivisors:G,object:p,attributes:{},index:null}}function R(p,L,W,G){const z=r.attributes,K=L.attributes;let B=0;const V=W.getAttributes();for(const J in V)if(V[J].location>=0){const ge=z[J];let Ee=K[J];if(Ee===void 0&&(J==="instanceMatrix"&&p.instanceMatrix&&(Ee=p.instanceMatrix),J==="instanceColor"&&p.instanceColor&&(Ee=p.instanceColor)),ge===void 0||ge.attribute!==Ee||Ee&&ge.data!==Ee.data)return!0;B++}return r.attributesNum!==B||r.index!==G}function O(p,L,W,G){const z={},K=L.attributes;let B=0;const V=W.getAttributes();for(const J in V)if(V[J].location>=0){let ge=K[J];ge===void 0&&(J==="instanceMatrix"&&p.instanceMatrix&&(ge=p.instanceMatrix),J==="instanceColor"&&p.instanceColor&&(ge=p.instanceColor));const Ee={};Ee.attribute=ge,ge&&ge.data&&(Ee.data=ge.data),z[J]=Ee,B++}r.attributes=z,r.attributesNum=B,r.index=G}function U(){const p=r.newAttributes;for(let L=0,W=p.length;L<W;L++)p[L]=0}function f(p){o(p,0)}function o(p,L){const W=r.newAttributes,G=r.enabledAttributes,z=r.attributeDivisors;W[p]=1,G[p]===0&&(e.enableVertexAttribArray(p),G[p]=1),z[p]!==L&&(e.vertexAttribDivisor(p,L),z[p]=L)}function P(){const p=r.newAttributes,L=r.enabledAttributes;for(let W=0,G=L.length;W<G;W++)L[W]!==p[W]&&(e.disableVertexAttribArray(W),L[W]=0)}function M(p,L,W,G,z,K,B){B===!0?e.vertexAttribIPointer(p,L,W,z,K):e.vertexAttribPointer(p,L,W,G,z,K)}function A(p,L,W,G){U();const z=G.attributes,K=W.getAttributes(),B=L.defaultAttributeValues;for(const V in K){const J=K[V];if(J.location>=0){let xe=z[V];if(xe===void 0&&(V==="instanceMatrix"&&p.instanceMatrix&&(xe=p.instanceMatrix),V==="instanceColor"&&p.instanceColor&&(xe=p.instanceColor)),xe!==void 0){const ge=xe.normalized,Ee=xe.itemSize,Oe=n.get(xe);if(Oe===void 0)continue;const we=Oe.buffer,nt=Oe.type,je=Oe.bytesPerElement,k=nt===e.INT||nt===e.UNSIGNED_INT||xe.gpuType===wa;if(xe.isInterleavedBufferAttribute){const $=xe.data,fe=$.stride,Ce=xe.offset;if($.isInstancedInterleavedBuffer){for(let pe=0;pe<J.locationSize;pe++)o(J.location+pe,$.meshPerAttribute);p.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=$.meshPerAttribute*$.count)}else for(let pe=0;pe<J.locationSize;pe++)f(J.location+pe);e.bindBuffer(e.ARRAY_BUFFER,we);for(let pe=0;pe<J.locationSize;pe++)M(J.location+pe,Ee/J.locationSize,nt,ge,fe*je,(Ce+Ee/J.locationSize*pe)*je,k)}else{if(xe.isInstancedBufferAttribute){for(let $=0;$<J.locationSize;$++)o(J.location+$,xe.meshPerAttribute);p.isInstancedMesh!==!0&&G._maxInstanceCount===void 0&&(G._maxInstanceCount=xe.meshPerAttribute*xe.count)}else for(let $=0;$<J.locationSize;$++)f(J.location+$);e.bindBuffer(e.ARRAY_BUFFER,we);for(let $=0;$<J.locationSize;$++)M(J.location+$,Ee/J.locationSize,nt,ge,Ee*je,Ee/J.locationSize*$*je,k)}}else if(B!==void 0){const ge=B[V];if(ge!==void 0)switch(ge.length){case 2:e.vertexAttrib2fv(J.location,ge);break;case 3:e.vertexAttrib3fv(J.location,ge);break;case 4:e.vertexAttrib4fv(J.location,ge);break;default:e.vertexAttrib1fv(J.location,ge)}}}}P()}function C(){q();for(const p in i){const L=i[p];for(const W in L){const G=L[W];for(const z in G)w(G[z].object),delete G[z];delete L[W]}delete i[p]}}function T(p){if(i[p.id]===void 0)return;const L=i[p.id];for(const W in L){const G=L[W];for(const z in G)w(G[z].object),delete G[z];delete L[W]}delete i[p.id]}function N(p){for(const L in i){const W=i[L];if(W[p.id]===void 0)continue;const G=W[p.id];for(const z in G)w(G[z].object),delete G[z];delete W[p.id]}}function q(){c(),h=!0,r!==l&&(r=l,x(r.object))}function c(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:d,reset:q,resetDefaultState:c,dispose:C,releaseStatesOfGeometry:T,releaseStatesOfProgram:N,initAttributes:U,enableAttribute:f,disableUnusedAttributes:P}}function ec(e,n,t){let i;function l(x){i=x}function r(x,w){e.drawArrays(i,x,w),t.update(w,i,1)}function h(x,w,g){g!==0&&(e.drawArraysInstanced(i,x,w,g),t.update(w,i,g))}function d(x,w,g){if(g===0)return;n.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,x,0,w,0,g);let R=0;for(let O=0;O<g;O++)R+=w[O];t.update(R,i,1)}function b(x,w,g,S){if(g===0)return;const R=n.get("WEBGL_multi_draw");if(R===null)for(let O=0;O<x.length;O++)h(x[O],w[O],S[O]);else{R.multiDrawArraysInstancedWEBGL(i,x,0,w,0,S,0,g);let O=0;for(let U=0;U<g;U++)O+=w[U]*S[U];t.update(O,i,1)}}this.setMode=l,this.render=r,this.renderInstances=h,this.renderMultiDraw=d,this.renderMultiDrawInstances=b}function tc(e,n,t,i){let l;function r(){if(l!==void 0)return l;if(n.has("EXT_texture_filter_anisotropic")===!0){const N=n.get("EXT_texture_filter_anisotropic");l=e.getParameter(N.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function h(N){return!(N!==Ct&&i.convert(N)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(N){const q=N===wt&&(n.has("EXT_color_buffer_half_float")||n.has("EXT_color_buffer_float"));return!(N!==Tt&&i.convert(N)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)&&N!==Lt&&!q)}function b(N){if(N==="highp"){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return"highp";N="mediump"}return N==="mediump"&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let x=t.precision!==void 0?t.precision:"highp";const w=b(x);w!==x&&(Ye("WebGLRenderer:",x,"not supported, using",w,"instead."),x=w);const g=t.logarithmicDepthBuffer===!0,S=t.reversedDepthBuffer===!0&&n.has("EXT_clip_control"),R=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),O=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),U=e.getParameter(e.MAX_TEXTURE_SIZE),f=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),o=e.getParameter(e.MAX_VERTEX_ATTRIBS),P=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),M=e.getParameter(e.MAX_VARYING_VECTORS),A=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),C=e.getParameter(e.MAX_SAMPLES),T=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:r,getMaxPrecision:b,textureFormatReadable:h,textureTypeReadable:d,precision:x,logarithmicDepthBuffer:g,reversedDepthBuffer:S,maxTextures:R,maxVertexTextures:O,maxTextureSize:U,maxCubemapSize:f,maxAttributes:o,maxVertexUniforms:P,maxVaryings:M,maxFragmentUniforms:A,maxSamples:C,samples:T}}function nc(e){const n=this;let t=null,i=0,l=!1,r=!1;const h=new Gr,d=new Fe,b={value:null,needsUpdate:!1};this.uniform=b,this.numPlanes=0,this.numIntersection=0,this.init=function(g,S){const R=g.length!==0||S||i!==0||l;return l=S,i=g.length,R},this.beginShadows=function(){r=!0,w(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(g,S){t=w(g,S,0)},this.setState=function(g,S,R){const O=g.clippingPlanes,U=g.clipIntersection,f=g.clipShadows,o=e.get(g);if(!l||O===null||O.length===0||r&&!f)r?w(null):x();else{const P=r?0:i,M=P*4;let A=o.clippingState||null;b.value=A,A=w(O,S,M,R);for(let C=0;C!==M;++C)A[C]=t[C];o.clippingState=A,this.numIntersection=U?this.numPlanes:0,this.numPlanes+=P}};function x(){b.value!==t&&(b.value=t,b.needsUpdate=i>0),n.numPlanes=i,n.numIntersection=0}function w(g,S,R,O){const U=g!==null?g.length:0;let f=null;if(U!==0){if(f=b.value,O!==!0||f===null){const o=R+U*4,P=S.matrixWorldInverse;d.getNormalMatrix(P),(f===null||f.length<o)&&(f=new Float32Array(o));for(let M=0,A=R;M!==U;++M,A+=4)h.copy(g[M]).applyMatrix4(P,d),h.normal.toArray(f,A),f[A+3]=h.constant}b.value=f,b.needsUpdate=!0}return n.numPlanes=U,n.numIntersection=0,f}}function ic(e){let n=new WeakMap;function t(h,d){return d===Zn?h.mapping=rn:d===Qn&&(h.mapping=qt),h}function i(h){if(h&&h.isTexture){const d=h.mapping;if(d===Zn||d===Qn)if(n.has(h)){const b=n.get(h).texture;return t(b,h.mapping)}else{const b=h.image;if(b&&b.height>0){const x=new Aa(b.height);return x.fromEquirectangularTexture(e,h),n.set(h,x),h.addEventListener("dispose",l),t(x.texture,h.mapping)}else return null}}return h}function l(h){const d=h.target;d.removeEventListener("dispose",l);const b=n.get(d);b!==void 0&&(n.delete(d),b.dispose())}function r(){n=new WeakMap}return{get:i,dispose:r}}const Dt=4,Ji=[.125,.215,.35,.446,.526,.582],Gt=20,ac=256,Jt=new Ma,ji=new Je;let yn=null,Fn=0,On=0,Bn=!1;const rc=new Be;class ea{constructor(n){this._renderer=n,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(n,t=0,i=.1,l=100,r={}){const{size:h=256,position:d=rc}=r;yn=this._renderer.getRenderTarget(),Fn=this._renderer.getActiveCubeFace(),On=this._renderer.getActiveMipmapLevel(),Bn=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(h);const b=this._allocateTargets();return b.depthBuffer=!0,this._sceneToCubeUV(n,i,l,b,d),t>0&&this._blur(b,0,0,t),this._applyPMREM(b),this._cleanup(b),b}fromEquirectangular(n,t=null){return this._fromTexture(n,t)}fromCubemap(n,t=null){return this._fromTexture(n,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=ia(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=na(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(n){this._lodMax=Math.floor(Math.log2(n)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let n=0;n<this._lodMeshes.length;n++)this._lodMeshes[n].geometry.dispose()}_cleanup(n){this._renderer.setRenderTarget(yn,Fn,On),this._renderer.xr.enabled=Bn,n.scissorTest=!1,kt(n,0,0,n.width,n.height)}_fromTexture(n,t){n.mapping===rn||n.mapping===qt?this._setSize(n.image.length===0?16:n.image[0].width||n.image[0].image.width):this._setSize(n.image.width/4),yn=this._renderer.getRenderTarget(),Fn=this._renderer.getActiveCubeFace(),On=this._renderer.getActiveMipmapLevel(),Bn=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const i=t||this._allocateTargets();return this._textureToCubeUV(n,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){const n=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:vt,minFilter:vt,generateMipmaps:!1,type:wt,format:Ct,colorSpace:xn,depthBuffer:!1},l=ta(n,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==n||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=ta(n,t,i);const{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=oc(r)),this._blurMaterial=lc(r,n,t),this._ggxMaterial=sc(r,n,t)}return l}_compileMaterial(n){const t=new It(new Mn,n);this._renderer.compile(t,Jt)}_sceneToCubeUV(n,t,i,l,r){const b=new pn(90,1,t,i),x=[1,-1,1,1,1,1],w=[1,1,1,-1,-1,-1],g=this._renderer,S=g.autoClear,R=g.toneMapping;g.getClearColor(ji),g.toneMapping=At,g.autoClear=!1,g.state.buffers.depth.getReversed()&&(g.setRenderTarget(l),g.clearDepth(),g.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new It(new Ta,new sr({name:"PMREM.Background",side:St,depthWrite:!1,depthTest:!1})));const U=this._backgroundBox,f=U.material;let o=!1;const P=n.background;P?P.isColor&&(f.color.copy(P),n.background=null,o=!0):(f.color.copy(ji),o=!0);for(let M=0;M<6;M++){const A=M%3;A===0?(b.up.set(0,x[M],0),b.position.set(r.x,r.y,r.z),b.lookAt(r.x+w[M],r.y,r.z)):A===1?(b.up.set(0,0,x[M]),b.position.set(r.x,r.y,r.z),b.lookAt(r.x,r.y+w[M],r.z)):(b.up.set(0,x[M],0),b.position.set(r.x,r.y,r.z),b.lookAt(r.x,r.y,r.z+w[M]));const C=this._cubeSize;kt(l,A*C,M>2?C:0,C,C),g.setRenderTarget(l),o&&g.render(U,b),g.render(n,b)}g.toneMapping=R,g.autoClear=S,n.background=P}_textureToCubeUV(n,t){const i=this._renderer,l=n.mapping===rn||n.mapping===qt;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=ia()),this._cubemapMaterial.uniforms.flipEnvMap.value=n.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=na());const r=l?this._cubemapMaterial:this._equirectMaterial,h=this._lodMeshes[0];h.material=r;const d=r.uniforms;d.envMap.value=n;const b=this._cubeSize;kt(t,0,0,3*b,2*b),i.setRenderTarget(t),i.render(h,Jt)}_applyPMREM(n){const t=this._renderer,i=t.autoClear;t.autoClear=!1;const l=this._lodMeshes.length;for(let r=1;r<l;r++)this._applyGGXFilter(n,r-1,r);t.autoClear=i}_applyGGXFilter(n,t,i){const l=this._renderer,r=this._pingPongRenderTarget,h=this._ggxMaterial,d=this._lodMeshes[i];d.material=h;const b=h.uniforms,x=i/(this._lodMeshes.length-1),w=t/(this._lodMeshes.length-1),g=Math.sqrt(x*x-w*w),S=0+x*1.25,R=g*S,{_lodMax:O}=this,U=this._sizeLods[i],f=3*U*(i>O-Dt?i-O+Dt:0),o=4*(this._cubeSize-U);b.envMap.value=n.texture,b.roughness.value=R,b.mipInt.value=O-t,kt(r,f,o,3*U,2*U),l.setRenderTarget(r),l.render(d,Jt),b.envMap.value=r.texture,b.roughness.value=0,b.mipInt.value=O-i,kt(n,f,o,3*U,2*U),l.setRenderTarget(n),l.render(d,Jt)}_blur(n,t,i,l,r){const h=this._pingPongRenderTarget;this._halfBlur(n,h,t,i,l,"latitudinal",r),this._halfBlur(h,n,i,i,l,"longitudinal",r)}_halfBlur(n,t,i,l,r,h,d){const b=this._renderer,x=this._blurMaterial;h!=="latitudinal"&&h!=="longitudinal"&&Qe("blur direction must be either latitudinal or longitudinal!");const w=3,g=this._lodMeshes[l];g.material=x;const S=x.uniforms,R=this._sizeLods[i]-1,O=isFinite(r)?Math.PI/(2*R):2*Math.PI/(2*Gt-1),U=r/O,f=isFinite(r)?1+Math.floor(w*U):Gt;f>Gt&&Ye(`sigmaRadians, ${r}, is too large and will clip, as it requested ${f} samples when the maximum is set to ${Gt}`);const o=[];let P=0;for(let N=0;N<Gt;++N){const q=N/U,c=Math.exp(-q*q/2);o.push(c),N===0?P+=c:N<f&&(P+=2*c)}for(let N=0;N<o.length;N++)o[N]=o[N]/P;S.envMap.value=n.texture,S.samples.value=f,S.weights.value=o,S.latitudinal.value=h==="latitudinal",d&&(S.poleAxis.value=d);const{_lodMax:M}=this;S.dTheta.value=O,S.mipInt.value=M-i;const A=this._sizeLods[l],C=3*A*(l>M-Dt?l-M+Dt:0),T=4*(this._cubeSize-A);kt(t,C,T,3*A,2*A),b.setRenderTarget(t),b.render(g,Jt)}}function oc(e){const n=[],t=[],i=[];let l=e;const r=e-Dt+1+Ji.length;for(let h=0;h<r;h++){const d=Math.pow(2,l);n.push(d);let b=1/d;h>e-Dt?b=Ji[h-e+Dt-1]:h===0&&(b=0),t.push(b);const x=1/(d-2),w=-x,g=1+x,S=[w,w,g,w,g,g,w,w,g,g,w,g],R=6,O=6,U=3,f=2,o=1,P=new Float32Array(U*O*R),M=new Float32Array(f*O*R),A=new Float32Array(o*O*R);for(let T=0;T<R;T++){const N=T%3*2/3-1,q=T>2?0:-1,c=[N,q,0,N+2/3,q,0,N+2/3,q+1,0,N,q,0,N+2/3,q+1,0,N,q+1,0];P.set(c,U*O*T),M.set(S,f*O*T);const p=[T,T,T,T,T,T];A.set(p,o*O*T)}const C=new Mn;C.setAttribute("position",new hn(P,U)),C.setAttribute("uv",new hn(M,f)),C.setAttribute("faceIndex",new hn(A,o)),i.push(new It(C,null)),l>Dt&&l--}return{lodMeshes:i,sizeLods:n,sigmas:t}}function ta(e,n,t){const i=new Pt(e,n,t);return i.texture.mapping=Tn,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function kt(e,n,t,i,l){e.viewport.set(n,t,i,l),e.scissor.set(n,t,i,l)}function sc(e,n,t){return new Nt({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:ac,CUBEUV_TEXEL_WIDTH:1/n,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:An(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 3.2: Transform view direction to hemisphere configuration
				vec3 Vh = normalize(vec3(alpha * V.x, alpha * V.y, V.z));

				// Section 4.1: Orthonormal basis
				float lensq = Vh.x * Vh.x + Vh.y * Vh.y;
				vec3 T1 = lensq > 0.0 ? vec3(-Vh.y, Vh.x, 0.0) / sqrt(lensq) : vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(Vh, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + Vh.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * Vh;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:Ut,depthTest:!1,depthWrite:!1})}function lc(e,n,t){const i=new Float32Array(Gt),l=new Be(0,1,0);return new Nt({name:"SphericalGaussianBlur",defines:{n:Gt,CUBEUV_TEXEL_WIDTH:1/n,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:An(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ut,depthTest:!1,depthWrite:!1})}function na(){return new Nt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:An(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ut,depthTest:!1,depthWrite:!1})}function ia(){return new Nt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:An(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ut,depthTest:!1,depthWrite:!1})}function An(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function cc(e){let n=new WeakMap,t=null;function i(d){if(d&&d.isTexture){const b=d.mapping,x=b===Zn||b===Qn,w=b===rn||b===qt;if(x||w){let g=n.get(d);const S=g!==void 0?g.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==S)return t===null&&(t=new ea(e)),g=x?t.fromEquirectangular(d,g):t.fromCubemap(d,g),g.texture.pmremVersion=d.pmremVersion,n.set(d,g),g.texture;if(g!==void 0)return g.texture;{const R=d.image;return x&&R&&R.height>0||w&&R&&l(R)?(t===null&&(t=new ea(e)),g=x?t.fromEquirectangular(d):t.fromCubemap(d),g.texture.pmremVersion=d.pmremVersion,n.set(d,g),d.addEventListener("dispose",r),g.texture):null}}}return d}function l(d){let b=0;const x=6;for(let w=0;w<x;w++)d[w]!==void 0&&b++;return b===x}function r(d){const b=d.target;b.removeEventListener("dispose",r);const x=n.get(b);x!==void 0&&(n.delete(b),x.dispose())}function h(){n=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:i,dispose:h}}function fc(e){const n={};function t(i){if(n[i]!==void 0)return n[i];const l=e.getExtension(i);return n[i]=l,l}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){const l=t(i);return l===null&&Vn("WebGLRenderer: "+i+" extension not supported."),l}}}function dc(e,n,t,i){const l={},r=new WeakMap;function h(g){const S=g.target;S.index!==null&&n.remove(S.index);for(const O in S.attributes)n.remove(S.attributes[O]);S.removeEventListener("dispose",h),delete l[S.id];const R=r.get(S);R&&(n.remove(R),r.delete(S)),i.releaseStatesOfGeometry(S),S.isInstancedBufferGeometry===!0&&delete S._maxInstanceCount,t.memory.geometries--}function d(g,S){return l[S.id]===!0||(S.addEventListener("dispose",h),l[S.id]=!0,t.memory.geometries++),S}function b(g){const S=g.attributes;for(const R in S)n.update(S[R],e.ARRAY_BUFFER)}function x(g){const S=[],R=g.index,O=g.attributes.position;let U=0;if(R!==null){const P=R.array;U=R.version;for(let M=0,A=P.length;M<A;M+=3){const C=P[M+0],T=P[M+1],N=P[M+2];S.push(C,T,T,N,N,C)}}else if(O!==void 0){const P=O.array;U=O.version;for(let M=0,A=P.length/3-1;M<A;M+=3){const C=M+0,T=M+1,N=M+2;S.push(C,T,T,N,N,C)}}else return;const f=new(ro(S)?io:ao)(S,1);f.version=U;const o=r.get(g);o&&n.remove(o),r.set(g,f)}function w(g){const S=r.get(g);if(S){const R=g.index;R!==null&&S.version<R.version&&x(g)}else x(g);return r.get(g)}return{get:d,update:b,getWireframeAttribute:w}}function uc(e,n,t){let i;function l(S){i=S}let r,h;function d(S){r=S.type,h=S.bytesPerElement}function b(S,R){e.drawElements(i,R,r,S*h),t.update(R,i,1)}function x(S,R,O){O!==0&&(e.drawElementsInstanced(i,R,r,S*h,O),t.update(R,i,O))}function w(S,R,O){if(O===0)return;n.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,R,0,r,S,0,O);let f=0;for(let o=0;o<O;o++)f+=R[o];t.update(f,i,1)}function g(S,R,O,U){if(O===0)return;const f=n.get("WEBGL_multi_draw");if(f===null)for(let o=0;o<S.length;o++)x(S[o]/h,R[o],U[o]);else{f.multiDrawElementsInstancedWEBGL(i,R,0,r,S,0,U,0,O);let o=0;for(let P=0;P<O;P++)o+=R[P]*U[P];t.update(o,i,1)}}this.setMode=l,this.setIndex=d,this.render=b,this.renderInstances=x,this.renderMultiDraw=w,this.renderMultiDrawInstances=g}function pc(e){const n={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function i(r,h,d){switch(t.calls++,h){case e.TRIANGLES:t.triangles+=d*(r/3);break;case e.LINES:t.lines+=d*(r/2);break;case e.LINE_STRIP:t.lines+=d*(r-1);break;case e.LINE_LOOP:t.lines+=d*r;break;case e.POINTS:t.points+=d*r;break;default:Qe("WebGLInfo: Unknown draw mode:",h);break}}function l(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:n,render:t,programs:null,autoReset:!0,reset:l,update:i}}function hc(e,n,t){const i=new WeakMap,l=new pt;function r(h,d,b){const x=h.morphTargetInfluences,w=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,g=w!==void 0?w.length:0;let S=i.get(d);if(S===void 0||S.count!==g){let c=function(){N.dispose(),i.delete(d),d.removeEventListener("dispose",c)};S!==void 0&&S.texture.dispose();const R=d.morphAttributes.position!==void 0,O=d.morphAttributes.normal!==void 0,U=d.morphAttributes.color!==void 0,f=d.morphAttributes.position||[],o=d.morphAttributes.normal||[],P=d.morphAttributes.color||[];let M=0;R===!0&&(M=1),O===!0&&(M=2),U===!0&&(M=3);let A=d.attributes.position.count*M,C=1;A>n.maxTextureSize&&(C=Math.ceil(A/n.maxTextureSize),A=n.maxTextureSize);const T=new Float32Array(A*C*4*g),N=new Ia(T,A,C,g);N.type=Lt,N.needsUpdate=!0;const q=M*4;for(let p=0;p<g;p++){const L=f[p],W=o[p],G=P[p],z=A*C*4*p;for(let K=0;K<L.count;K++){const B=K*q;R===!0&&(l.fromBufferAttribute(L,K),T[z+B+0]=l.x,T[z+B+1]=l.y,T[z+B+2]=l.z,T[z+B+3]=0),O===!0&&(l.fromBufferAttribute(W,K),T[z+B+4]=l.x,T[z+B+5]=l.y,T[z+B+6]=l.z,T[z+B+7]=0),U===!0&&(l.fromBufferAttribute(G,K),T[z+B+8]=l.x,T[z+B+9]=l.y,T[z+B+10]=l.z,T[z+B+11]=G.itemSize===4?l.w:1)}}S={count:g,texture:N,size:new ht(A,C)},i.set(d,S),d.addEventListener("dispose",c)}if(h.isInstancedMesh===!0&&h.morphTexture!==null)b.getUniforms().setValue(e,"morphTexture",h.morphTexture,t);else{let R=0;for(let U=0;U<x.length;U++)R+=x[U];const O=d.morphTargetsRelative?1:1-R;b.getUniforms().setValue(e,"morphTargetBaseInfluence",O),b.getUniforms().setValue(e,"morphTargetInfluences",x)}b.getUniforms().setValue(e,"morphTargetsTexture",S.texture,t),b.getUniforms().setValue(e,"morphTargetsTextureSize",S.size)}return{update:r}}function mc(e,n,t,i){let l=new WeakMap;function r(b){const x=i.render.frame,w=b.geometry,g=n.get(b,w);if(l.get(g)!==x&&(n.update(g),l.set(g,x)),b.isInstancedMesh&&(b.hasEventListener("dispose",d)===!1&&b.addEventListener("dispose",d),l.get(b)!==x&&(t.update(b.instanceMatrix,e.ARRAY_BUFFER),b.instanceColor!==null&&t.update(b.instanceColor,e.ARRAY_BUFFER),l.set(b,x))),b.isSkinnedMesh){const S=b.skeleton;l.get(S)!==x&&(S.update(),l.set(S,x))}return g}function h(){l=new WeakMap}function d(b){const x=b.target;x.removeEventListener("dispose",d),t.remove(x.instanceMatrix),x.instanceColor!==null&&t.remove(x.instanceColor)}return{update:r,dispose:h}}const _c={[Wa]:"LINEAR_TONE_MAPPING",[Va]:"REINHARD_TONE_MAPPING",[Ha]:"CINEON_TONE_MAPPING",[Ga]:"ACES_FILMIC_TONE_MAPPING",[Ba]:"AGX_TONE_MAPPING",[Oa]:"NEUTRAL_TONE_MAPPING",[Fa]:"CUSTOM_TONE_MAPPING"};function gc(e,n,t,i,l){const r=new Pt(n,t,{type:e,depthBuffer:i,stencilBuffer:l}),h=new Pt(n,t,{type:wt,depthBuffer:!1,stencilBuffer:!1}),d=new Mn;d.setAttribute("position",new ui([-1,3,0,-1,-1,0,3,-1,0],3)),d.setAttribute("uv",new ui([0,2,0,0,2,0],2));const b=new lr({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),x=new It(d,b),w=new Ma(-1,1,1,-1,0,1);let g=null,S=null,R=!1,O,U=null,f=[],o=!1;this.setSize=function(P,M){r.setSize(P,M),h.setSize(P,M);for(let A=0;A<f.length;A++){const C=f[A];C.setSize&&C.setSize(P,M)}},this.setEffects=function(P){f=P,o=f.length>0&&f[0].isRenderPass===!0;const M=r.width,A=r.height;for(let C=0;C<f.length;C++){const T=f[C];T.setSize&&T.setSize(M,A)}},this.begin=function(P,M){if(R||P.toneMapping===At&&f.length===0)return!1;if(U=M,M!==null){const A=M.width,C=M.height;(r.width!==A||r.height!==C)&&this.setSize(A,C)}return o===!1&&P.setRenderTarget(r),O=P.toneMapping,P.toneMapping=At,!0},this.hasRenderPass=function(){return o},this.end=function(P,M){P.toneMapping=O,R=!0;let A=r,C=h;for(let T=0;T<f.length;T++){const N=f[T];if(N.enabled!==!1&&(N.render(P,C,A,M),N.needsSwap!==!1)){const q=A;A=C,C=q}}if(g!==P.outputColorSpace||S!==P.toneMapping){g=P.outputColorSpace,S=P.toneMapping,b.defines={},it.getTransfer(g)===Ze&&(b.defines.SRGB_TRANSFER="");const T=_c[S];T&&(b.defines[T]=""),b.needsUpdate=!0}b.uniforms.tDiffuse.value=A.texture,P.setRenderTarget(U),P.render(x,w),U=null,R=!1},this.isCompositing=function(){return R},this.dispose=function(){r.dispose(),h.dispose(),d.dispose(),b.dispose()}}const Xa=new ho,Jn=new vn(1,1),Ya=new Ia,qa=new lo,Ka=new so,aa=[],ra=[],oa=new Float32Array(16),sa=new Float32Array(9),la=new Float32Array(4);function $t(e,n,t){const i=e[0];if(i<=0||i>0)return e;const l=n*t;let r=aa[l];if(r===void 0&&(r=new Float32Array(l),aa[l]=r),n!==0){i.toArray(r,0);for(let h=1,d=0;h!==n;++h)d+=t,e[h].toArray(r,d)}return r}function ot(e,n){if(e.length!==n.length)return!1;for(let t=0,i=e.length;t<i;t++)if(e[t]!==n[t])return!1;return!0}function st(e,n){for(let t=0,i=n.length;t<i;t++)e[t]=n[t]}function Rn(e,n){let t=ra[n];t===void 0&&(t=new Int32Array(n),ra[n]=t);for(let i=0;i!==n;++i)t[i]=e.allocateTextureUnit();return t}function vc(e,n){const t=this.cache;t[0]!==n&&(e.uniform1f(this.addr,n),t[0]=n)}function Sc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y)&&(e.uniform2f(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);else{if(ot(t,n))return;e.uniform2fv(this.addr,n),st(t,n)}}function Ec(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3f(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);else if(n.r!==void 0)(t[0]!==n.r||t[1]!==n.g||t[2]!==n.b)&&(e.uniform3f(this.addr,n.r,n.g,n.b),t[0]=n.r,t[1]=n.g,t[2]=n.b);else{if(ot(t,n))return;e.uniform3fv(this.addr,n),st(t,n)}}function xc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4f(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);else{if(ot(t,n))return;e.uniform4fv(this.addr,n),st(t,n)}}function Mc(e,n){const t=this.cache,i=n.elements;if(i===void 0){if(ot(t,n))return;e.uniformMatrix2fv(this.addr,!1,n),st(t,n)}else{if(ot(t,i))return;la.set(i),e.uniformMatrix2fv(this.addr,!1,la),st(t,i)}}function Tc(e,n){const t=this.cache,i=n.elements;if(i===void 0){if(ot(t,n))return;e.uniformMatrix3fv(this.addr,!1,n),st(t,n)}else{if(ot(t,i))return;sa.set(i),e.uniformMatrix3fv(this.addr,!1,sa),st(t,i)}}function Ac(e,n){const t=this.cache,i=n.elements;if(i===void 0){if(ot(t,n))return;e.uniformMatrix4fv(this.addr,!1,n),st(t,n)}else{if(ot(t,i))return;oa.set(i),e.uniformMatrix4fv(this.addr,!1,oa),st(t,i)}}function Rc(e,n){const t=this.cache;t[0]!==n&&(e.uniform1i(this.addr,n),t[0]=n)}function bc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y)&&(e.uniform2i(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);else{if(ot(t,n))return;e.uniform2iv(this.addr,n),st(t,n)}}function Cc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3i(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);else{if(ot(t,n))return;e.uniform3iv(this.addr,n),st(t,n)}}function Pc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4i(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);else{if(ot(t,n))return;e.uniform4iv(this.addr,n),st(t,n)}}function Lc(e,n){const t=this.cache;t[0]!==n&&(e.uniform1ui(this.addr,n),t[0]=n)}function Dc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y)&&(e.uniform2ui(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);else{if(ot(t,n))return;e.uniform2uiv(this.addr,n),st(t,n)}}function Uc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3ui(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);else{if(ot(t,n))return;e.uniform3uiv(this.addr,n),st(t,n)}}function wc(e,n){const t=this.cache;if(n.x!==void 0)(t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4ui(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);else{if(ot(t,n))return;e.uniform4uiv(this.addr,n),st(t,n)}}function Ic(e,n,t){const i=this.cache,l=t.allocateTextureUnit();i[0]!==l&&(e.uniform1i(this.addr,l),i[0]=l);let r;this.type===e.SAMPLER_2D_SHADOW?(Jn.compareFunction=t.isReversedDepthBuffer()?ei:ti,r=Jn):r=Xa,t.setTexture2D(n||r,l)}function Nc(e,n,t){const i=this.cache,l=t.allocateTextureUnit();i[0]!==l&&(e.uniform1i(this.addr,l),i[0]=l),t.setTexture3D(n||qa,l)}function yc(e,n,t){const i=this.cache,l=t.allocateTextureUnit();i[0]!==l&&(e.uniform1i(this.addr,l),i[0]=l),t.setTextureCube(n||Ka,l)}function Fc(e,n,t){const i=this.cache,l=t.allocateTextureUnit();i[0]!==l&&(e.uniform1i(this.addr,l),i[0]=l),t.setTexture2DArray(n||Ya,l)}function Oc(e){switch(e){case 5126:return vc;case 35664:return Sc;case 35665:return Ec;case 35666:return xc;case 35674:return Mc;case 35675:return Tc;case 35676:return Ac;case 5124:case 35670:return Rc;case 35667:case 35671:return bc;case 35668:case 35672:return Cc;case 35669:case 35673:return Pc;case 5125:return Lc;case 36294:return Dc;case 36295:return Uc;case 36296:return wc;case 35678:case 36198:case 36298:case 36306:case 35682:return Ic;case 35679:case 36299:case 36307:return Nc;case 35680:case 36300:case 36308:case 36293:return yc;case 36289:case 36303:case 36311:case 36292:return Fc}}function Bc(e,n){e.uniform1fv(this.addr,n)}function Gc(e,n){const t=$t(n,this.size,2);e.uniform2fv(this.addr,t)}function Hc(e,n){const t=$t(n,this.size,3);e.uniform3fv(this.addr,t)}function Vc(e,n){const t=$t(n,this.size,4);e.uniform4fv(this.addr,t)}function Wc(e,n){const t=$t(n,this.size,4);e.uniformMatrix2fv(this.addr,!1,t)}function kc(e,n){const t=$t(n,this.size,9);e.uniformMatrix3fv(this.addr,!1,t)}function zc(e,n){const t=$t(n,this.size,16);e.uniformMatrix4fv(this.addr,!1,t)}function Xc(e,n){e.uniform1iv(this.addr,n)}function Yc(e,n){e.uniform2iv(this.addr,n)}function qc(e,n){e.uniform3iv(this.addr,n)}function Kc(e,n){e.uniform4iv(this.addr,n)}function $c(e,n){e.uniform1uiv(this.addr,n)}function Zc(e,n){e.uniform2uiv(this.addr,n)}function Qc(e,n){e.uniform3uiv(this.addr,n)}function Jc(e,n){e.uniform4uiv(this.addr,n)}function jc(e,n,t){const i=this.cache,l=n.length,r=Rn(t,l);ot(i,r)||(e.uniform1iv(this.addr,r),st(i,r));let h;this.type===e.SAMPLER_2D_SHADOW?h=Jn:h=Xa;for(let d=0;d!==l;++d)t.setTexture2D(n[d]||h,r[d])}function ef(e,n,t){const i=this.cache,l=n.length,r=Rn(t,l);ot(i,r)||(e.uniform1iv(this.addr,r),st(i,r));for(let h=0;h!==l;++h)t.setTexture3D(n[h]||qa,r[h])}function tf(e,n,t){const i=this.cache,l=n.length,r=Rn(t,l);ot(i,r)||(e.uniform1iv(this.addr,r),st(i,r));for(let h=0;h!==l;++h)t.setTextureCube(n[h]||Ka,r[h])}function nf(e,n,t){const i=this.cache,l=n.length,r=Rn(t,l);ot(i,r)||(e.uniform1iv(this.addr,r),st(i,r));for(let h=0;h!==l;++h)t.setTexture2DArray(n[h]||Ya,r[h])}function af(e){switch(e){case 5126:return Bc;case 35664:return Gc;case 35665:return Hc;case 35666:return Vc;case 35674:return Wc;case 35675:return kc;case 35676:return zc;case 5124:case 35670:return Xc;case 35667:case 35671:return Yc;case 35668:case 35672:return qc;case 35669:case 35673:return Kc;case 5125:return $c;case 36294:return Zc;case 36295:return Qc;case 36296:return Jc;case 35678:case 36198:case 36298:case 36306:case 35682:return jc;case 35679:case 36299:case 36307:return ef;case 35680:case 36300:case 36308:case 36293:return tf;case 36289:case 36303:case 36311:case 36292:return nf}}class rf{constructor(n,t,i){this.id=n,this.addr=i,this.cache=[],this.type=t.type,this.setValue=Oc(t.type)}}class of{constructor(n,t,i){this.id=n,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=af(t.type)}}class sf{constructor(n){this.id=n,this.seq=[],this.map={}}setValue(n,t,i){const l=this.seq;for(let r=0,h=l.length;r!==h;++r){const d=l[r];d.setValue(n,t[d.id],i)}}}const Gn=/(\w+)(\])?(\[|\.)?/g;function ca(e,n){e.seq.push(n),e.map[n.id]=n}function lf(e,n,t){const i=e.name,l=i.length;for(Gn.lastIndex=0;;){const r=Gn.exec(i),h=Gn.lastIndex;let d=r[1];const b=r[2]==="]",x=r[3];if(b&&(d=d|0),x===void 0||x==="["&&h+2===l){ca(t,x===void 0?new rf(d,e,n):new of(d,e,n));break}else{let g=t.map[d];g===void 0&&(g=new sf(d),ca(t,g)),t=g}}}class gn{constructor(n,t){this.seq=[],this.map={};const i=n.getProgramParameter(t,n.ACTIVE_UNIFORMS);for(let h=0;h<i;++h){const d=n.getActiveUniform(t,h),b=n.getUniformLocation(t,d.name);lf(d,b,this)}const l=[],r=[];for(const h of this.seq)h.type===n.SAMPLER_2D_SHADOW||h.type===n.SAMPLER_CUBE_SHADOW||h.type===n.SAMPLER_2D_ARRAY_SHADOW?l.push(h):r.push(h);l.length>0&&(this.seq=l.concat(r))}setValue(n,t,i,l){const r=this.map[t];r!==void 0&&r.setValue(n,i,l)}setOptional(n,t,i){const l=t[i];l!==void 0&&this.setValue(n,i,l)}static upload(n,t,i,l){for(let r=0,h=t.length;r!==h;++r){const d=t[r],b=i[d.id];b.needsUpdate!==!1&&d.setValue(n,b.value,l)}}static seqWithValue(n,t){const i=[];for(let l=0,r=n.length;l!==r;++l){const h=n[l];h.id in t&&i.push(h)}return i}}function fa(e,n,t){const i=e.createShader(n);return e.shaderSource(i,t),e.compileShader(i),i}const cf=37297;let ff=0;function df(e,n){const t=e.split(`
`),i=[],l=Math.max(n-6,0),r=Math.min(n+6,t.length);for(let h=l;h<r;h++){const d=h+1;i.push(`${d===n?">":" "} ${d}: ${t[h]}`)}return i.join(`
`)}const da=new Fe;function uf(e){it._getMatrix(da,it.workingColorSpace,e);const n=`mat3( ${da.elements.map(t=>t.toFixed(4))} )`;switch(it.getTransfer(e)){case ka:return[n,"LinearTransferOETF"];case Ze:return[n,"sRGBTransferOETF"];default:return Ye("WebGLProgram: Unsupported color space: ",e),[n,"LinearTransferOETF"]}}function ua(e,n,t){const i=e.getShaderParameter(n,e.COMPILE_STATUS),r=(e.getShaderInfoLog(n)||"").trim();if(i&&r==="")return"";const h=/ERROR: 0:(\d+)/.exec(r);if(h){const d=parseInt(h[1]);return t.toUpperCase()+`

`+r+`

`+df(e.getShaderSource(n),d)}else return r}function pf(e,n){const t=uf(n);return[`vec4 ${e}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}const hf={[Wa]:"Linear",[Va]:"Reinhard",[Ha]:"Cineon",[Ga]:"ACESFilmic",[Ba]:"AgX",[Oa]:"Neutral",[Fa]:"Custom"};function mf(e,n){const t=hf[n];return t===void 0?(Ye("WebGLProgram: Unsupported toneMapping:",n),"vec3 "+e+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+e+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const un=new Be;function _f(){it.getLuminanceCoefficients(un);const e=un.x.toFixed(4),n=un.y.toFixed(4),t=un.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${e}, ${n}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function gf(e){return[e.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",e.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(nn).join(`
`)}function vf(e){const n=[];for(const t in e){const i=e[t];i!==!1&&n.push("#define "+t+" "+i)}return n.join(`
`)}function Sf(e,n){const t={},i=e.getProgramParameter(n,e.ACTIVE_ATTRIBUTES);for(let l=0;l<i;l++){const r=e.getActiveAttrib(n,l),h=r.name;let d=1;r.type===e.FLOAT_MAT2&&(d=2),r.type===e.FLOAT_MAT3&&(d=3),r.type===e.FLOAT_MAT4&&(d=4),t[h]={type:r.type,location:e.getAttribLocation(n,h),locationSize:d}}return t}function nn(e){return e!==""}function pa(e,n){const t=n.numSpotLightShadows+n.numSpotLightMaps-n.numSpotLightShadowsWithMaps;return e.replace(/NUM_DIR_LIGHTS/g,n.numDirLights).replace(/NUM_SPOT_LIGHTS/g,n.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,n.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,n.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,n.numPointLights).replace(/NUM_HEMI_LIGHTS/g,n.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,n.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,n.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,n.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,n.numPointLightShadows)}function ha(e,n){return e.replace(/NUM_CLIPPING_PLANES/g,n.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,n.numClippingPlanes-n.numClipIntersection)}const Ef=/^[ \t]*#include +<([\w\d./]+)>/gm;function jn(e){return e.replace(Ef,Mf)}const xf=new Map;function Mf(e,n){let t=Pe[n];if(t===void 0){const i=xf.get(n);if(i!==void 0)t=Pe[i],Ye('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',n,i);else throw new Error("Can not resolve #include <"+n+">")}return jn(t)}const Tf=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function ma(e){return e.replace(Tf,Af)}function Af(e,n,t,i){let l="";for(let r=parseInt(n);r<parseInt(t);r++)l+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return l}function _a(e){let n=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision==="highp"?n+=`
#define HIGH_PRECISION`:e.precision==="mediump"?n+=`
#define MEDIUM_PRECISION`:e.precision==="lowp"&&(n+=`
#define LOW_PRECISION`),n}const Rf={[mn]:"SHADOWMAP_TYPE_PCF",[tn]:"SHADOWMAP_TYPE_VSM"};function bf(e){return Rf[e.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const Cf={[rn]:"ENVMAP_TYPE_CUBE",[qt]:"ENVMAP_TYPE_CUBE",[Tn]:"ENVMAP_TYPE_CUBE_UV"};function Pf(e){return e.envMap===!1?"ENVMAP_TYPE_CUBE":Cf[e.envMapMode]||"ENVMAP_TYPE_CUBE"}const Lf={[qt]:"ENVMAP_MODE_REFRACTION"};function Df(e){return e.envMap===!1?"ENVMAP_MODE_REFLECTION":Lf[e.envMapMode]||"ENVMAP_MODE_REFLECTION"}const Uf={[po]:"ENVMAP_BLENDING_MULTIPLY",[uo]:"ENVMAP_BLENDING_MIX",[fo]:"ENVMAP_BLENDING_ADD"};function wf(e){return e.envMap===!1?"ENVMAP_BLENDING_NONE":Uf[e.combine]||"ENVMAP_BLENDING_NONE"}function If(e){const n=e.envMapCubeUVHeight;if(n===null)return null;const t=Math.log2(n)-2,i=1/n;return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:i,maxMip:t}}function Nf(e,n,t,i){const l=e.getContext(),r=t.defines;let h=t.vertexShader,d=t.fragmentShader;const b=bf(t),x=Pf(t),w=Df(t),g=wf(t),S=If(t),R=gf(t),O=vf(r),U=l.createProgram();let f,o,P=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,O].filter(nn).join(`
`),f.length>0&&(f+=`
`),o=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,O].filter(nn).join(`
`),o.length>0&&(o+=`
`)):(f=[_a(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,O,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+w:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+b:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(nn).join(`
`),o=[_a(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,O,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+x:"",t.envMap?"#define "+w:"",t.envMap?"#define "+g:"",S?"#define CUBEUV_TEXEL_WIDTH "+S.texelWidth:"",S?"#define CUBEUV_TEXEL_HEIGHT "+S.texelHeight:"",S?"#define CUBEUV_MAX_MIP "+S.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+b:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",t.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==At?"#define TONE_MAPPING":"",t.toneMapping!==At?Pe.tonemapping_pars_fragment:"",t.toneMapping!==At?mf("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Pe.colorspace_pars_fragment,pf("linearToOutputTexel",t.outputColorSpace),_f(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(nn).join(`
`)),h=jn(h),h=pa(h,t),h=ha(h,t),d=jn(d),d=pa(d,t),d=ha(d,t),h=ma(h),d=ma(d),t.isRawShaderMaterial!==!0&&(P=`#version 300 es
`,f=[R,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,o=["#define varying in",t.glslVersion===Qi?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Qi?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+o);const M=P+f+h,A=P+o+d,C=fa(l,l.VERTEX_SHADER,M),T=fa(l,l.FRAGMENT_SHADER,A);l.attachShader(U,C),l.attachShader(U,T),t.index0AttributeName!==void 0?l.bindAttribLocation(U,0,t.index0AttributeName):t.morphTargets===!0&&l.bindAttribLocation(U,0,"position"),l.linkProgram(U);function N(L){if(e.debug.checkShaderErrors){const W=l.getProgramInfoLog(U)||"",G=l.getShaderInfoLog(C)||"",z=l.getShaderInfoLog(T)||"",K=W.trim(),B=G.trim(),V=z.trim();let J=!0,xe=!0;if(l.getProgramParameter(U,l.LINK_STATUS)===!1)if(J=!1,typeof e.debug.onShaderError=="function")e.debug.onShaderError(l,U,C,T);else{const ge=ua(l,C,"vertex"),Ee=ua(l,T,"fragment");Qe("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(U,l.VALIDATE_STATUS)+`

Material Name: `+L.name+`
Material Type: `+L.type+`

Program Info Log: `+K+`
`+ge+`
`+Ee)}else K!==""?Ye("WebGLProgram: Program Info Log:",K):(B===""||V==="")&&(xe=!1);xe&&(L.diagnostics={runnable:J,programLog:K,vertexShader:{log:B,prefix:f},fragmentShader:{log:V,prefix:o}})}l.deleteShader(C),l.deleteShader(T),q=new gn(l,U),c=Sf(l,U)}let q;this.getUniforms=function(){return q===void 0&&N(this),q};let c;this.getAttributes=function(){return c===void 0&&N(this),c};let p=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return p===!1&&(p=l.getProgramParameter(U,cf)),p},this.destroy=function(){i.releaseStatesOfProgram(this),l.deleteProgram(U),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=ff++,this.cacheKey=n,this.usedTimes=1,this.program=U,this.vertexShader=C,this.fragmentShader=T,this}let yf=0;class Ff{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(n){const t=n.vertexShader,i=n.fragmentShader,l=this._getShaderStage(t),r=this._getShaderStage(i),h=this._getShaderCacheForMaterial(n);return h.has(l)===!1&&(h.add(l),l.usedTimes++),h.has(r)===!1&&(h.add(r),r.usedTimes++),this}remove(n){const t=this.materialCache.get(n);for(const i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(n),this}getVertexShaderID(n){return this._getShaderStage(n.vertexShader).id}getFragmentShaderID(n){return this._getShaderStage(n.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(n){const t=this.materialCache;let i=t.get(n);return i===void 0&&(i=new Set,t.set(n,i)),i}_getShaderStage(n){const t=this.shaderCache;let i=t.get(n);return i===void 0&&(i=new Of(n),t.set(n,i)),i}}class Of{constructor(n){this.id=yf++,this.code=n,this.usedTimes=0}}function Bf(e,n,t,i,l,r,h){const d=new oo,b=new Ff,x=new Set,w=[],g=new Map,S=l.logarithmicDepthBuffer;let R=l.precision;const O={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function U(c){return x.add(c),c===0?"uv":`uv${c}`}function f(c,p,L,W,G){const z=W.fog,K=G.geometry,B=c.isMeshStandardMaterial?W.environment:null,V=(c.isMeshStandardMaterial?t:n).get(c.envMap||B),J=V&&V.mapping===Tn?V.image.height:null,xe=O[c.type];c.precision!==null&&(R=l.getMaxPrecision(c.precision),R!==c.precision&&Ye("WebGLProgram.getParameters:",c.precision,"not supported, using",R,"instead."));const ge=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,Ee=ge!==void 0?ge.length:0;let Oe=0;K.morphAttributes.position!==void 0&&(Oe=1),K.morphAttributes.normal!==void 0&&(Oe=2),K.morphAttributes.color!==void 0&&(Oe=3);let we,nt,je,k;if(xe){const Ve=Mt[xe];we=Ve.vertexShader,nt=Ve.fragmentShader}else we=c.vertexShader,nt=c.fragmentShader,b.update(c),je=b.getVertexShaderID(c),k=b.getFragmentShaderID(c);const $=e.getRenderTarget(),fe=e.state.buffers.depth.getReversed(),Ce=G.isInstancedMesh===!0,pe=G.isBatchedMesh===!0,Ne=!!c.map,lt=!!c.matcap,Ie=!!V,He=!!c.aoMap,ze=!!c.lightMap,Le=!!c.bumpMap,at=!!c.normalMap,m=!!c.displacementMap,rt=!!c.emissiveMap,Ge=!!c.metalnessMap,qe=!!c.roughnessMap,me=c.anisotropy>0,u=c.clearcoat>0,a=c.dispersion>0,v=c.iridescence>0,H=c.sheen>0,Y=c.transmission>0,F=me&&!!c.anisotropyMap,ve=u&&!!c.clearcoatMap,te=u&&!!c.clearcoatNormalMap,he=u&&!!c.clearcoatRoughnessMap,Re=v&&!!c.iridescenceMap,Q=v&&!!c.iridescenceThicknessMap,ie=H&&!!c.sheenColorMap,ue=H&&!!c.sheenRoughnessMap,_e=!!c.specularMap,ne=!!c.specularColorMap,De=!!c.specularIntensityMap,_=Y&&!!c.transmissionMap,se=Y&&!!c.thicknessMap,j=!!c.gradientMap,le=!!c.alphaMap,Z=c.alphaTest>0,X=!!c.alphaHash,ee=!!c.extensions;let be=At;c.toneMapped&&($===null||$.isXRRenderTarget===!0)&&(be=e.toneMapping);const Ke={shaderID:xe,shaderType:c.type,shaderName:c.name,vertexShader:we,fragmentShader:nt,defines:c.defines,customVertexShaderID:je,customFragmentShaderID:k,isRawShaderMaterial:c.isRawShaderMaterial===!0,glslVersion:c.glslVersion,precision:R,batching:pe,batchingColor:pe&&G._colorsTexture!==null,instancing:Ce,instancingColor:Ce&&G.instanceColor!==null,instancingMorph:Ce&&G.morphTexture!==null,outputColorSpace:$===null?e.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:xn,alphaToCoverage:!!c.alphaToCoverage,map:Ne,matcap:lt,envMap:Ie,envMapMode:Ie&&V.mapping,envMapCubeUVHeight:J,aoMap:He,lightMap:ze,bumpMap:Le,normalMap:at,displacementMap:m,emissiveMap:rt,normalMapObjectSpace:at&&c.normalMapType===no,normalMapTangentSpace:at&&c.normalMapType===to,metalnessMap:Ge,roughnessMap:qe,anisotropy:me,anisotropyMap:F,clearcoat:u,clearcoatMap:ve,clearcoatNormalMap:te,clearcoatRoughnessMap:he,dispersion:a,iridescence:v,iridescenceMap:Re,iridescenceThicknessMap:Q,sheen:H,sheenColorMap:ie,sheenRoughnessMap:ue,specularMap:_e,specularColorMap:ne,specularIntensityMap:De,transmission:Y,transmissionMap:_,thicknessMap:se,gradientMap:j,opaque:c.transparent===!1&&c.blending===_n&&c.alphaToCoverage===!1,alphaMap:le,alphaTest:Z,alphaHash:X,combine:c.combine,mapUv:Ne&&U(c.map.channel),aoMapUv:He&&U(c.aoMap.channel),lightMapUv:ze&&U(c.lightMap.channel),bumpMapUv:Le&&U(c.bumpMap.channel),normalMapUv:at&&U(c.normalMap.channel),displacementMapUv:m&&U(c.displacementMap.channel),emissiveMapUv:rt&&U(c.emissiveMap.channel),metalnessMapUv:Ge&&U(c.metalnessMap.channel),roughnessMapUv:qe&&U(c.roughnessMap.channel),anisotropyMapUv:F&&U(c.anisotropyMap.channel),clearcoatMapUv:ve&&U(c.clearcoatMap.channel),clearcoatNormalMapUv:te&&U(c.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:he&&U(c.clearcoatRoughnessMap.channel),iridescenceMapUv:Re&&U(c.iridescenceMap.channel),iridescenceThicknessMapUv:Q&&U(c.iridescenceThicknessMap.channel),sheenColorMapUv:ie&&U(c.sheenColorMap.channel),sheenRoughnessMapUv:ue&&U(c.sheenRoughnessMap.channel),specularMapUv:_e&&U(c.specularMap.channel),specularColorMapUv:ne&&U(c.specularColorMap.channel),specularIntensityMapUv:De&&U(c.specularIntensityMap.channel),transmissionMapUv:_&&U(c.transmissionMap.channel),thicknessMapUv:se&&U(c.thicknessMap.channel),alphaMapUv:le&&U(c.alphaMap.channel),vertexTangents:!!K.attributes.tangent&&(at||me),vertexColors:c.vertexColors,vertexAlphas:c.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,pointsUvs:G.isPoints===!0&&!!K.attributes.uv&&(Ne||le),fog:!!z,useFog:c.fog===!0,fogExp2:!!z&&z.isFogExp2,flatShading:c.flatShading===!0&&c.wireframe===!1,sizeAttenuation:c.sizeAttenuation===!0,logarithmicDepthBuffer:S,reversedDepthBuffer:fe,skinning:G.isSkinnedMesh===!0,morphTargets:K.morphAttributes.position!==void 0,morphNormals:K.morphAttributes.normal!==void 0,morphColors:K.morphAttributes.color!==void 0,morphTargetsCount:Ee,morphTextureStride:Oe,numDirLights:p.directional.length,numPointLights:p.point.length,numSpotLights:p.spot.length,numSpotLightMaps:p.spotLightMap.length,numRectAreaLights:p.rectArea.length,numHemiLights:p.hemi.length,numDirLightShadows:p.directionalShadowMap.length,numPointLightShadows:p.pointShadowMap.length,numSpotLightShadows:p.spotShadowMap.length,numSpotLightShadowsWithMaps:p.numSpotLightShadowsWithMaps,numLightProbes:p.numLightProbes,numClippingPlanes:h.numPlanes,numClipIntersection:h.numIntersection,dithering:c.dithering,shadowMapEnabled:e.shadowMap.enabled&&L.length>0,shadowMapType:e.shadowMap.type,toneMapping:be,decodeVideoTexture:Ne&&c.map.isVideoTexture===!0&&it.getTransfer(c.map.colorSpace)===Ze,decodeVideoTextureEmissive:rt&&c.emissiveMap.isVideoTexture===!0&&it.getTransfer(c.emissiveMap.colorSpace)===Ze,premultipliedAlpha:c.premultipliedAlpha,doubleSided:c.side===bt,flipSided:c.side===St,useDepthPacking:c.depthPacking>=0,depthPacking:c.depthPacking||0,index0AttributeName:c.index0AttributeName,extensionClipCullDistance:ee&&c.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ee&&c.extensions.multiDraw===!0||pe)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:c.customProgramCacheKey()};return Ke.vertexUv1s=x.has(1),Ke.vertexUv2s=x.has(2),Ke.vertexUv3s=x.has(3),x.clear(),Ke}function o(c){const p=[];if(c.shaderID?p.push(c.shaderID):(p.push(c.customVertexShaderID),p.push(c.customFragmentShaderID)),c.defines!==void 0)for(const L in c.defines)p.push(L),p.push(c.defines[L]);return c.isRawShaderMaterial===!1&&(P(p,c),M(p,c),p.push(e.outputColorSpace)),p.push(c.customProgramCacheKey),p.join()}function P(c,p){c.push(p.precision),c.push(p.outputColorSpace),c.push(p.envMapMode),c.push(p.envMapCubeUVHeight),c.push(p.mapUv),c.push(p.alphaMapUv),c.push(p.lightMapUv),c.push(p.aoMapUv),c.push(p.bumpMapUv),c.push(p.normalMapUv),c.push(p.displacementMapUv),c.push(p.emissiveMapUv),c.push(p.metalnessMapUv),c.push(p.roughnessMapUv),c.push(p.anisotropyMapUv),c.push(p.clearcoatMapUv),c.push(p.clearcoatNormalMapUv),c.push(p.clearcoatRoughnessMapUv),c.push(p.iridescenceMapUv),c.push(p.iridescenceThicknessMapUv),c.push(p.sheenColorMapUv),c.push(p.sheenRoughnessMapUv),c.push(p.specularMapUv),c.push(p.specularColorMapUv),c.push(p.specularIntensityMapUv),c.push(p.transmissionMapUv),c.push(p.thicknessMapUv),c.push(p.combine),c.push(p.fogExp2),c.push(p.sizeAttenuation),c.push(p.morphTargetsCount),c.push(p.morphAttributeCount),c.push(p.numDirLights),c.push(p.numPointLights),c.push(p.numSpotLights),c.push(p.numSpotLightMaps),c.push(p.numHemiLights),c.push(p.numRectAreaLights),c.push(p.numDirLightShadows),c.push(p.numPointLightShadows),c.push(p.numSpotLightShadows),c.push(p.numSpotLightShadowsWithMaps),c.push(p.numLightProbes),c.push(p.shadowMapType),c.push(p.toneMapping),c.push(p.numClippingPlanes),c.push(p.numClipIntersection),c.push(p.depthPacking)}function M(c,p){d.disableAll(),p.instancing&&d.enable(0),p.instancingColor&&d.enable(1),p.instancingMorph&&d.enable(2),p.matcap&&d.enable(3),p.envMap&&d.enable(4),p.normalMapObjectSpace&&d.enable(5),p.normalMapTangentSpace&&d.enable(6),p.clearcoat&&d.enable(7),p.iridescence&&d.enable(8),p.alphaTest&&d.enable(9),p.vertexColors&&d.enable(10),p.vertexAlphas&&d.enable(11),p.vertexUv1s&&d.enable(12),p.vertexUv2s&&d.enable(13),p.vertexUv3s&&d.enable(14),p.vertexTangents&&d.enable(15),p.anisotropy&&d.enable(16),p.alphaHash&&d.enable(17),p.batching&&d.enable(18),p.dispersion&&d.enable(19),p.batchingColor&&d.enable(20),p.gradientMap&&d.enable(21),c.push(d.mask),d.disableAll(),p.fog&&d.enable(0),p.useFog&&d.enable(1),p.flatShading&&d.enable(2),p.logarithmicDepthBuffer&&d.enable(3),p.reversedDepthBuffer&&d.enable(4),p.skinning&&d.enable(5),p.morphTargets&&d.enable(6),p.morphNormals&&d.enable(7),p.morphColors&&d.enable(8),p.premultipliedAlpha&&d.enable(9),p.shadowMapEnabled&&d.enable(10),p.doubleSided&&d.enable(11),p.flipSided&&d.enable(12),p.useDepthPacking&&d.enable(13),p.dithering&&d.enable(14),p.transmission&&d.enable(15),p.sheen&&d.enable(16),p.opaque&&d.enable(17),p.pointsUvs&&d.enable(18),p.decodeVideoTexture&&d.enable(19),p.decodeVideoTextureEmissive&&d.enable(20),p.alphaToCoverage&&d.enable(21),c.push(d.mask)}function A(c){const p=O[c.type];let L;if(p){const W=Mt[p];L=eo.clone(W.uniforms)}else L=c.uniforms;return L}function C(c,p){let L=g.get(p);return L!==void 0?++L.usedTimes:(L=new Nf(e,p,c,r),w.push(L),g.set(p,L)),L}function T(c){if(--c.usedTimes===0){const p=w.indexOf(c);w[p]=w[w.length-1],w.pop(),g.delete(c.cacheKey),c.destroy()}}function N(c){b.remove(c)}function q(){b.dispose()}return{getParameters:f,getProgramCacheKey:o,getUniforms:A,acquireProgram:C,releaseProgram:T,releaseShaderCache:N,programs:w,dispose:q}}function Gf(){let e=new WeakMap;function n(h){return e.has(h)}function t(h){let d=e.get(h);return d===void 0&&(d={},e.set(h,d)),d}function i(h){e.delete(h)}function l(h,d,b){e.get(h)[d]=b}function r(){e=new WeakMap}return{has:n,get:t,remove:i,update:l,dispose:r}}function Hf(e,n){return e.groupOrder!==n.groupOrder?e.groupOrder-n.groupOrder:e.renderOrder!==n.renderOrder?e.renderOrder-n.renderOrder:e.material.id!==n.material.id?e.material.id-n.material.id:e.z!==n.z?e.z-n.z:e.id-n.id}function ga(e,n){return e.groupOrder!==n.groupOrder?e.groupOrder-n.groupOrder:e.renderOrder!==n.renderOrder?e.renderOrder-n.renderOrder:e.z!==n.z?n.z-e.z:e.id-n.id}function va(){const e=[];let n=0;const t=[],i=[],l=[];function r(){n=0,t.length=0,i.length=0,l.length=0}function h(g,S,R,O,U,f){let o=e[n];return o===void 0?(o={id:g.id,object:g,geometry:S,material:R,groupOrder:O,renderOrder:g.renderOrder,z:U,group:f},e[n]=o):(o.id=g.id,o.object=g,o.geometry=S,o.material=R,o.groupOrder=O,o.renderOrder=g.renderOrder,o.z=U,o.group=f),n++,o}function d(g,S,R,O,U,f){const o=h(g,S,R,O,U,f);R.transmission>0?i.push(o):R.transparent===!0?l.push(o):t.push(o)}function b(g,S,R,O,U,f){const o=h(g,S,R,O,U,f);R.transmission>0?i.unshift(o):R.transparent===!0?l.unshift(o):t.unshift(o)}function x(g,S){t.length>1&&t.sort(g||Hf),i.length>1&&i.sort(S||ga),l.length>1&&l.sort(S||ga)}function w(){for(let g=n,S=e.length;g<S;g++){const R=e[g];if(R.id===null)break;R.id=null,R.object=null,R.geometry=null,R.material=null,R.group=null}}return{opaque:t,transmissive:i,transparent:l,init:r,push:d,unshift:b,finish:w,sort:x}}function Vf(){let e=new WeakMap;function n(i,l){const r=e.get(i);let h;return r===void 0?(h=new va,e.set(i,[h])):l>=r.length?(h=new va,r.push(h)):h=r[l],h}function t(){e=new WeakMap}return{get:n,dispose:t}}function Wf(){const e={};return{get:function(n){if(e[n.id]!==void 0)return e[n.id];let t;switch(n.type){case"DirectionalLight":t={direction:new Be,color:new Je};break;case"SpotLight":t={position:new Be,direction:new Be,color:new Je,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new Be,color:new Je,distance:0,decay:0};break;case"HemisphereLight":t={direction:new Be,skyColor:new Je,groundColor:new Je};break;case"RectAreaLight":t={color:new Je,position:new Be,halfWidth:new Be,halfHeight:new Be};break}return e[n.id]=t,t}}}function kf(){const e={};return{get:function(n){if(e[n.id]!==void 0)return e[n.id];let t;switch(n.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ht,shadowCameraNear:1,shadowCameraFar:1e3};break}return e[n.id]=t,t}}}let zf=0;function Xf(e,n){return(n.castShadow?2:0)-(e.castShadow?2:0)+(n.map?1:0)-(e.map?1:0)}function Yf(e){const n=new Wf,t=kf(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let x=0;x<9;x++)i.probe.push(new Be);const l=new Be,r=new Yt,h=new Yt;function d(x){let w=0,g=0,S=0;for(let c=0;c<9;c++)i.probe[c].set(0,0,0);let R=0,O=0,U=0,f=0,o=0,P=0,M=0,A=0,C=0,T=0,N=0;x.sort(Xf);for(let c=0,p=x.length;c<p;c++){const L=x[c],W=L.color,G=L.intensity,z=L.distance;let K=null;if(L.shadow&&L.shadow.map&&(L.shadow.map.texture.format===sn?K=L.shadow.map.texture:K=L.shadow.map.depthTexture||L.shadow.map.texture),L.isAmbientLight)w+=W.r*G,g+=W.g*G,S+=W.b*G;else if(L.isLightProbe){for(let B=0;B<9;B++)i.probe[B].addScaledVector(L.sh.coefficients[B],G);N++}else if(L.isDirectionalLight){const B=n.get(L);if(B.color.copy(L.color).multiplyScalar(L.intensity),L.castShadow){const V=L.shadow,J=t.get(L);J.shadowIntensity=V.intensity,J.shadowBias=V.bias,J.shadowNormalBias=V.normalBias,J.shadowRadius=V.radius,J.shadowMapSize=V.mapSize,i.directionalShadow[R]=J,i.directionalShadowMap[R]=K,i.directionalShadowMatrix[R]=L.shadow.matrix,P++}i.directional[R]=B,R++}else if(L.isSpotLight){const B=n.get(L);B.position.setFromMatrixPosition(L.matrixWorld),B.color.copy(W).multiplyScalar(G),B.distance=z,B.coneCos=Math.cos(L.angle),B.penumbraCos=Math.cos(L.angle*(1-L.penumbra)),B.decay=L.decay,i.spot[U]=B;const V=L.shadow;if(L.map&&(i.spotLightMap[C]=L.map,C++,V.updateMatrices(L),L.castShadow&&T++),i.spotLightMatrix[U]=V.matrix,L.castShadow){const J=t.get(L);J.shadowIntensity=V.intensity,J.shadowBias=V.bias,J.shadowNormalBias=V.normalBias,J.shadowRadius=V.radius,J.shadowMapSize=V.mapSize,i.spotShadow[U]=J,i.spotShadowMap[U]=K,A++}U++}else if(L.isRectAreaLight){const B=n.get(L);B.color.copy(W).multiplyScalar(G),B.halfWidth.set(L.width*.5,0,0),B.halfHeight.set(0,L.height*.5,0),i.rectArea[f]=B,f++}else if(L.isPointLight){const B=n.get(L);if(B.color.copy(L.color).multiplyScalar(L.intensity),B.distance=L.distance,B.decay=L.decay,L.castShadow){const V=L.shadow,J=t.get(L);J.shadowIntensity=V.intensity,J.shadowBias=V.bias,J.shadowNormalBias=V.normalBias,J.shadowRadius=V.radius,J.shadowMapSize=V.mapSize,J.shadowCameraNear=V.camera.near,J.shadowCameraFar=V.camera.far,i.pointShadow[O]=J,i.pointShadowMap[O]=K,i.pointShadowMatrix[O]=L.shadow.matrix,M++}i.point[O]=B,O++}else if(L.isHemisphereLight){const B=n.get(L);B.skyColor.copy(L.color).multiplyScalar(G),B.groundColor.copy(L.groundColor).multiplyScalar(G),i.hemi[o]=B,o++}}f>0&&(e.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=re.LTC_FLOAT_1,i.rectAreaLTC2=re.LTC_FLOAT_2):(i.rectAreaLTC1=re.LTC_HALF_1,i.rectAreaLTC2=re.LTC_HALF_2)),i.ambient[0]=w,i.ambient[1]=g,i.ambient[2]=S;const q=i.hash;(q.directionalLength!==R||q.pointLength!==O||q.spotLength!==U||q.rectAreaLength!==f||q.hemiLength!==o||q.numDirectionalShadows!==P||q.numPointShadows!==M||q.numSpotShadows!==A||q.numSpotMaps!==C||q.numLightProbes!==N)&&(i.directional.length=R,i.spot.length=U,i.rectArea.length=f,i.point.length=O,i.hemi.length=o,i.directionalShadow.length=P,i.directionalShadowMap.length=P,i.pointShadow.length=M,i.pointShadowMap.length=M,i.spotShadow.length=A,i.spotShadowMap.length=A,i.directionalShadowMatrix.length=P,i.pointShadowMatrix.length=M,i.spotLightMatrix.length=A+C-T,i.spotLightMap.length=C,i.numSpotLightShadowsWithMaps=T,i.numLightProbes=N,q.directionalLength=R,q.pointLength=O,q.spotLength=U,q.rectAreaLength=f,q.hemiLength=o,q.numDirectionalShadows=P,q.numPointShadows=M,q.numSpotShadows=A,q.numSpotMaps=C,q.numLightProbes=N,i.version=zf++)}function b(x,w){let g=0,S=0,R=0,O=0,U=0;const f=w.matrixWorldInverse;for(let o=0,P=x.length;o<P;o++){const M=x[o];if(M.isDirectionalLight){const A=i.directional[g];A.direction.setFromMatrixPosition(M.matrixWorld),l.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(l),A.direction.transformDirection(f),g++}else if(M.isSpotLight){const A=i.spot[R];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(f),A.direction.setFromMatrixPosition(M.matrixWorld),l.setFromMatrixPosition(M.target.matrixWorld),A.direction.sub(l),A.direction.transformDirection(f),R++}else if(M.isRectAreaLight){const A=i.rectArea[O];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(f),h.identity(),r.copy(M.matrixWorld),r.premultiply(f),h.extractRotation(r),A.halfWidth.set(M.width*.5,0,0),A.halfHeight.set(0,M.height*.5,0),A.halfWidth.applyMatrix4(h),A.halfHeight.applyMatrix4(h),O++}else if(M.isPointLight){const A=i.point[S];A.position.setFromMatrixPosition(M.matrixWorld),A.position.applyMatrix4(f),S++}else if(M.isHemisphereLight){const A=i.hemi[U];A.direction.setFromMatrixPosition(M.matrixWorld),A.direction.transformDirection(f),U++}}}return{setup:d,setupView:b,state:i}}function Sa(e){const n=new Yf(e),t=[],i=[];function l(w){x.camera=w,t.length=0,i.length=0}function r(w){t.push(w)}function h(w){i.push(w)}function d(){n.setup(t)}function b(w){n.setupView(t,w)}const x={lightsArray:t,shadowsArray:i,camera:null,lights:n,transmissionRenderTarget:{}};return{init:l,state:x,setupLights:d,setupLightsView:b,pushLight:r,pushShadow:h}}function qf(e){let n=new WeakMap;function t(l,r=0){const h=n.get(l);let d;return h===void 0?(d=new Sa(e),n.set(l,[d])):r>=h.length?(d=new Sa(e),h.push(d)):d=h[r],d}function i(){n=new WeakMap}return{get:t,dispose:i}}const Kf=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,$f=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Zf=[new Be(1,0,0),new Be(-1,0,0),new Be(0,1,0),new Be(0,-1,0),new Be(0,0,1),new Be(0,0,-1)],Qf=[new Be(0,-1,0),new Be(0,-1,0),new Be(0,0,1),new Be(0,0,-1),new Be(0,-1,0),new Be(0,-1,0)],Ea=new Yt,jt=new Be,Hn=new Be;function Jf(e,n,t){let i=new xa;const l=new ht,r=new ht,h=new pt,d=new Hr,b=new Vr,x={},w=t.maxTextureSize,g={[an]:St,[St]:an,[bt]:bt},S=new Nt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ht},radius:{value:4}},vertexShader:Kf,fragmentShader:$f}),R=S.clone();R.defines.HORIZONTAL_PASS=1;const O=new Mn;O.setAttribute("position",new hn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const U=new It(O,S),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=mn;let o=this.type;this.render=function(T,N,q){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||T.length===0)return;T.type===Wr&&(Ye("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),T.type=mn);const c=e.getRenderTarget(),p=e.getActiveCubeFace(),L=e.getActiveMipmapLevel(),W=e.state;W.setBlending(Ut),W.buffers.depth.getReversed()===!0?W.buffers.color.setClear(0,0,0,0):W.buffers.color.setClear(1,1,1,1),W.buffers.depth.setTest(!0),W.setScissorTest(!1);const G=o!==this.type;G&&N.traverse(function(z){z.material&&(Array.isArray(z.material)?z.material.forEach(K=>K.needsUpdate=!0):z.material.needsUpdate=!0)});for(let z=0,K=T.length;z<K;z++){const B=T[z],V=B.shadow;if(V===void 0){Ye("WebGLShadowMap:",B,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;l.copy(V.mapSize);const J=V.getFrameExtents();if(l.multiply(J),r.copy(V.mapSize),(l.x>w||l.y>w)&&(l.x>w&&(r.x=Math.floor(w/J.x),l.x=r.x*J.x,V.mapSize.x=r.x),l.y>w&&(r.y=Math.floor(w/J.y),l.y=r.y*J.y,V.mapSize.y=r.y)),V.map===null||G===!0){if(V.map!==null&&(V.map.depthTexture!==null&&(V.map.depthTexture.dispose(),V.map.depthTexture=null),V.map.dispose()),this.type===tn){if(B.isPointLight){Ye("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}V.map=new Pt(l.x,l.y,{format:sn,type:wt,minFilter:vt,magFilter:vt,generateMipmaps:!1}),V.map.texture.name=B.name+".shadowMap",V.map.depthTexture=new vn(l.x,l.y,Lt),V.map.depthTexture.name=B.name+".shadowMapDepth",V.map.depthTexture.format=Kt,V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=Ht,V.map.depthTexture.magFilter=Ht}else{B.isPointLight?(V.map=new Aa(l.x),V.map.depthTexture=new kr(l.x,Vt)):(V.map=new Pt(l.x,l.y),V.map.depthTexture=new vn(l.x,l.y,Vt)),V.map.depthTexture.name=B.name+".shadowMap",V.map.depthTexture.format=Kt;const ge=e.state.buffers.depth.getReversed();this.type===mn?(V.map.depthTexture.compareFunction=ge?ei:ti,V.map.depthTexture.minFilter=vt,V.map.depthTexture.magFilter=vt):(V.map.depthTexture.compareFunction=null,V.map.depthTexture.minFilter=Ht,V.map.depthTexture.magFilter=Ht)}V.camera.updateProjectionMatrix()}const xe=V.map.isWebGLCubeRenderTarget?6:1;for(let ge=0;ge<xe;ge++){if(V.map.isWebGLCubeRenderTarget)e.setRenderTarget(V.map,ge),e.clear();else{ge===0&&(e.setRenderTarget(V.map),e.clear());const Ee=V.getViewport(ge);h.set(r.x*Ee.x,r.y*Ee.y,r.x*Ee.z,r.y*Ee.w),W.viewport(h)}if(B.isPointLight){const Ee=V.camera,Oe=V.matrix,we=B.distance||Ee.far;we!==Ee.far&&(Ee.far=we,Ee.updateProjectionMatrix()),jt.setFromMatrixPosition(B.matrixWorld),Ee.position.copy(jt),Hn.copy(Ee.position),Hn.add(Zf[ge]),Ee.up.copy(Qf[ge]),Ee.lookAt(Hn),Ee.updateMatrixWorld(),Oe.makeTranslation(-jt.x,-jt.y,-jt.z),Ea.multiplyMatrices(Ee.projectionMatrix,Ee.matrixWorldInverse),V._frustum.setFromProjectionMatrix(Ea,Ee.coordinateSystem,Ee.reversedDepth)}else V.updateMatrices(B);i=V.getFrustum(),A(N,q,V.camera,B,this.type)}V.isPointLightShadow!==!0&&this.type===tn&&P(V,q),V.needsUpdate=!1}o=this.type,f.needsUpdate=!1,e.setRenderTarget(c,p,L)};function P(T,N){const q=n.update(U);S.defines.VSM_SAMPLES!==T.blurSamples&&(S.defines.VSM_SAMPLES=T.blurSamples,R.defines.VSM_SAMPLES=T.blurSamples,S.needsUpdate=!0,R.needsUpdate=!0),T.mapPass===null&&(T.mapPass=new Pt(l.x,l.y,{format:sn,type:wt})),S.uniforms.shadow_pass.value=T.map.depthTexture,S.uniforms.resolution.value=T.mapSize,S.uniforms.radius.value=T.radius,e.setRenderTarget(T.mapPass),e.clear(),e.renderBufferDirect(N,null,q,S,U,null),R.uniforms.shadow_pass.value=T.mapPass.texture,R.uniforms.resolution.value=T.mapSize,R.uniforms.radius.value=T.radius,e.setRenderTarget(T.map),e.clear(),e.renderBufferDirect(N,null,q,R,U,null)}function M(T,N,q,c){let p=null;const L=q.isPointLight===!0?T.customDistanceMaterial:T.customDepthMaterial;if(L!==void 0)p=L;else if(p=q.isPointLight===!0?b:d,e.localClippingEnabled&&N.clipShadows===!0&&Array.isArray(N.clippingPlanes)&&N.clippingPlanes.length!==0||N.displacementMap&&N.displacementScale!==0||N.alphaMap&&N.alphaTest>0||N.map&&N.alphaTest>0||N.alphaToCoverage===!0){const W=p.uuid,G=N.uuid;let z=x[W];z===void 0&&(z={},x[W]=z);let K=z[G];K===void 0&&(K=p.clone(),z[G]=K,N.addEventListener("dispose",C)),p=K}if(p.visible=N.visible,p.wireframe=N.wireframe,c===tn?p.side=N.shadowSide!==null?N.shadowSide:N.side:p.side=N.shadowSide!==null?N.shadowSide:g[N.side],p.alphaMap=N.alphaMap,p.alphaTest=N.alphaToCoverage===!0?.5:N.alphaTest,p.map=N.map,p.clipShadows=N.clipShadows,p.clippingPlanes=N.clippingPlanes,p.clipIntersection=N.clipIntersection,p.displacementMap=N.displacementMap,p.displacementScale=N.displacementScale,p.displacementBias=N.displacementBias,p.wireframeLinewidth=N.wireframeLinewidth,p.linewidth=N.linewidth,q.isPointLight===!0&&p.isMeshDistanceMaterial===!0){const W=e.properties.get(p);W.light=q}return p}function A(T,N,q,c,p){if(T.visible===!1)return;if(T.layers.test(N.layers)&&(T.isMesh||T.isLine||T.isPoints)&&(T.castShadow||T.receiveShadow&&p===tn)&&(!T.frustumCulled||i.intersectsObject(T))){T.modelViewMatrix.multiplyMatrices(q.matrixWorldInverse,T.matrixWorld);const G=n.update(T),z=T.material;if(Array.isArray(z)){const K=G.groups;for(let B=0,V=K.length;B<V;B++){const J=K[B],xe=z[J.materialIndex];if(xe&&xe.visible){const ge=M(T,xe,c,p);T.onBeforeShadow(e,T,N,q,G,ge,J),e.renderBufferDirect(q,null,G,ge,T,J),T.onAfterShadow(e,T,N,q,G,ge,J)}}}else if(z.visible){const K=M(T,z,c,p);T.onBeforeShadow(e,T,N,q,G,K,null),e.renderBufferDirect(q,null,G,K,T,null),T.onAfterShadow(e,T,N,q,G,K,null)}}const W=T.children;for(let G=0,z=W.length;G<z;G++)A(W[G],N,q,c,p)}function C(T){T.target.removeEventListener("dispose",C);for(const q in x){const c=x[q],p=T.target.uuid;p in c&&(c[p].dispose(),delete c[p])}}}const jf={[$n]:Kn,[qn]:zn,[Yn]:kn,[Sn]:Xn,[Kn]:$n,[zn]:qn,[kn]:Yn,[Xn]:Sn};function ed(e,n){function t(){let _=!1;const se=new pt;let j=null;const le=new pt(0,0,0,0);return{setMask:function(Z){j!==Z&&!_&&(e.colorMask(Z,Z,Z,Z),j=Z)},setLocked:function(Z){_=Z},setClear:function(Z,X,ee,be,Ke){Ke===!0&&(Z*=be,X*=be,ee*=be),se.set(Z,X,ee,be),le.equals(se)===!1&&(e.clearColor(Z,X,ee,be),le.copy(se))},reset:function(){_=!1,j=null,le.set(-1,0,0,0)}}}function i(){let _=!1,se=!1,j=null,le=null,Z=null;return{setReversed:function(X){if(se!==X){const ee=n.get("EXT_clip_control");X?ee.clipControlEXT(ee.LOWER_LEFT_EXT,ee.ZERO_TO_ONE_EXT):ee.clipControlEXT(ee.LOWER_LEFT_EXT,ee.NEGATIVE_ONE_TO_ONE_EXT),se=X;const be=Z;Z=null,this.setClear(be)}},getReversed:function(){return se},setTest:function(X){X?$(e.DEPTH_TEST):fe(e.DEPTH_TEST)},setMask:function(X){j!==X&&!_&&(e.depthMask(X),j=X)},setFunc:function(X){if(se&&(X=jf[X]),le!==X){switch(X){case $n:e.depthFunc(e.NEVER);break;case Kn:e.depthFunc(e.ALWAYS);break;case qn:e.depthFunc(e.LESS);break;case Sn:e.depthFunc(e.LEQUAL);break;case Yn:e.depthFunc(e.EQUAL);break;case Xn:e.depthFunc(e.GEQUAL);break;case zn:e.depthFunc(e.GREATER);break;case kn:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}le=X}},setLocked:function(X){_=X},setClear:function(X){Z!==X&&(se&&(X=1-X),e.clearDepth(X),Z=X)},reset:function(){_=!1,j=null,le=null,Z=null,se=!1}}}function l(){let _=!1,se=null,j=null,le=null,Z=null,X=null,ee=null,be=null,Ke=null;return{setTest:function(Ve){_||(Ve?$(e.STENCIL_TEST):fe(e.STENCIL_TEST))},setMask:function(Ve){se!==Ve&&!_&&(e.stencilMask(Ve),se=Ve)},setFunc:function(Ve,Et,Rt){(j!==Ve||le!==Et||Z!==Rt)&&(e.stencilFunc(Ve,Et,Rt),j=Ve,le=Et,Z=Rt)},setOp:function(Ve,Et,Rt){(X!==Ve||ee!==Et||be!==Rt)&&(e.stencilOp(Ve,Et,Rt),X=Ve,ee=Et,be=Rt)},setLocked:function(Ve){_=Ve},setClear:function(Ve){Ke!==Ve&&(e.clearStencil(Ve),Ke=Ve)},reset:function(){_=!1,se=null,j=null,le=null,Z=null,X=null,ee=null,be=null,Ke=null}}}const r=new t,h=new i,d=new l,b=new WeakMap,x=new WeakMap;let w={},g={},S=new WeakMap,R=[],O=null,U=!1,f=null,o=null,P=null,M=null,A=null,C=null,T=null,N=new Je(0,0,0),q=0,c=!1,p=null,L=null,W=null,G=null,z=null;const K=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let B=!1,V=0;const J=e.getParameter(e.VERSION);J.indexOf("WebGL")!==-1?(V=parseFloat(/^WebGL (\d)/.exec(J)[1]),B=V>=1):J.indexOf("OpenGL ES")!==-1&&(V=parseFloat(/^OpenGL ES (\d)/.exec(J)[1]),B=V>=2);let xe=null,ge={};const Ee=e.getParameter(e.SCISSOR_BOX),Oe=e.getParameter(e.VIEWPORT),we=new pt().fromArray(Ee),nt=new pt().fromArray(Oe);function je(_,se,j,le){const Z=new Uint8Array(4),X=e.createTexture();e.bindTexture(_,X),e.texParameteri(_,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(_,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let ee=0;ee<j;ee++)_===e.TEXTURE_3D||_===e.TEXTURE_2D_ARRAY?e.texImage3D(se,0,e.RGBA,1,1,le,0,e.RGBA,e.UNSIGNED_BYTE,Z):e.texImage2D(se+ee,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,Z);return X}const k={};k[e.TEXTURE_2D]=je(e.TEXTURE_2D,e.TEXTURE_2D,1),k[e.TEXTURE_CUBE_MAP]=je(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),k[e.TEXTURE_2D_ARRAY]=je(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),k[e.TEXTURE_3D]=je(e.TEXTURE_3D,e.TEXTURE_3D,1,1),r.setClear(0,0,0,1),h.setClear(1),d.setClear(0),$(e.DEPTH_TEST),h.setFunc(Sn),Le(!1),at(Xi),$(e.CULL_FACE),He(Ut);function $(_){w[_]!==!0&&(e.enable(_),w[_]=!0)}function fe(_){w[_]!==!1&&(e.disable(_),w[_]=!1)}function Ce(_,se){return g[_]!==se?(e.bindFramebuffer(_,se),g[_]=se,_===e.DRAW_FRAMEBUFFER&&(g[e.FRAMEBUFFER]=se),_===e.FRAMEBUFFER&&(g[e.DRAW_FRAMEBUFFER]=se),!0):!1}function pe(_,se){let j=R,le=!1;if(_){j=S.get(se),j===void 0&&(j=[],S.set(se,j));const Z=_.textures;if(j.length!==Z.length||j[0]!==e.COLOR_ATTACHMENT0){for(let X=0,ee=Z.length;X<ee;X++)j[X]=e.COLOR_ATTACHMENT0+X;j.length=Z.length,le=!0}}else j[0]!==e.BACK&&(j[0]=e.BACK,le=!0);le&&e.drawBuffers(j)}function Ne(_){return O!==_?(e.useProgram(_),O=_,!0):!1}const lt={[Qt]:e.FUNC_ADD,[hr]:e.FUNC_SUBTRACT,[pr]:e.FUNC_REVERSE_SUBTRACT};lt[mo]=e.MIN,lt[_o]=e.MAX;const Ie={[Lr]:e.ZERO,[Pr]:e.ONE,[Cr]:e.SRC_COLOR,[br]:e.SRC_ALPHA,[Rr]:e.SRC_ALPHA_SATURATE,[Ar]:e.DST_COLOR,[Tr]:e.DST_ALPHA,[Mr]:e.ONE_MINUS_SRC_COLOR,[xr]:e.ONE_MINUS_SRC_ALPHA,[Er]:e.ONE_MINUS_DST_COLOR,[Sr]:e.ONE_MINUS_DST_ALPHA,[vr]:e.CONSTANT_COLOR,[gr]:e.ONE_MINUS_CONSTANT_COLOR,[_r]:e.CONSTANT_ALPHA,[mr]:e.ONE_MINUS_CONSTANT_ALPHA};function He(_,se,j,le,Z,X,ee,be,Ke,Ve){if(_===Ut){U===!0&&(fe(e.BLEND),U=!1);return}if(U===!1&&($(e.BLEND),U=!0),_!==jr){if(_!==f||Ve!==c){if((o!==Qt||A!==Qt)&&(e.blendEquation(e.FUNC_ADD),o=Qt,A=Qt),Ve)switch(_){case _n:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case Ki:e.blendFunc(e.ONE,e.ONE);break;case qi:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case Yi:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:Qe("WebGLState: Invalid blending: ",_);break}else switch(_){case _n:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case Ki:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case qi:Qe("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case Yi:Qe("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:Qe("WebGLState: Invalid blending: ",_);break}P=null,M=null,C=null,T=null,N.set(0,0,0),q=0,f=_,c=Ve}return}Z=Z||se,X=X||j,ee=ee||le,(se!==o||Z!==A)&&(e.blendEquationSeparate(lt[se],lt[Z]),o=se,A=Z),(j!==P||le!==M||X!==C||ee!==T)&&(e.blendFuncSeparate(Ie[j],Ie[le],Ie[X],Ie[ee]),P=j,M=le,C=X,T=ee),(be.equals(N)===!1||Ke!==q)&&(e.blendColor(be.r,be.g,be.b,Ke),N.copy(be),q=Ke),f=_,c=!1}function ze(_,se){_.side===bt?fe(e.CULL_FACE):$(e.CULL_FACE);let j=_.side===St;se&&(j=!j),Le(j),_.blending===_n&&_.transparent===!1?He(Ut):He(_.blending,_.blendEquation,_.blendSrc,_.blendDst,_.blendEquationAlpha,_.blendSrcAlpha,_.blendDstAlpha,_.blendColor,_.blendAlpha,_.premultipliedAlpha),h.setFunc(_.depthFunc),h.setTest(_.depthTest),h.setMask(_.depthWrite),r.setMask(_.colorWrite);const le=_.stencilWrite;d.setTest(le),le&&(d.setMask(_.stencilWriteMask),d.setFunc(_.stencilFunc,_.stencilRef,_.stencilFuncMask),d.setOp(_.stencilFail,_.stencilZFail,_.stencilZPass)),rt(_.polygonOffset,_.polygonOffsetFactor,_.polygonOffsetUnits),_.alphaToCoverage===!0?$(e.SAMPLE_ALPHA_TO_COVERAGE):fe(e.SAMPLE_ALPHA_TO_COVERAGE)}function Le(_){p!==_&&(_?e.frontFace(e.CW):e.frontFace(e.CCW),p=_)}function at(_){_!==Qr?($(e.CULL_FACE),_!==L&&(_===Xi?e.cullFace(e.BACK):_===Jr?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))):fe(e.CULL_FACE),L=_}function m(_){_!==W&&(B&&e.lineWidth(_),W=_)}function rt(_,se,j){_?($(e.POLYGON_OFFSET_FILL),(G!==se||z!==j)&&(e.polygonOffset(se,j),G=se,z=j)):fe(e.POLYGON_OFFSET_FILL)}function Ge(_){_?$(e.SCISSOR_TEST):fe(e.SCISSOR_TEST)}function qe(_){_===void 0&&(_=e.TEXTURE0+K-1),xe!==_&&(e.activeTexture(_),xe=_)}function me(_,se,j){j===void 0&&(xe===null?j=e.TEXTURE0+K-1:j=xe);let le=ge[j];le===void 0&&(le={type:void 0,texture:void 0},ge[j]=le),(le.type!==_||le.texture!==se)&&(xe!==j&&(e.activeTexture(j),xe=j),e.bindTexture(_,se||k[_]),le.type=_,le.texture=se)}function u(){const _=ge[xe];_!==void 0&&_.type!==void 0&&(e.bindTexture(_.type,null),_.type=void 0,_.texture=void 0)}function a(){try{e.compressedTexImage2D(...arguments)}catch(_){Qe("WebGLState:",_)}}function v(){try{e.compressedTexImage3D(...arguments)}catch(_){Qe("WebGLState:",_)}}function H(){try{e.texSubImage2D(...arguments)}catch(_){Qe("WebGLState:",_)}}function Y(){try{e.texSubImage3D(...arguments)}catch(_){Qe("WebGLState:",_)}}function F(){try{e.compressedTexSubImage2D(...arguments)}catch(_){Qe("WebGLState:",_)}}function ve(){try{e.compressedTexSubImage3D(...arguments)}catch(_){Qe("WebGLState:",_)}}function te(){try{e.texStorage2D(...arguments)}catch(_){Qe("WebGLState:",_)}}function he(){try{e.texStorage3D(...arguments)}catch(_){Qe("WebGLState:",_)}}function Re(){try{e.texImage2D(...arguments)}catch(_){Qe("WebGLState:",_)}}function Q(){try{e.texImage3D(...arguments)}catch(_){Qe("WebGLState:",_)}}function ie(_){we.equals(_)===!1&&(e.scissor(_.x,_.y,_.z,_.w),we.copy(_))}function ue(_){nt.equals(_)===!1&&(e.viewport(_.x,_.y,_.z,_.w),nt.copy(_))}function _e(_,se){let j=x.get(se);j===void 0&&(j=new WeakMap,x.set(se,j));let le=j.get(_);le===void 0&&(le=e.getUniformBlockIndex(se,_.name),j.set(_,le))}function ne(_,se){const le=x.get(se).get(_);b.get(se)!==le&&(e.uniformBlockBinding(se,le,_.__bindingPointIndex),b.set(se,le))}function De(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),h.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),w={},xe=null,ge={},g={},S=new WeakMap,R=[],O=null,U=!1,f=null,o=null,P=null,M=null,A=null,C=null,T=null,N=new Je(0,0,0),q=0,c=!1,p=null,L=null,W=null,G=null,z=null,we.set(0,0,e.canvas.width,e.canvas.height),nt.set(0,0,e.canvas.width,e.canvas.height),r.reset(),h.reset(),d.reset()}return{buffers:{color:r,depth:h,stencil:d},enable:$,disable:fe,bindFramebuffer:Ce,drawBuffers:pe,useProgram:Ne,setBlending:He,setMaterial:ze,setFlipSided:Le,setCullFace:at,setLineWidth:m,setPolygonOffset:rt,setScissorTest:Ge,activeTexture:qe,bindTexture:me,unbindTexture:u,compressedTexImage2D:a,compressedTexImage3D:v,texImage2D:Re,texImage3D:Q,updateUBOMapping:_e,uniformBlockBinding:ne,texStorage2D:te,texStorage3D:he,texSubImage2D:H,texSubImage3D:Y,compressedTexSubImage2D:F,compressedTexSubImage3D:ve,scissor:ie,viewport:ue,reset:De}}function td(e,n,t,i,l,r,h){const d=n.has("WEBGL_multisampled_render_to_texture")?n.get("WEBGL_multisampled_render_to_texture"):null,b=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),x=new ht,w=new WeakMap;let g;const S=new WeakMap;let R=!1;try{R=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function O(u,a){return R?new OffscreenCanvas(u,a):co("canvas")}function U(u,a,v){let H=1;const Y=me(u);if((Y.width>v||Y.height>v)&&(H=v/Math.max(Y.width,Y.height)),H<1)if(typeof HTMLImageElement<"u"&&u instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&u instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&u instanceof ImageBitmap||typeof VideoFrame<"u"&&u instanceof VideoFrame){const F=Math.floor(H*Y.width),ve=Math.floor(H*Y.height);g===void 0&&(g=O(F,ve));const te=a?O(F,ve):g;return te.width=F,te.height=ve,te.getContext("2d").drawImage(u,0,0,F,ve),Ye("WebGLRenderer: Texture has been resized from ("+Y.width+"x"+Y.height+") to ("+F+"x"+ve+")."),te}else return"data"in u&&Ye("WebGLRenderer: Image in DataTexture is too big ("+Y.width+"x"+Y.height+")."),u;return u}function f(u){return u.generateMipmaps}function o(u){e.generateMipmap(u)}function P(u){return u.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:u.isWebGL3DRenderTarget?e.TEXTURE_3D:u.isWebGLArrayRenderTarget||u.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function M(u,a,v,H,Y=!1){if(u!==null){if(e[u]!==void 0)return e[u];Ye("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+u+"'")}let F=a;if(a===e.RED&&(v===e.FLOAT&&(F=e.R32F),v===e.HALF_FLOAT&&(F=e.R16F),v===e.UNSIGNED_BYTE&&(F=e.R8)),a===e.RED_INTEGER&&(v===e.UNSIGNED_BYTE&&(F=e.R8UI),v===e.UNSIGNED_SHORT&&(F=e.R16UI),v===e.UNSIGNED_INT&&(F=e.R32UI),v===e.BYTE&&(F=e.R8I),v===e.SHORT&&(F=e.R16I),v===e.INT&&(F=e.R32I)),a===e.RG&&(v===e.FLOAT&&(F=e.RG32F),v===e.HALF_FLOAT&&(F=e.RG16F),v===e.UNSIGNED_BYTE&&(F=e.RG8)),a===e.RG_INTEGER&&(v===e.UNSIGNED_BYTE&&(F=e.RG8UI),v===e.UNSIGNED_SHORT&&(F=e.RG16UI),v===e.UNSIGNED_INT&&(F=e.RG32UI),v===e.BYTE&&(F=e.RG8I),v===e.SHORT&&(F=e.RG16I),v===e.INT&&(F=e.RG32I)),a===e.RGB_INTEGER&&(v===e.UNSIGNED_BYTE&&(F=e.RGB8UI),v===e.UNSIGNED_SHORT&&(F=e.RGB16UI),v===e.UNSIGNED_INT&&(F=e.RGB32UI),v===e.BYTE&&(F=e.RGB8I),v===e.SHORT&&(F=e.RGB16I),v===e.INT&&(F=e.RGB32I)),a===e.RGBA_INTEGER&&(v===e.UNSIGNED_BYTE&&(F=e.RGBA8UI),v===e.UNSIGNED_SHORT&&(F=e.RGBA16UI),v===e.UNSIGNED_INT&&(F=e.RGBA32UI),v===e.BYTE&&(F=e.RGBA8I),v===e.SHORT&&(F=e.RGBA16I),v===e.INT&&(F=e.RGBA32I)),a===e.RGB&&(v===e.UNSIGNED_INT_5_9_9_9_REV&&(F=e.RGB9_E5),v===e.UNSIGNED_INT_10F_11F_11F_REV&&(F=e.R11F_G11F_B10F)),a===e.RGBA){const ve=Y?ka:it.getTransfer(H);v===e.FLOAT&&(F=e.RGBA32F),v===e.HALF_FLOAT&&(F=e.RGBA16F),v===e.UNSIGNED_BYTE&&(F=ve===Ze?e.SRGB8_ALPHA8:e.RGBA8),v===e.UNSIGNED_SHORT_4_4_4_4&&(F=e.RGBA4),v===e.UNSIGNED_SHORT_5_5_5_1&&(F=e.RGB5_A1)}return(F===e.R16F||F===e.R32F||F===e.RG16F||F===e.RG32F||F===e.RGBA16F||F===e.RGBA32F)&&n.get("EXT_color_buffer_float"),F}function A(u,a){let v;return u?a===null||a===Vt||a===on?v=e.DEPTH24_STENCIL8:a===Lt?v=e.DEPTH32F_STENCIL8:a===En&&(v=e.DEPTH24_STENCIL8,Ye("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):a===null||a===Vt||a===on?v=e.DEPTH_COMPONENT24:a===Lt?v=e.DEPTH_COMPONENT32F:a===En&&(v=e.DEPTH_COMPONENT16),v}function C(u,a){return f(u)===!0||u.isFramebufferTexture&&u.minFilter!==Ht&&u.minFilter!==vt?Math.log2(Math.max(a.width,a.height))+1:u.mipmaps!==void 0&&u.mipmaps.length>0?u.mipmaps.length:u.isCompressedTexture&&Array.isArray(u.image)?a.mipmaps.length:1}function T(u){const a=u.target;a.removeEventListener("dispose",T),q(a),a.isVideoTexture&&w.delete(a)}function N(u){const a=u.target;a.removeEventListener("dispose",N),p(a)}function q(u){const a=i.get(u);if(a.__webglInit===void 0)return;const v=u.source,H=S.get(v);if(H){const Y=H[a.__cacheKey];Y.usedTimes--,Y.usedTimes===0&&c(u),Object.keys(H).length===0&&S.delete(v)}i.remove(u)}function c(u){const a=i.get(u);e.deleteTexture(a.__webglTexture);const v=u.source,H=S.get(v);delete H[a.__cacheKey],h.memory.textures--}function p(u){const a=i.get(u);if(u.depthTexture&&(u.depthTexture.dispose(),i.remove(u.depthTexture)),u.isWebGLCubeRenderTarget)for(let H=0;H<6;H++){if(Array.isArray(a.__webglFramebuffer[H]))for(let Y=0;Y<a.__webglFramebuffer[H].length;Y++)e.deleteFramebuffer(a.__webglFramebuffer[H][Y]);else e.deleteFramebuffer(a.__webglFramebuffer[H]);a.__webglDepthbuffer&&e.deleteRenderbuffer(a.__webglDepthbuffer[H])}else{if(Array.isArray(a.__webglFramebuffer))for(let H=0;H<a.__webglFramebuffer.length;H++)e.deleteFramebuffer(a.__webglFramebuffer[H]);else e.deleteFramebuffer(a.__webglFramebuffer);if(a.__webglDepthbuffer&&e.deleteRenderbuffer(a.__webglDepthbuffer),a.__webglMultisampledFramebuffer&&e.deleteFramebuffer(a.__webglMultisampledFramebuffer),a.__webglColorRenderbuffer)for(let H=0;H<a.__webglColorRenderbuffer.length;H++)a.__webglColorRenderbuffer[H]&&e.deleteRenderbuffer(a.__webglColorRenderbuffer[H]);a.__webglDepthRenderbuffer&&e.deleteRenderbuffer(a.__webglDepthRenderbuffer)}const v=u.textures;for(let H=0,Y=v.length;H<Y;H++){const F=i.get(v[H]);F.__webglTexture&&(e.deleteTexture(F.__webglTexture),h.memory.textures--),i.remove(v[H])}i.remove(u)}let L=0;function W(){L=0}function G(){const u=L;return u>=l.maxTextures&&Ye("WebGLTextures: Trying to use "+u+" texture units while this GPU supports only "+l.maxTextures),L+=1,u}function z(u){const a=[];return a.push(u.wrapS),a.push(u.wrapT),a.push(u.wrapR||0),a.push(u.magFilter),a.push(u.minFilter),a.push(u.anisotropy),a.push(u.internalFormat),a.push(u.format),a.push(u.type),a.push(u.generateMipmaps),a.push(u.premultiplyAlpha),a.push(u.flipY),a.push(u.unpackAlignment),a.push(u.colorSpace),a.join()}function K(u,a){const v=i.get(u);if(u.isVideoTexture&&Ge(u),u.isRenderTargetTexture===!1&&u.isExternalTexture!==!0&&u.version>0&&v.__version!==u.version){const H=u.image;if(H===null)Ye("WebGLRenderer: Texture marked for update but no image data found.");else if(H.complete===!1)Ye("WebGLRenderer: Texture marked for update but image is incomplete");else{k(v,u,a);return}}else u.isExternalTexture&&(v.__webglTexture=u.sourceTexture?u.sourceTexture:null);t.bindTexture(e.TEXTURE_2D,v.__webglTexture,e.TEXTURE0+a)}function B(u,a){const v=i.get(u);if(u.isRenderTargetTexture===!1&&u.version>0&&v.__version!==u.version){k(v,u,a);return}else u.isExternalTexture&&(v.__webglTexture=u.sourceTexture?u.sourceTexture:null);t.bindTexture(e.TEXTURE_2D_ARRAY,v.__webglTexture,e.TEXTURE0+a)}function V(u,a){const v=i.get(u);if(u.isRenderTargetTexture===!1&&u.version>0&&v.__version!==u.version){k(v,u,a);return}t.bindTexture(e.TEXTURE_3D,v.__webglTexture,e.TEXTURE0+a)}function J(u,a){const v=i.get(u);if(u.isCubeDepthTexture!==!0&&u.version>0&&v.__version!==u.version){$(v,u,a);return}t.bindTexture(e.TEXTURE_CUBE_MAP,v.__webglTexture,e.TEXTURE0+a)}const xe={[Ur]:e.REPEAT,[Wn]:e.CLAMP_TO_EDGE,[Dr]:e.MIRRORED_REPEAT},ge={[Ht]:e.NEAREST,[wr]:e.NEAREST_MIPMAP_NEAREST,[fn]:e.NEAREST_MIPMAP_LINEAR,[vt]:e.LINEAR,[Dn]:e.LINEAR_MIPMAP_NEAREST,[en]:e.LINEAR_MIPMAP_LINEAR},Ee={[Br]:e.NEVER,[Or]:e.ALWAYS,[Fr]:e.LESS,[ti]:e.LEQUAL,[yr]:e.EQUAL,[ei]:e.GEQUAL,[Nr]:e.GREATER,[Ir]:e.NOTEQUAL};function Oe(u,a){if(a.type===Lt&&n.has("OES_texture_float_linear")===!1&&(a.magFilter===vt||a.magFilter===Dn||a.magFilter===fn||a.magFilter===en||a.minFilter===vt||a.minFilter===Dn||a.minFilter===fn||a.minFilter===en)&&Ye("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),e.texParameteri(u,e.TEXTURE_WRAP_S,xe[a.wrapS]),e.texParameteri(u,e.TEXTURE_WRAP_T,xe[a.wrapT]),(u===e.TEXTURE_3D||u===e.TEXTURE_2D_ARRAY)&&e.texParameteri(u,e.TEXTURE_WRAP_R,xe[a.wrapR]),e.texParameteri(u,e.TEXTURE_MAG_FILTER,ge[a.magFilter]),e.texParameteri(u,e.TEXTURE_MIN_FILTER,ge[a.minFilter]),a.compareFunction&&(e.texParameteri(u,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(u,e.TEXTURE_COMPARE_FUNC,Ee[a.compareFunction])),n.has("EXT_texture_filter_anisotropic")===!0){if(a.magFilter===Ht||a.minFilter!==fn&&a.minFilter!==en||a.type===Lt&&n.has("OES_texture_float_linear")===!1)return;if(a.anisotropy>1||i.get(a).__currentAnisotropy){const v=n.get("EXT_texture_filter_anisotropic");e.texParameterf(u,v.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,l.getMaxAnisotropy())),i.get(a).__currentAnisotropy=a.anisotropy}}}function we(u,a){let v=!1;u.__webglInit===void 0&&(u.__webglInit=!0,a.addEventListener("dispose",T));const H=a.source;let Y=S.get(H);Y===void 0&&(Y={},S.set(H,Y));const F=z(a);if(F!==u.__cacheKey){Y[F]===void 0&&(Y[F]={texture:e.createTexture(),usedTimes:0},h.memory.textures++,v=!0),Y[F].usedTimes++;const ve=Y[u.__cacheKey];ve!==void 0&&(Y[u.__cacheKey].usedTimes--,ve.usedTimes===0&&c(a)),u.__cacheKey=F,u.__webglTexture=Y[F].texture}return v}function nt(u,a,v){return Math.floor(Math.floor(u/v)/a)}function je(u,a,v,H){const F=u.updateRanges;if(F.length===0)t.texSubImage2D(e.TEXTURE_2D,0,0,0,a.width,a.height,v,H,a.data);else{F.sort((Q,ie)=>Q.start-ie.start);let ve=0;for(let Q=1;Q<F.length;Q++){const ie=F[ve],ue=F[Q],_e=ie.start+ie.count,ne=nt(ue.start,a.width,4),De=nt(ie.start,a.width,4);ue.start<=_e+1&&ne===De&&nt(ue.start+ue.count-1,a.width,4)===ne?ie.count=Math.max(ie.count,ue.start+ue.count-ie.start):(++ve,F[ve]=ue)}F.length=ve+1;const te=e.getParameter(e.UNPACK_ROW_LENGTH),he=e.getParameter(e.UNPACK_SKIP_PIXELS),Re=e.getParameter(e.UNPACK_SKIP_ROWS);e.pixelStorei(e.UNPACK_ROW_LENGTH,a.width);for(let Q=0,ie=F.length;Q<ie;Q++){const ue=F[Q],_e=Math.floor(ue.start/4),ne=Math.ceil(ue.count/4),De=_e%a.width,_=Math.floor(_e/a.width),se=ne,j=1;e.pixelStorei(e.UNPACK_SKIP_PIXELS,De),e.pixelStorei(e.UNPACK_SKIP_ROWS,_),t.texSubImage2D(e.TEXTURE_2D,0,De,_,se,j,v,H,a.data)}u.clearUpdateRanges(),e.pixelStorei(e.UNPACK_ROW_LENGTH,te),e.pixelStorei(e.UNPACK_SKIP_PIXELS,he),e.pixelStorei(e.UNPACK_SKIP_ROWS,Re)}}function k(u,a,v){let H=e.TEXTURE_2D;(a.isDataArrayTexture||a.isCompressedArrayTexture)&&(H=e.TEXTURE_2D_ARRAY),a.isData3DTexture&&(H=e.TEXTURE_3D);const Y=we(u,a),F=a.source;t.bindTexture(H,u.__webglTexture,e.TEXTURE0+v);const ve=i.get(F);if(F.version!==ve.__version||Y===!0){t.activeTexture(e.TEXTURE0+v);const te=it.getPrimaries(it.workingColorSpace),he=a.colorSpace===zt?null:it.getPrimaries(a.colorSpace),Re=a.colorSpace===zt||te===he?e.NONE:e.BROWSER_DEFAULT_WEBGL;e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,a.flipY),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,a.premultiplyAlpha),e.pixelStorei(e.UNPACK_ALIGNMENT,a.unpackAlignment),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,Re);let Q=U(a.image,!1,l.maxTextureSize);Q=qe(a,Q);const ie=r.convert(a.format,a.colorSpace),ue=r.convert(a.type);let _e=M(a.internalFormat,ie,ue,a.colorSpace,a.isVideoTexture);Oe(H,a);let ne;const De=a.mipmaps,_=a.isVideoTexture!==!0,se=ve.__version===void 0||Y===!0,j=F.dataReady,le=C(a,Q);if(a.isDepthTexture)_e=A(a.format===Xt,a.type),se&&(_?t.texStorage2D(e.TEXTURE_2D,1,_e,Q.width,Q.height):t.texImage2D(e.TEXTURE_2D,0,_e,Q.width,Q.height,0,ie,ue,null));else if(a.isDataTexture)if(De.length>0){_&&se&&t.texStorage2D(e.TEXTURE_2D,le,_e,De[0].width,De[0].height);for(let Z=0,X=De.length;Z<X;Z++)ne=De[Z],_?j&&t.texSubImage2D(e.TEXTURE_2D,Z,0,0,ne.width,ne.height,ie,ue,ne.data):t.texImage2D(e.TEXTURE_2D,Z,_e,ne.width,ne.height,0,ie,ue,ne.data);a.generateMipmaps=!1}else _?(se&&t.texStorage2D(e.TEXTURE_2D,le,_e,Q.width,Q.height),j&&je(a,Q,ie,ue)):t.texImage2D(e.TEXTURE_2D,0,_e,Q.width,Q.height,0,ie,ue,Q.data);else if(a.isCompressedTexture)if(a.isCompressedArrayTexture){_&&se&&t.texStorage3D(e.TEXTURE_2D_ARRAY,le,_e,De[0].width,De[0].height,Q.depth);for(let Z=0,X=De.length;Z<X;Z++)if(ne=De[Z],a.format!==Ct)if(ie!==null)if(_){if(j)if(a.layerUpdates.size>0){const ee=Zi(ne.width,ne.height,a.format,a.type);for(const be of a.layerUpdates){const Ke=ne.data.subarray(be*ee/ne.data.BYTES_PER_ELEMENT,(be+1)*ee/ne.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,Z,0,0,be,ne.width,ne.height,1,ie,Ke)}a.clearLayerUpdates()}else t.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,Z,0,0,0,ne.width,ne.height,Q.depth,ie,ne.data)}else t.compressedTexImage3D(e.TEXTURE_2D_ARRAY,Z,_e,ne.width,ne.height,Q.depth,0,ne.data,0,0);else Ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else _?j&&t.texSubImage3D(e.TEXTURE_2D_ARRAY,Z,0,0,0,ne.width,ne.height,Q.depth,ie,ue,ne.data):t.texImage3D(e.TEXTURE_2D_ARRAY,Z,_e,ne.width,ne.height,Q.depth,0,ie,ue,ne.data)}else{_&&se&&t.texStorage2D(e.TEXTURE_2D,le,_e,De[0].width,De[0].height);for(let Z=0,X=De.length;Z<X;Z++)ne=De[Z],a.format!==Ct?ie!==null?_?j&&t.compressedTexSubImage2D(e.TEXTURE_2D,Z,0,0,ne.width,ne.height,ie,ne.data):t.compressedTexImage2D(e.TEXTURE_2D,Z,_e,ne.width,ne.height,0,ne.data):Ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):_?j&&t.texSubImage2D(e.TEXTURE_2D,Z,0,0,ne.width,ne.height,ie,ue,ne.data):t.texImage2D(e.TEXTURE_2D,Z,_e,ne.width,ne.height,0,ie,ue,ne.data)}else if(a.isDataArrayTexture)if(_){if(se&&t.texStorage3D(e.TEXTURE_2D_ARRAY,le,_e,Q.width,Q.height,Q.depth),j)if(a.layerUpdates.size>0){const Z=Zi(Q.width,Q.height,a.format,a.type);for(const X of a.layerUpdates){const ee=Q.data.subarray(X*Z/Q.data.BYTES_PER_ELEMENT,(X+1)*Z/Q.data.BYTES_PER_ELEMENT);t.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,X,Q.width,Q.height,1,ie,ue,ee)}a.clearLayerUpdates()}else t.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,Q.width,Q.height,Q.depth,ie,ue,Q.data)}else t.texImage3D(e.TEXTURE_2D_ARRAY,0,_e,Q.width,Q.height,Q.depth,0,ie,ue,Q.data);else if(a.isData3DTexture)_?(se&&t.texStorage3D(e.TEXTURE_3D,le,_e,Q.width,Q.height,Q.depth),j&&t.texSubImage3D(e.TEXTURE_3D,0,0,0,0,Q.width,Q.height,Q.depth,ie,ue,Q.data)):t.texImage3D(e.TEXTURE_3D,0,_e,Q.width,Q.height,Q.depth,0,ie,ue,Q.data);else if(a.isFramebufferTexture){if(se)if(_)t.texStorage2D(e.TEXTURE_2D,le,_e,Q.width,Q.height);else{let Z=Q.width,X=Q.height;for(let ee=0;ee<le;ee++)t.texImage2D(e.TEXTURE_2D,ee,_e,Z,X,0,ie,ue,null),Z>>=1,X>>=1}}else if(De.length>0){if(_&&se){const Z=me(De[0]);t.texStorage2D(e.TEXTURE_2D,le,_e,Z.width,Z.height)}for(let Z=0,X=De.length;Z<X;Z++)ne=De[Z],_?j&&t.texSubImage2D(e.TEXTURE_2D,Z,0,0,ie,ue,ne):t.texImage2D(e.TEXTURE_2D,Z,_e,ie,ue,ne);a.generateMipmaps=!1}else if(_){if(se){const Z=me(Q);t.texStorage2D(e.TEXTURE_2D,le,_e,Z.width,Z.height)}j&&t.texSubImage2D(e.TEXTURE_2D,0,0,0,ie,ue,Q)}else t.texImage2D(e.TEXTURE_2D,0,_e,ie,ue,Q);f(a)&&o(H),ve.__version=F.version,a.onUpdate&&a.onUpdate(a)}u.__version=a.version}function $(u,a,v){if(a.image.length!==6)return;const H=we(u,a),Y=a.source;t.bindTexture(e.TEXTURE_CUBE_MAP,u.__webglTexture,e.TEXTURE0+v);const F=i.get(Y);if(Y.version!==F.__version||H===!0){t.activeTexture(e.TEXTURE0+v);const ve=it.getPrimaries(it.workingColorSpace),te=a.colorSpace===zt?null:it.getPrimaries(a.colorSpace),he=a.colorSpace===zt||ve===te?e.NONE:e.BROWSER_DEFAULT_WEBGL;e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,a.flipY),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,a.premultiplyAlpha),e.pixelStorei(e.UNPACK_ALIGNMENT,a.unpackAlignment),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,he);const Re=a.isCompressedTexture||a.image[0].isCompressedTexture,Q=a.image[0]&&a.image[0].isDataTexture,ie=[];for(let X=0;X<6;X++)!Re&&!Q?ie[X]=U(a.image[X],!0,l.maxCubemapSize):ie[X]=Q?a.image[X].image:a.image[X],ie[X]=qe(a,ie[X]);const ue=ie[0],_e=r.convert(a.format,a.colorSpace),ne=r.convert(a.type),De=M(a.internalFormat,_e,ne,a.colorSpace),_=a.isVideoTexture!==!0,se=F.__version===void 0||H===!0,j=Y.dataReady;let le=C(a,ue);Oe(e.TEXTURE_CUBE_MAP,a);let Z;if(Re){_&&se&&t.texStorage2D(e.TEXTURE_CUBE_MAP,le,De,ue.width,ue.height);for(let X=0;X<6;X++){Z=ie[X].mipmaps;for(let ee=0;ee<Z.length;ee++){const be=Z[ee];a.format!==Ct?_e!==null?_?j&&t.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee,0,0,be.width,be.height,_e,be.data):t.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee,De,be.width,be.height,0,be.data):Ye("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):_?j&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee,0,0,be.width,be.height,_e,ne,be.data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee,De,be.width,be.height,0,_e,ne,be.data)}}}else{if(Z=a.mipmaps,_&&se){Z.length>0&&le++;const X=me(ie[0]);t.texStorage2D(e.TEXTURE_CUBE_MAP,le,De,X.width,X.height)}for(let X=0;X<6;X++)if(Q){_?j&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,0,0,0,ie[X].width,ie[X].height,_e,ne,ie[X].data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,0,De,ie[X].width,ie[X].height,0,_e,ne,ie[X].data);for(let ee=0;ee<Z.length;ee++){const Ke=Z[ee].image[X].image;_?j&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee+1,0,0,Ke.width,Ke.height,_e,ne,Ke.data):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee+1,De,Ke.width,Ke.height,0,_e,ne,Ke.data)}}else{_?j&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,0,0,0,_e,ne,ie[X]):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,0,De,_e,ne,ie[X]);for(let ee=0;ee<Z.length;ee++){const be=Z[ee];_?j&&t.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee+1,0,0,_e,ne,be.image[X]):t.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+X,ee+1,De,_e,ne,be.image[X])}}}f(a)&&o(e.TEXTURE_CUBE_MAP),F.__version=Y.version,a.onUpdate&&a.onUpdate(a)}u.__version=a.version}function fe(u,a,v,H,Y,F){const ve=r.convert(v.format,v.colorSpace),te=r.convert(v.type),he=M(v.internalFormat,ve,te,v.colorSpace),Re=i.get(a),Q=i.get(v);if(Q.__renderTarget=a,!Re.__hasExternalTextures){const ie=Math.max(1,a.width>>F),ue=Math.max(1,a.height>>F);Y===e.TEXTURE_3D||Y===e.TEXTURE_2D_ARRAY?t.texImage3D(Y,F,he,ie,ue,a.depth,0,ve,te,null):t.texImage2D(Y,F,he,ie,ue,0,ve,te,null)}t.bindFramebuffer(e.FRAMEBUFFER,u),rt(a)?d.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,H,Y,Q.__webglTexture,0,m(a)):(Y===e.TEXTURE_2D||Y>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&Y<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,H,Y,Q.__webglTexture,F),t.bindFramebuffer(e.FRAMEBUFFER,null)}function Ce(u,a,v){if(e.bindRenderbuffer(e.RENDERBUFFER,u),a.depthBuffer){const H=a.depthTexture,Y=H&&H.isDepthTexture?H.type:null,F=A(a.stencilBuffer,Y),ve=a.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;rt(a)?d.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,m(a),F,a.width,a.height):v?e.renderbufferStorageMultisample(e.RENDERBUFFER,m(a),F,a.width,a.height):e.renderbufferStorage(e.RENDERBUFFER,F,a.width,a.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,ve,e.RENDERBUFFER,u)}else{const H=a.textures;for(let Y=0;Y<H.length;Y++){const F=H[Y],ve=r.convert(F.format,F.colorSpace),te=r.convert(F.type),he=M(F.internalFormat,ve,te,F.colorSpace);rt(a)?d.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,m(a),he,a.width,a.height):v?e.renderbufferStorageMultisample(e.RENDERBUFFER,m(a),he,a.width,a.height):e.renderbufferStorage(e.RENDERBUFFER,he,a.width,a.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function pe(u,a,v){const H=a.isWebGLCubeRenderTarget===!0;if(t.bindFramebuffer(e.FRAMEBUFFER,u),!(a.depthTexture&&a.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Y=i.get(a.depthTexture);if(Y.__renderTarget=a,(!Y.__webglTexture||a.depthTexture.image.width!==a.width||a.depthTexture.image.height!==a.height)&&(a.depthTexture.image.width=a.width,a.depthTexture.image.height=a.height,a.depthTexture.needsUpdate=!0),H){if(Y.__webglInit===void 0&&(Y.__webglInit=!0,a.depthTexture.addEventListener("dispose",T)),Y.__webglTexture===void 0){Y.__webglTexture=e.createTexture(),t.bindTexture(e.TEXTURE_CUBE_MAP,Y.__webglTexture),Oe(e.TEXTURE_CUBE_MAP,a.depthTexture);const Re=r.convert(a.depthTexture.format),Q=r.convert(a.depthTexture.type);let ie;a.depthTexture.format===Kt?ie=e.DEPTH_COMPONENT24:a.depthTexture.format===Xt&&(ie=e.DEPTH24_STENCIL8);for(let ue=0;ue<6;ue++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+ue,0,ie,a.width,a.height,0,Re,Q,null)}}else K(a.depthTexture,0);const F=Y.__webglTexture,ve=m(a),te=H?e.TEXTURE_CUBE_MAP_POSITIVE_X+v:e.TEXTURE_2D,he=a.depthTexture.format===Xt?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(a.depthTexture.format===Kt)rt(a)?d.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,he,te,F,0,ve):e.framebufferTexture2D(e.FRAMEBUFFER,he,te,F,0);else if(a.depthTexture.format===Xt)rt(a)?d.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,he,te,F,0,ve):e.framebufferTexture2D(e.FRAMEBUFFER,he,te,F,0);else throw new Error("Unknown depthTexture format")}function Ne(u){const a=i.get(u),v=u.isWebGLCubeRenderTarget===!0;if(a.__boundDepthTexture!==u.depthTexture){const H=u.depthTexture;if(a.__depthDisposeCallback&&a.__depthDisposeCallback(),H){const Y=()=>{delete a.__boundDepthTexture,delete a.__depthDisposeCallback,H.removeEventListener("dispose",Y)};H.addEventListener("dispose",Y),a.__depthDisposeCallback=Y}a.__boundDepthTexture=H}if(u.depthTexture&&!a.__autoAllocateDepthBuffer)if(v)for(let H=0;H<6;H++)pe(a.__webglFramebuffer[H],u,H);else{const H=u.texture.mipmaps;H&&H.length>0?pe(a.__webglFramebuffer[0],u,0):pe(a.__webglFramebuffer,u,0)}else if(v){a.__webglDepthbuffer=[];for(let H=0;H<6;H++)if(t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer[H]),a.__webglDepthbuffer[H]===void 0)a.__webglDepthbuffer[H]=e.createRenderbuffer(),Ce(a.__webglDepthbuffer[H],u,!1);else{const Y=u.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,F=a.__webglDepthbuffer[H];e.bindRenderbuffer(e.RENDERBUFFER,F),e.framebufferRenderbuffer(e.FRAMEBUFFER,Y,e.RENDERBUFFER,F)}}else{const H=u.texture.mipmaps;if(H&&H.length>0?t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer[0]):t.bindFramebuffer(e.FRAMEBUFFER,a.__webglFramebuffer),a.__webglDepthbuffer===void 0)a.__webglDepthbuffer=e.createRenderbuffer(),Ce(a.__webglDepthbuffer,u,!1);else{const Y=u.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,F=a.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,F),e.framebufferRenderbuffer(e.FRAMEBUFFER,Y,e.RENDERBUFFER,F)}}t.bindFramebuffer(e.FRAMEBUFFER,null)}function lt(u,a,v){const H=i.get(u);a!==void 0&&fe(H.__webglFramebuffer,u,u.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),v!==void 0&&Ne(u)}function Ie(u){const a=u.texture,v=i.get(u),H=i.get(a);u.addEventListener("dispose",N);const Y=u.textures,F=u.isWebGLCubeRenderTarget===!0,ve=Y.length>1;if(ve||(H.__webglTexture===void 0&&(H.__webglTexture=e.createTexture()),H.__version=a.version,h.memory.textures++),F){v.__webglFramebuffer=[];for(let te=0;te<6;te++)if(a.mipmaps&&a.mipmaps.length>0){v.__webglFramebuffer[te]=[];for(let he=0;he<a.mipmaps.length;he++)v.__webglFramebuffer[te][he]=e.createFramebuffer()}else v.__webglFramebuffer[te]=e.createFramebuffer()}else{if(a.mipmaps&&a.mipmaps.length>0){v.__webglFramebuffer=[];for(let te=0;te<a.mipmaps.length;te++)v.__webglFramebuffer[te]=e.createFramebuffer()}else v.__webglFramebuffer=e.createFramebuffer();if(ve)for(let te=0,he=Y.length;te<he;te++){const Re=i.get(Y[te]);Re.__webglTexture===void 0&&(Re.__webglTexture=e.createTexture(),h.memory.textures++)}if(u.samples>0&&rt(u)===!1){v.__webglMultisampledFramebuffer=e.createFramebuffer(),v.__webglColorRenderbuffer=[],t.bindFramebuffer(e.FRAMEBUFFER,v.__webglMultisampledFramebuffer);for(let te=0;te<Y.length;te++){const he=Y[te];v.__webglColorRenderbuffer[te]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,v.__webglColorRenderbuffer[te]);const Re=r.convert(he.format,he.colorSpace),Q=r.convert(he.type),ie=M(he.internalFormat,Re,Q,he.colorSpace,u.isXRRenderTarget===!0),ue=m(u);e.renderbufferStorageMultisample(e.RENDERBUFFER,ue,ie,u.width,u.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+te,e.RENDERBUFFER,v.__webglColorRenderbuffer[te])}e.bindRenderbuffer(e.RENDERBUFFER,null),u.depthBuffer&&(v.__webglDepthRenderbuffer=e.createRenderbuffer(),Ce(v.__webglDepthRenderbuffer,u,!0)),t.bindFramebuffer(e.FRAMEBUFFER,null)}}if(F){t.bindTexture(e.TEXTURE_CUBE_MAP,H.__webglTexture),Oe(e.TEXTURE_CUBE_MAP,a);for(let te=0;te<6;te++)if(a.mipmaps&&a.mipmaps.length>0)for(let he=0;he<a.mipmaps.length;he++)fe(v.__webglFramebuffer[te][he],u,a,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+te,he);else fe(v.__webglFramebuffer[te],u,a,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+te,0);f(a)&&o(e.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(ve){for(let te=0,he=Y.length;te<he;te++){const Re=Y[te],Q=i.get(Re);let ie=e.TEXTURE_2D;(u.isWebGL3DRenderTarget||u.isWebGLArrayRenderTarget)&&(ie=u.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),t.bindTexture(ie,Q.__webglTexture),Oe(ie,Re),fe(v.__webglFramebuffer,u,Re,e.COLOR_ATTACHMENT0+te,ie,0),f(Re)&&o(ie)}t.unbindTexture()}else{let te=e.TEXTURE_2D;if((u.isWebGL3DRenderTarget||u.isWebGLArrayRenderTarget)&&(te=u.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),t.bindTexture(te,H.__webglTexture),Oe(te,a),a.mipmaps&&a.mipmaps.length>0)for(let he=0;he<a.mipmaps.length;he++)fe(v.__webglFramebuffer[he],u,a,e.COLOR_ATTACHMENT0,te,he);else fe(v.__webglFramebuffer,u,a,e.COLOR_ATTACHMENT0,te,0);f(a)&&o(te),t.unbindTexture()}u.depthBuffer&&Ne(u)}function He(u){const a=u.textures;for(let v=0,H=a.length;v<H;v++){const Y=a[v];if(f(Y)){const F=P(u),ve=i.get(Y).__webglTexture;t.bindTexture(F,ve),o(F),t.unbindTexture()}}}const ze=[],Le=[];function at(u){if(u.samples>0){if(rt(u)===!1){const a=u.textures,v=u.width,H=u.height;let Y=e.COLOR_BUFFER_BIT;const F=u.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,ve=i.get(u),te=a.length>1;if(te)for(let Re=0;Re<a.length;Re++)t.bindFramebuffer(e.FRAMEBUFFER,ve.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+Re,e.RENDERBUFFER,null),t.bindFramebuffer(e.FRAMEBUFFER,ve.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+Re,e.TEXTURE_2D,null,0);t.bindFramebuffer(e.READ_FRAMEBUFFER,ve.__webglMultisampledFramebuffer);const he=u.texture.mipmaps;he&&he.length>0?t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ve.__webglFramebuffer[0]):t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ve.__webglFramebuffer);for(let Re=0;Re<a.length;Re++){if(u.resolveDepthBuffer&&(u.depthBuffer&&(Y|=e.DEPTH_BUFFER_BIT),u.stencilBuffer&&u.resolveStencilBuffer&&(Y|=e.STENCIL_BUFFER_BIT)),te){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,ve.__webglColorRenderbuffer[Re]);const Q=i.get(a[Re]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,Q,0)}e.blitFramebuffer(0,0,v,H,0,0,v,H,Y,e.NEAREST),b===!0&&(ze.length=0,Le.length=0,ze.push(e.COLOR_ATTACHMENT0+Re),u.depthBuffer&&u.resolveDepthBuffer===!1&&(ze.push(F),Le.push(F),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,Le)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,ze))}if(t.bindFramebuffer(e.READ_FRAMEBUFFER,null),t.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),te)for(let Re=0;Re<a.length;Re++){t.bindFramebuffer(e.FRAMEBUFFER,ve.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+Re,e.RENDERBUFFER,ve.__webglColorRenderbuffer[Re]);const Q=i.get(a[Re]).__webglTexture;t.bindFramebuffer(e.FRAMEBUFFER,ve.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+Re,e.TEXTURE_2D,Q,0)}t.bindFramebuffer(e.DRAW_FRAMEBUFFER,ve.__webglMultisampledFramebuffer)}else if(u.depthBuffer&&u.resolveDepthBuffer===!1&&b){const a=u.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[a])}}}function m(u){return Math.min(l.maxSamples,u.samples)}function rt(u){const a=i.get(u);return u.samples>0&&n.has("WEBGL_multisampled_render_to_texture")===!0&&a.__useRenderToTexture!==!1}function Ge(u){const a=h.render.frame;w.get(u)!==a&&(w.set(u,a),u.update())}function qe(u,a){const v=u.colorSpace,H=u.format,Y=u.type;return u.isCompressedTexture===!0||u.isVideoTexture===!0||v!==xn&&v!==zt&&(it.getTransfer(v)===Ze?(H!==Ct||Y!==Tt)&&Ye("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):Qe("WebGLTextures: Unsupported texture color space:",v)),a}function me(u){return typeof HTMLImageElement<"u"&&u instanceof HTMLImageElement?(x.width=u.naturalWidth||u.width,x.height=u.naturalHeight||u.height):typeof VideoFrame<"u"&&u instanceof VideoFrame?(x.width=u.displayWidth,x.height=u.displayHeight):(x.width=u.width,x.height=u.height),x}this.allocateTextureUnit=G,this.resetTextureUnits=W,this.setTexture2D=K,this.setTexture2DArray=B,this.setTexture3D=V,this.setTextureCube=J,this.rebindTextures=lt,this.setupRenderTarget=Ie,this.updateRenderTargetMipmap=He,this.updateMultisampleRenderTarget=at,this.setupDepthRenderbuffer=Ne,this.setupFrameBufferTexture=fe,this.useMultisampledRTT=rt,this.isReversedDepthBuffer=function(){return t.buffers.depth.getReversed()}}function nd(e,n){function t(i,l=zt){let r;const h=it.getTransfer(l);if(i===Tt)return e.UNSIGNED_BYTE;if(i===Pa)return e.UNSIGNED_SHORT_4_4_4_4;if(i===La)return e.UNSIGNED_SHORT_5_5_5_1;if(i===zr)return e.UNSIGNED_INT_5_9_9_9_REV;if(i===Xr)return e.UNSIGNED_INT_10F_11F_11F_REV;if(i===Yr)return e.BYTE;if(i===qr)return e.SHORT;if(i===En)return e.UNSIGNED_SHORT;if(i===wa)return e.INT;if(i===Vt)return e.UNSIGNED_INT;if(i===Lt)return e.FLOAT;if(i===wt)return e.HALF_FLOAT;if(i===Kr)return e.ALPHA;if(i===$r)return e.RGB;if(i===Ct)return e.RGBA;if(i===Kt)return e.DEPTH_COMPONENT;if(i===Xt)return e.DEPTH_STENCIL;if(i===Zr)return e.RED;if(i===Ca)return e.RED_INTEGER;if(i===sn)return e.RG;if(i===ba)return e.RG_INTEGER;if(i===Ra)return e.RGBA_INTEGER;if(i===Un||i===wn||i===In||i===Nn)if(h===Ze)if(r=n.get("WEBGL_compressed_texture_s3tc_srgb"),r!==null){if(i===Un)return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(i===wn)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(i===In)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(i===Nn)return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(r=n.get("WEBGL_compressed_texture_s3tc"),r!==null){if(i===Un)return r.COMPRESSED_RGB_S3TC_DXT1_EXT;if(i===wn)return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(i===In)return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(i===Nn)return r.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(i===pi||i===hi||i===mi||i===_i)if(r=n.get("WEBGL_compressed_texture_pvrtc"),r!==null){if(i===pi)return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(i===hi)return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(i===mi)return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(i===_i)return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(i===gi||i===vi||i===Si||i===Ei||i===xi||i===Mi||i===Ti)if(r=n.get("WEBGL_compressed_texture_etc"),r!==null){if(i===gi||i===vi)return h===Ze?r.COMPRESSED_SRGB8_ETC2:r.COMPRESSED_RGB8_ETC2;if(i===Si)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:r.COMPRESSED_RGBA8_ETC2_EAC;if(i===Ei)return r.COMPRESSED_R11_EAC;if(i===xi)return r.COMPRESSED_SIGNED_R11_EAC;if(i===Mi)return r.COMPRESSED_RG11_EAC;if(i===Ti)return r.COMPRESSED_SIGNED_RG11_EAC}else return null;if(i===Ai||i===Ri||i===bi||i===Ci||i===Pi||i===Li||i===Di||i===Ui||i===wi||i===Ii||i===Ni||i===yi||i===Fi||i===Oi)if(r=n.get("WEBGL_compressed_texture_astc"),r!==null){if(i===Ai)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:r.COMPRESSED_RGBA_ASTC_4x4_KHR;if(i===Ri)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:r.COMPRESSED_RGBA_ASTC_5x4_KHR;if(i===bi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:r.COMPRESSED_RGBA_ASTC_5x5_KHR;if(i===Ci)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:r.COMPRESSED_RGBA_ASTC_6x5_KHR;if(i===Pi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:r.COMPRESSED_RGBA_ASTC_6x6_KHR;if(i===Li)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:r.COMPRESSED_RGBA_ASTC_8x5_KHR;if(i===Di)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:r.COMPRESSED_RGBA_ASTC_8x6_KHR;if(i===Ui)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:r.COMPRESSED_RGBA_ASTC_8x8_KHR;if(i===wi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:r.COMPRESSED_RGBA_ASTC_10x5_KHR;if(i===Ii)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:r.COMPRESSED_RGBA_ASTC_10x6_KHR;if(i===Ni)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:r.COMPRESSED_RGBA_ASTC_10x8_KHR;if(i===yi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:r.COMPRESSED_RGBA_ASTC_10x10_KHR;if(i===Fi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:r.COMPRESSED_RGBA_ASTC_12x10_KHR;if(i===Oi)return h===Ze?r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:r.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(i===Bi||i===Gi||i===Hi)if(r=n.get("EXT_texture_compression_bptc"),r!==null){if(i===Bi)return h===Ze?r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:r.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(i===Gi)return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(i===Hi)return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(i===Vi||i===Wi||i===ki||i===zi)if(r=n.get("EXT_texture_compression_rgtc"),r!==null){if(i===Vi)return r.COMPRESSED_RED_RGTC1_EXT;if(i===Wi)return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(i===ki)return r.COMPRESSED_RED_GREEN_RGTC2_EXT;if(i===zi)return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return i===on?e.UNSIGNED_INT_24_8:e[i]!==void 0?e[i]:null}return{convert:t}}const id=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,ad=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class rd{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(n,t){if(this.texture===null){const i=new Da(n.texture);(n.depthNear!==t.depthNear||n.depthFar!==t.depthFar)&&(this.depthNear=n.depthNear,this.depthFar=n.depthFar),this.texture=i}}getMesh(n){if(this.texture!==null&&this.mesh===null){const t=n.cameras[0].viewport,i=new Nt({vertexShader:id,fragmentShader:ad,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new It(new Ua(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class od extends cr{constructor(n,t){super();const i=this;let l=null,r=1,h=null,d="local-floor",b=1,x=null,w=null,g=null,S=null,R=null,O=null;const U=typeof XRWebGLBinding<"u",f=new rd,o={},P=t.getContextAttributes();let M=null,A=null;const C=[],T=[],N=new ht;let q=null;const c=new pn;c.viewport=new pt;const p=new pn;p.viewport=new pt;const L=[c,p],W=new fr;let G=null,z=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(k){let $=C[k];return $===void 0&&($=new Ln,C[k]=$),$.getTargetRaySpace()},this.getControllerGrip=function(k){let $=C[k];return $===void 0&&($=new Ln,C[k]=$),$.getGripSpace()},this.getHand=function(k){let $=C[k];return $===void 0&&($=new Ln,C[k]=$),$.getHandSpace()};function K(k){const $=T.indexOf(k.inputSource);if($===-1)return;const fe=C[$];fe!==void 0&&(fe.update(k.inputSource,k.frame,x||h),fe.dispatchEvent({type:k.type,data:k.inputSource}))}function B(){l.removeEventListener("select",K),l.removeEventListener("selectstart",K),l.removeEventListener("selectend",K),l.removeEventListener("squeeze",K),l.removeEventListener("squeezestart",K),l.removeEventListener("squeezeend",K),l.removeEventListener("end",B),l.removeEventListener("inputsourceschange",V);for(let k=0;k<C.length;k++){const $=T[k];$!==null&&(T[k]=null,C[k].disconnect($))}G=null,z=null,f.reset();for(const k in o)delete o[k];n.setRenderTarget(M),R=null,S=null,g=null,l=null,A=null,je.stop(),i.isPresenting=!1,n.setPixelRatio(q),n.setSize(N.width,N.height,!1),i.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(k){r=k,i.isPresenting===!0&&Ye("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(k){d=k,i.isPresenting===!0&&Ye("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return x||h},this.setReferenceSpace=function(k){x=k},this.getBaseLayer=function(){return S!==null?S:R},this.getBinding=function(){return g===null&&U&&(g=new XRWebGLBinding(l,t)),g},this.getFrame=function(){return O},this.getSession=function(){return l},this.setSession=async function(k){if(l=k,l!==null){if(M=n.getRenderTarget(),l.addEventListener("select",K),l.addEventListener("selectstart",K),l.addEventListener("selectend",K),l.addEventListener("squeeze",K),l.addEventListener("squeezestart",K),l.addEventListener("squeezeend",K),l.addEventListener("end",B),l.addEventListener("inputsourceschange",V),P.xrCompatible!==!0&&await t.makeXRCompatible(),q=n.getPixelRatio(),n.getSize(N),U&&"createProjectionLayer"in XRWebGLBinding.prototype){let fe=null,Ce=null,pe=null;P.depth&&(pe=P.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,fe=P.stencil?Xt:Kt,Ce=P.stencil?on:Vt);const Ne={colorFormat:t.RGBA8,depthFormat:pe,scaleFactor:r};g=this.getBinding(),S=g.createProjectionLayer(Ne),l.updateRenderState({layers:[S]}),n.setPixelRatio(1),n.setSize(S.textureWidth,S.textureHeight,!1),A=new Pt(S.textureWidth,S.textureHeight,{format:Ct,type:Tt,depthTexture:new vn(S.textureWidth,S.textureHeight,Ce,void 0,void 0,void 0,void 0,void 0,void 0,fe),stencilBuffer:P.stencil,colorSpace:n.outputColorSpace,samples:P.antialias?4:0,resolveDepthBuffer:S.ignoreDepthValues===!1,resolveStencilBuffer:S.ignoreDepthValues===!1})}else{const fe={antialias:P.antialias,alpha:!0,depth:P.depth,stencil:P.stencil,framebufferScaleFactor:r};R=new XRWebGLLayer(l,t,fe),l.updateRenderState({baseLayer:R}),n.setPixelRatio(1),n.setSize(R.framebufferWidth,R.framebufferHeight,!1),A=new Pt(R.framebufferWidth,R.framebufferHeight,{format:Ct,type:Tt,colorSpace:n.outputColorSpace,stencilBuffer:P.stencil,resolveDepthBuffer:R.ignoreDepthValues===!1,resolveStencilBuffer:R.ignoreDepthValues===!1})}A.isXRRenderTarget=!0,this.setFoveation(b),x=null,h=await l.requestReferenceSpace(d),je.setContext(l),je.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return f.getDepthTexture()};function V(k){for(let $=0;$<k.removed.length;$++){const fe=k.removed[$],Ce=T.indexOf(fe);Ce>=0&&(T[Ce]=null,C[Ce].disconnect(fe))}for(let $=0;$<k.added.length;$++){const fe=k.added[$];let Ce=T.indexOf(fe);if(Ce===-1){for(let Ne=0;Ne<C.length;Ne++)if(Ne>=T.length){T.push(fe),Ce=Ne;break}else if(T[Ne]===null){T[Ne]=fe,Ce=Ne;break}if(Ce===-1)break}const pe=C[Ce];pe&&pe.connect(fe)}}const J=new Be,xe=new Be;function ge(k,$,fe){J.setFromMatrixPosition($.matrixWorld),xe.setFromMatrixPosition(fe.matrixWorld);const Ce=J.distanceTo(xe),pe=$.projectionMatrix.elements,Ne=fe.projectionMatrix.elements,lt=pe[14]/(pe[10]-1),Ie=pe[14]/(pe[10]+1),He=(pe[9]+1)/pe[5],ze=(pe[9]-1)/pe[5],Le=(pe[8]-1)/pe[0],at=(Ne[8]+1)/Ne[0],m=lt*Le,rt=lt*at,Ge=Ce/(-Le+at),qe=Ge*-Le;if($.matrixWorld.decompose(k.position,k.quaternion,k.scale),k.translateX(qe),k.translateZ(Ge),k.matrixWorld.compose(k.position,k.quaternion,k.scale),k.matrixWorldInverse.copy(k.matrixWorld).invert(),pe[10]===-1)k.projectionMatrix.copy($.projectionMatrix),k.projectionMatrixInverse.copy($.projectionMatrixInverse);else{const me=lt+Ge,u=Ie+Ge,a=m-qe,v=rt+(Ce-qe),H=He*Ie/u*me,Y=ze*Ie/u*me;k.projectionMatrix.makePerspective(a,v,H,Y,me,u),k.projectionMatrixInverse.copy(k.projectionMatrix).invert()}}function Ee(k,$){$===null?k.matrixWorld.copy(k.matrix):k.matrixWorld.multiplyMatrices($.matrixWorld,k.matrix),k.matrixWorldInverse.copy(k.matrixWorld).invert()}this.updateCamera=function(k){if(l===null)return;let $=k.near,fe=k.far;f.texture!==null&&(f.depthNear>0&&($=f.depthNear),f.depthFar>0&&(fe=f.depthFar)),W.near=p.near=c.near=$,W.far=p.far=c.far=fe,(G!==W.near||z!==W.far)&&(l.updateRenderState({depthNear:W.near,depthFar:W.far}),G=W.near,z=W.far),W.layers.mask=k.layers.mask|6,c.layers.mask=W.layers.mask&3,p.layers.mask=W.layers.mask&5;const Ce=k.parent,pe=W.cameras;Ee(W,Ce);for(let Ne=0;Ne<pe.length;Ne++)Ee(pe[Ne],Ce);pe.length===2?ge(W,c,p):W.projectionMatrix.copy(c.projectionMatrix),Oe(k,W,Ce)};function Oe(k,$,fe){fe===null?k.matrix.copy($.matrixWorld):(k.matrix.copy(fe.matrixWorld),k.matrix.invert(),k.matrix.multiply($.matrixWorld)),k.matrix.decompose(k.position,k.quaternion,k.scale),k.updateMatrixWorld(!0),k.projectionMatrix.copy($.projectionMatrix),k.projectionMatrixInverse.copy($.projectionMatrixInverse),k.isPerspectiveCamera&&(k.fov=dr*2*Math.atan(1/k.projectionMatrix.elements[5]),k.zoom=1)}this.getCamera=function(){return W},this.getFoveation=function(){if(!(S===null&&R===null))return b},this.setFoveation=function(k){b=k,S!==null&&(S.fixedFoveation=k),R!==null&&R.fixedFoveation!==void 0&&(R.fixedFoveation=k)},this.hasDepthSensing=function(){return f.texture!==null},this.getDepthSensingMesh=function(){return f.getMesh(W)},this.getCameraTexture=function(k){return o[k]};let we=null;function nt(k,$){if(w=$.getViewerPose(x||h),O=$,w!==null){const fe=w.views;R!==null&&(n.setRenderTargetFramebuffer(A,R.framebuffer),n.setRenderTarget(A));let Ce=!1;fe.length!==W.cameras.length&&(W.cameras.length=0,Ce=!0);for(let Ie=0;Ie<fe.length;Ie++){const He=fe[Ie];let ze=null;if(R!==null)ze=R.getViewport(He);else{const at=g.getViewSubImage(S,He);ze=at.viewport,Ie===0&&(n.setRenderTargetTextures(A,at.colorTexture,at.depthStencilTexture),n.setRenderTarget(A))}let Le=L[Ie];Le===void 0&&(Le=new pn,Le.layers.enable(Ie),Le.viewport=new pt,L[Ie]=Le),Le.matrix.fromArray(He.transform.matrix),Le.matrix.decompose(Le.position,Le.quaternion,Le.scale),Le.projectionMatrix.fromArray(He.projectionMatrix),Le.projectionMatrixInverse.copy(Le.projectionMatrix).invert(),Le.viewport.set(ze.x,ze.y,ze.width,ze.height),Ie===0&&(W.matrix.copy(Le.matrix),W.matrix.decompose(W.position,W.quaternion,W.scale)),Ce===!0&&W.cameras.push(Le)}const pe=l.enabledFeatures;if(pe&&pe.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&U){g=i.getBinding();const Ie=g.getDepthInformation(fe[0]);Ie&&Ie.isValid&&Ie.texture&&f.init(Ie,l.renderState)}if(pe&&pe.includes("camera-access")&&U){n.state.unbindTexture(),g=i.getBinding();for(let Ie=0;Ie<fe.length;Ie++){const He=fe[Ie].camera;if(He){let ze=o[He];ze||(ze=new Da,o[He]=ze);const Le=g.getCameraImage(He);ze.sourceTexture=Le}}}}for(let fe=0;fe<C.length;fe++){const Ce=T[fe],pe=C[fe];Ce!==null&&pe!==void 0&&pe.update(Ce,$,x||h)}we&&we(k,$),$.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:$}),O=null}const je=new za;je.setAnimationLoop(nt),this.setAnimationLoop=function(k){we=k},this.dispose=function(){}}}const Bt=new ya,sd=new Yt;function ld(e,n){function t(f,o){f.matrixAutoUpdate===!0&&f.updateMatrix(),o.value.copy(f.matrix)}function i(f,o){o.color.getRGB(f.fogColor.value,Na(e)),o.isFog?(f.fogNear.value=o.near,f.fogFar.value=o.far):o.isFogExp2&&(f.fogDensity.value=o.density)}function l(f,o,P,M,A){o.isMeshBasicMaterial||o.isMeshLambertMaterial?r(f,o):o.isMeshToonMaterial?(r(f,o),g(f,o)):o.isMeshPhongMaterial?(r(f,o),w(f,o)):o.isMeshStandardMaterial?(r(f,o),S(f,o),o.isMeshPhysicalMaterial&&R(f,o,A)):o.isMeshMatcapMaterial?(r(f,o),O(f,o)):o.isMeshDepthMaterial?r(f,o):o.isMeshDistanceMaterial?(r(f,o),U(f,o)):o.isMeshNormalMaterial?r(f,o):o.isLineBasicMaterial?(h(f,o),o.isLineDashedMaterial&&d(f,o)):o.isPointsMaterial?b(f,o,P,M):o.isSpriteMaterial?x(f,o):o.isShadowMaterial?(f.color.value.copy(o.color),f.opacity.value=o.opacity):o.isShaderMaterial&&(o.uniformsNeedUpdate=!1)}function r(f,o){f.opacity.value=o.opacity,o.color&&f.diffuse.value.copy(o.color),o.emissive&&f.emissive.value.copy(o.emissive).multiplyScalar(o.emissiveIntensity),o.map&&(f.map.value=o.map,t(o.map,f.mapTransform)),o.alphaMap&&(f.alphaMap.value=o.alphaMap,t(o.alphaMap,f.alphaMapTransform)),o.bumpMap&&(f.bumpMap.value=o.bumpMap,t(o.bumpMap,f.bumpMapTransform),f.bumpScale.value=o.bumpScale,o.side===St&&(f.bumpScale.value*=-1)),o.normalMap&&(f.normalMap.value=o.normalMap,t(o.normalMap,f.normalMapTransform),f.normalScale.value.copy(o.normalScale),o.side===St&&f.normalScale.value.negate()),o.displacementMap&&(f.displacementMap.value=o.displacementMap,t(o.displacementMap,f.displacementMapTransform),f.displacementScale.value=o.displacementScale,f.displacementBias.value=o.displacementBias),o.emissiveMap&&(f.emissiveMap.value=o.emissiveMap,t(o.emissiveMap,f.emissiveMapTransform)),o.specularMap&&(f.specularMap.value=o.specularMap,t(o.specularMap,f.specularMapTransform)),o.alphaTest>0&&(f.alphaTest.value=o.alphaTest);const P=n.get(o),M=P.envMap,A=P.envMapRotation;M&&(f.envMap.value=M,Bt.copy(A),Bt.x*=-1,Bt.y*=-1,Bt.z*=-1,M.isCubeTexture&&M.isRenderTargetTexture===!1&&(Bt.y*=-1,Bt.z*=-1),f.envMapRotation.value.setFromMatrix4(sd.makeRotationFromEuler(Bt)),f.flipEnvMap.value=M.isCubeTexture&&M.isRenderTargetTexture===!1?-1:1,f.reflectivity.value=o.reflectivity,f.ior.value=o.ior,f.refractionRatio.value=o.refractionRatio),o.lightMap&&(f.lightMap.value=o.lightMap,f.lightMapIntensity.value=o.lightMapIntensity,t(o.lightMap,f.lightMapTransform)),o.aoMap&&(f.aoMap.value=o.aoMap,f.aoMapIntensity.value=o.aoMapIntensity,t(o.aoMap,f.aoMapTransform))}function h(f,o){f.diffuse.value.copy(o.color),f.opacity.value=o.opacity,o.map&&(f.map.value=o.map,t(o.map,f.mapTransform))}function d(f,o){f.dashSize.value=o.dashSize,f.totalSize.value=o.dashSize+o.gapSize,f.scale.value=o.scale}function b(f,o,P,M){f.diffuse.value.copy(o.color),f.opacity.value=o.opacity,f.size.value=o.size*P,f.scale.value=M*.5,o.map&&(f.map.value=o.map,t(o.map,f.uvTransform)),o.alphaMap&&(f.alphaMap.value=o.alphaMap,t(o.alphaMap,f.alphaMapTransform)),o.alphaTest>0&&(f.alphaTest.value=o.alphaTest)}function x(f,o){f.diffuse.value.copy(o.color),f.opacity.value=o.opacity,f.rotation.value=o.rotation,o.map&&(f.map.value=o.map,t(o.map,f.mapTransform)),o.alphaMap&&(f.alphaMap.value=o.alphaMap,t(o.alphaMap,f.alphaMapTransform)),o.alphaTest>0&&(f.alphaTest.value=o.alphaTest)}function w(f,o){f.specular.value.copy(o.specular),f.shininess.value=Math.max(o.shininess,1e-4)}function g(f,o){o.gradientMap&&(f.gradientMap.value=o.gradientMap)}function S(f,o){f.metalness.value=o.metalness,o.metalnessMap&&(f.metalnessMap.value=o.metalnessMap,t(o.metalnessMap,f.metalnessMapTransform)),f.roughness.value=o.roughness,o.roughnessMap&&(f.roughnessMap.value=o.roughnessMap,t(o.roughnessMap,f.roughnessMapTransform)),o.envMap&&(f.envMapIntensity.value=o.envMapIntensity)}function R(f,o,P){f.ior.value=o.ior,o.sheen>0&&(f.sheenColor.value.copy(o.sheenColor).multiplyScalar(o.sheen),f.sheenRoughness.value=o.sheenRoughness,o.sheenColorMap&&(f.sheenColorMap.value=o.sheenColorMap,t(o.sheenColorMap,f.sheenColorMapTransform)),o.sheenRoughnessMap&&(f.sheenRoughnessMap.value=o.sheenRoughnessMap,t(o.sheenRoughnessMap,f.sheenRoughnessMapTransform))),o.clearcoat>0&&(f.clearcoat.value=o.clearcoat,f.clearcoatRoughness.value=o.clearcoatRoughness,o.clearcoatMap&&(f.clearcoatMap.value=o.clearcoatMap,t(o.clearcoatMap,f.clearcoatMapTransform)),o.clearcoatRoughnessMap&&(f.clearcoatRoughnessMap.value=o.clearcoatRoughnessMap,t(o.clearcoatRoughnessMap,f.clearcoatRoughnessMapTransform)),o.clearcoatNormalMap&&(f.clearcoatNormalMap.value=o.clearcoatNormalMap,t(o.clearcoatNormalMap,f.clearcoatNormalMapTransform),f.clearcoatNormalScale.value.copy(o.clearcoatNormalScale),o.side===St&&f.clearcoatNormalScale.value.negate())),o.dispersion>0&&(f.dispersion.value=o.dispersion),o.iridescence>0&&(f.iridescence.value=o.iridescence,f.iridescenceIOR.value=o.iridescenceIOR,f.iridescenceThicknessMinimum.value=o.iridescenceThicknessRange[0],f.iridescenceThicknessMaximum.value=o.iridescenceThicknessRange[1],o.iridescenceMap&&(f.iridescenceMap.value=o.iridescenceMap,t(o.iridescenceMap,f.iridescenceMapTransform)),o.iridescenceThicknessMap&&(f.iridescenceThicknessMap.value=o.iridescenceThicknessMap,t(o.iridescenceThicknessMap,f.iridescenceThicknessMapTransform))),o.transmission>0&&(f.transmission.value=o.transmission,f.transmissionSamplerMap.value=P.texture,f.transmissionSamplerSize.value.set(P.width,P.height),o.transmissionMap&&(f.transmissionMap.value=o.transmissionMap,t(o.transmissionMap,f.transmissionMapTransform)),f.thickness.value=o.thickness,o.thicknessMap&&(f.thicknessMap.value=o.thicknessMap,t(o.thicknessMap,f.thicknessMapTransform)),f.attenuationDistance.value=o.attenuationDistance,f.attenuationColor.value.copy(o.attenuationColor)),o.anisotropy>0&&(f.anisotropyVector.value.set(o.anisotropy*Math.cos(o.anisotropyRotation),o.anisotropy*Math.sin(o.anisotropyRotation)),o.anisotropyMap&&(f.anisotropyMap.value=o.anisotropyMap,t(o.anisotropyMap,f.anisotropyMapTransform))),f.specularIntensity.value=o.specularIntensity,f.specularColor.value.copy(o.specularColor),o.specularColorMap&&(f.specularColorMap.value=o.specularColorMap,t(o.specularColorMap,f.specularColorMapTransform)),o.specularIntensityMap&&(f.specularIntensityMap.value=o.specularIntensityMap,t(o.specularIntensityMap,f.specularIntensityMapTransform))}function O(f,o){o.matcap&&(f.matcap.value=o.matcap)}function U(f,o){const P=n.get(o).light;f.referencePosition.value.setFromMatrixPosition(P.matrixWorld),f.nearDistance.value=P.shadow.camera.near,f.farDistance.value=P.shadow.camera.far}return{refreshFogUniforms:i,refreshMaterialUniforms:l}}function cd(e,n,t,i){let l={},r={},h=[];const d=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function b(P,M){const A=M.program;i.uniformBlockBinding(P,A)}function x(P,M){let A=l[P.id];A===void 0&&(O(P),A=w(P),l[P.id]=A,P.addEventListener("dispose",f));const C=M.program;i.updateUBOMapping(P,C);const T=n.render.frame;r[P.id]!==T&&(S(P),r[P.id]=T)}function w(P){const M=g();P.__bindingPointIndex=M;const A=e.createBuffer(),C=P.__size,T=P.usage;return e.bindBuffer(e.UNIFORM_BUFFER,A),e.bufferData(e.UNIFORM_BUFFER,C,T),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,M,A),A}function g(){for(let P=0;P<d;P++)if(h.indexOf(P)===-1)return h.push(P),P;return Qe("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function S(P){const M=l[P.id],A=P.uniforms,C=P.__cache;e.bindBuffer(e.UNIFORM_BUFFER,M);for(let T=0,N=A.length;T<N;T++){const q=Array.isArray(A[T])?A[T]:[A[T]];for(let c=0,p=q.length;c<p;c++){const L=q[c];if(R(L,T,c,C)===!0){const W=L.__offset,G=Array.isArray(L.value)?L.value:[L.value];let z=0;for(let K=0;K<G.length;K++){const B=G[K],V=U(B);typeof B=="number"||typeof B=="boolean"?(L.__data[0]=B,e.bufferSubData(e.UNIFORM_BUFFER,W+z,L.__data)):B.isMatrix3?(L.__data[0]=B.elements[0],L.__data[1]=B.elements[1],L.__data[2]=B.elements[2],L.__data[3]=0,L.__data[4]=B.elements[3],L.__data[5]=B.elements[4],L.__data[6]=B.elements[5],L.__data[7]=0,L.__data[8]=B.elements[6],L.__data[9]=B.elements[7],L.__data[10]=B.elements[8],L.__data[11]=0):(B.toArray(L.__data,z),z+=V.storage/Float32Array.BYTES_PER_ELEMENT)}e.bufferSubData(e.UNIFORM_BUFFER,W,L.__data)}}}e.bindBuffer(e.UNIFORM_BUFFER,null)}function R(P,M,A,C){const T=P.value,N=M+"_"+A;if(C[N]===void 0)return typeof T=="number"||typeof T=="boolean"?C[N]=T:C[N]=T.clone(),!0;{const q=C[N];if(typeof T=="number"||typeof T=="boolean"){if(q!==T)return C[N]=T,!0}else if(q.equals(T)===!1)return q.copy(T),!0}return!1}function O(P){const M=P.uniforms;let A=0;const C=16;for(let N=0,q=M.length;N<q;N++){const c=Array.isArray(M[N])?M[N]:[M[N]];for(let p=0,L=c.length;p<L;p++){const W=c[p],G=Array.isArray(W.value)?W.value:[W.value];for(let z=0,K=G.length;z<K;z++){const B=G[z],V=U(B),J=A%C,xe=J%V.boundary,ge=J+xe;A+=xe,ge!==0&&C-ge<V.storage&&(A+=C-ge),W.__data=new Float32Array(V.storage/Float32Array.BYTES_PER_ELEMENT),W.__offset=A,A+=V.storage}}}const T=A%C;return T>0&&(A+=C-T),P.__size=A,P.__cache={},this}function U(P){const M={boundary:0,storage:0};return typeof P=="number"||typeof P=="boolean"?(M.boundary=4,M.storage=4):P.isVector2?(M.boundary=8,M.storage=8):P.isVector3||P.isColor?(M.boundary=16,M.storage=12):P.isVector4?(M.boundary=16,M.storage=16):P.isMatrix3?(M.boundary=48,M.storage=48):P.isMatrix4?(M.boundary=64,M.storage=64):P.isTexture?Ye("WebGLRenderer: Texture samplers can not be part of an uniforms group."):Ye("WebGLRenderer: Unsupported uniform value type.",P),M}function f(P){const M=P.target;M.removeEventListener("dispose",f);const A=h.indexOf(M.__bindingPointIndex);h.splice(A,1),e.deleteBuffer(l[M.id]),delete l[M.id],delete r[M.id]}function o(){for(const P in l)e.deleteBuffer(l[P]);h=[],l={},r={}}return{bind:b,update:x,dispose:o}}const fd=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let xt=null;function dd(){return xt===null&&(xt=new ur(fd,16,16,sn,wt),xt.name="DFG_LUT",xt.minFilter=vt,xt.magFilter=vt,xt.wrapS=Wn,xt.wrapT=Wn,xt.generateMipmaps=!1,xt.needsUpdate=!0),xt}class pd{constructor(n={}){const{canvas:t=ir(),context:i=null,depth:l=!0,stencil:r=!1,alpha:h=!1,antialias:d=!1,premultipliedAlpha:b=!0,preserveDrawingBuffer:x=!1,powerPreference:w="default",failIfMajorPerformanceCaveat:g=!1,reversedDepthBuffer:S=!1,outputBufferType:R=Tt}=n;this.isWebGLRenderer=!0;let O;if(i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");O=i.getContextAttributes().alpha}else O=h;const U=R,f=new Set([Ra,ba,Ca]),o=new Set([Tt,Vt,En,on,Pa,La]),P=new Uint32Array(4),M=new Int32Array(4);let A=null,C=null;const T=[],N=[];let q=null;this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=At,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const c=this;let p=!1;this._outputColorSpace=ar;let L=0,W=0,G=null,z=-1,K=null;const B=new pt,V=new pt;let J=null;const xe=new Je(0);let ge=0,Ee=t.width,Oe=t.height,we=1,nt=null,je=null;const k=new pt(0,0,Ee,Oe),$=new pt(0,0,Ee,Oe);let fe=!1;const Ce=new xa;let pe=!1,Ne=!1;const lt=new Yt,Ie=new Be,He=new pt,ze={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Le=!1;function at(){return G===null?we:1}let m=i;function rt(s,E){return t.getContext(s,E)}try{const s={alpha:!0,depth:l,stencil:r,antialias:d,premultipliedAlpha:b,preserveDrawingBuffer:x,powerPreference:w,failIfMajorPerformanceCaveat:g};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${rr}`),t.addEventListener("webglcontextlost",be,!1),t.addEventListener("webglcontextrestored",Ke,!1),t.addEventListener("webglcontextcreationerror",Ve,!1),m===null){const E="webgl2";if(m=rt(E,s),m===null)throw rt(E)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(s){throw Qe("WebGLRenderer: "+s.message),s}let Ge,qe,me,u,a,v,H,Y,F,ve,te,he,Re,Q,ie,ue,_e,ne,De,_,se,j,le,Z;function X(){Ge=new fc(m),Ge.init(),j=new nd(m,Ge),qe=new tc(m,Ge,n,j),me=new ed(m,Ge),qe.reversedDepthBuffer&&S&&me.buffers.depth.setReversed(!0),u=new pc(m),a=new Gf,v=new td(m,Ge,me,a,qe,j,u),H=new ic(c),Y=new cc(c),F=new go(m),le=new jl(m,F),ve=new dc(m,F,u,le),te=new mc(m,ve,F,u),De=new hc(m,qe,v),ue=new nc(a),he=new Bf(c,H,Y,Ge,qe,le,ue),Re=new ld(c,a),Q=new Vf,ie=new qf(Ge),ne=new Jl(c,H,Y,me,te,O,b),_e=new Jf(c,te,qe),Z=new cd(m,u,qe,me),_=new ec(m,Ge,u),se=new uc(m,Ge,u),u.programs=he.programs,c.capabilities=qe,c.extensions=Ge,c.properties=a,c.renderLists=Q,c.shadowMap=_e,c.state=me,c.info=u}X(),U!==Tt&&(q=new gc(U,t.width,t.height,l,r));const ee=new od(c,m);this.xr=ee,this.getContext=function(){return m},this.getContextAttributes=function(){return m.getContextAttributes()},this.forceContextLoss=function(){const s=Ge.get("WEBGL_lose_context");s&&s.loseContext()},this.forceContextRestore=function(){const s=Ge.get("WEBGL_lose_context");s&&s.restoreContext()},this.getPixelRatio=function(){return we},this.setPixelRatio=function(s){s!==void 0&&(we=s,this.setSize(Ee,Oe,!1))},this.getSize=function(s){return s.set(Ee,Oe)},this.setSize=function(s,E,y=!0){if(ee.isPresenting){Ye("WebGLRenderer: Can't change size while VR device is presenting.");return}Ee=s,Oe=E,t.width=Math.floor(s*we),t.height=Math.floor(E*we),y===!0&&(t.style.width=s+"px",t.style.height=E+"px"),q!==null&&q.setSize(t.width,t.height),this.setViewport(0,0,s,E)},this.getDrawingBufferSize=function(s){return s.set(Ee*we,Oe*we).floor()},this.setDrawingBufferSize=function(s,E,y){Ee=s,Oe=E,we=y,t.width=Math.floor(s*y),t.height=Math.floor(E*y),this.setViewport(0,0,s,E)},this.setEffects=function(s){if(U===Tt){console.error("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(s){for(let E=0;E<s.length;E++)if(s[E].isOutputPass===!0){console.warn("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}q.setEffects(s||[])},this.getCurrentViewport=function(s){return s.copy(B)},this.getViewport=function(s){return s.copy(k)},this.setViewport=function(s,E,y,I){s.isVector4?k.set(s.x,s.y,s.z,s.w):k.set(s,E,y,I),me.viewport(B.copy(k).multiplyScalar(we).round())},this.getScissor=function(s){return s.copy($)},this.setScissor=function(s,E,y,I){s.isVector4?$.set(s.x,s.y,s.z,s.w):$.set(s,E,y,I),me.scissor(V.copy($).multiplyScalar(we).round())},this.getScissorTest=function(){return fe},this.setScissorTest=function(s){me.setScissorTest(fe=s)},this.setOpaqueSort=function(s){nt=s},this.setTransparentSort=function(s){je=s},this.getClearColor=function(s){return s.copy(ne.getClearColor())},this.setClearColor=function(){ne.setClearColor(...arguments)},this.getClearAlpha=function(){return ne.getClearAlpha()},this.setClearAlpha=function(){ne.setClearAlpha(...arguments)},this.clear=function(s=!0,E=!0,y=!0){let I=0;if(s){let D=!1;if(G!==null){const ae=G.texture.format;D=f.has(ae)}if(D){const ae=G.texture.type,ce=o.has(ae),oe=ne.getClearColor(),de=ne.getClearAlpha(),Se=oe.r,Ae=oe.g,Me=oe.b;ce?(P[0]=Se,P[1]=Ae,P[2]=Me,P[3]=de,m.clearBufferuiv(m.COLOR,0,P)):(M[0]=Se,M[1]=Ae,M[2]=Me,M[3]=de,m.clearBufferiv(m.COLOR,0,M))}else I|=m.COLOR_BUFFER_BIT}E&&(I|=m.DEPTH_BUFFER_BIT),y&&(I|=m.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),m.clear(I)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",be,!1),t.removeEventListener("webglcontextrestored",Ke,!1),t.removeEventListener("webglcontextcreationerror",Ve,!1),ne.dispose(),Q.dispose(),ie.dispose(),a.dispose(),H.dispose(),Y.dispose(),te.dispose(),le.dispose(),Z.dispose(),he.dispose(),ee.dispose(),ee.removeEventListener("sessionstart",ii),ee.removeEventListener("sessionend",ai),yt.stop()};function be(s){s.preventDefault(),fi("WebGLRenderer: Context Lost."),p=!0}function Ke(){fi("WebGLRenderer: Context Restored."),p=!1;const s=u.autoReset,E=_e.enabled,y=_e.autoUpdate,I=_e.needsUpdate,D=_e.type;X(),u.autoReset=s,_e.enabled=E,_e.autoUpdate=y,_e.needsUpdate=I,_e.type=D}function Ve(s){Qe("WebGLRenderer: A WebGL context could not be created. Reason: ",s.statusMessage)}function Et(s){const E=s.target;E.removeEventListener("dispose",Et),Rt(E)}function Rt(s){$a(s),a.remove(s)}function $a(s){const E=a.get(s).programs;E!==void 0&&(E.forEach(function(y){he.releaseProgram(y)}),s.isShaderMaterial&&he.releaseShaderCache(s))}this.renderBufferDirect=function(s,E,y,I,D,ae){E===null&&(E=ze);const ce=D.isMesh&&D.matrixWorld.determinant()<0,oe=Qa(s,E,y,I,D);me.setMaterial(I,ce);let de=y.index,Se=1;if(I.wireframe===!0){if(de=ve.getWireframeAttribute(y),de===void 0)return;Se=2}const Ae=y.drawRange,Me=y.attributes.position;let Ue=Ae.start*Se,ke=(Ae.start+Ae.count)*Se;ae!==null&&(Ue=Math.max(Ue,ae.start*Se),ke=Math.min(ke,(ae.start+ae.count)*Se)),de!==null?(Ue=Math.max(Ue,0),ke=Math.min(ke,de.count)):Me!=null&&(Ue=Math.max(Ue,0),ke=Math.min(ke,Me.count));const et=ke-Ue;if(et<0||et===1/0)return;le.setup(D,I,oe,y,de);let tt,Xe=_;if(de!==null&&(tt=F.get(de),Xe=se,Xe.setIndex(tt)),D.isMesh)I.wireframe===!0?(me.setLineWidth(I.wireframeLinewidth*at()),Xe.setMode(m.LINES)):Xe.setMode(m.TRIANGLES);else if(D.isLine){let Te=I.linewidth;Te===void 0&&(Te=1),me.setLineWidth(Te*at()),D.isLineSegments?Xe.setMode(m.LINES):D.isLineLoop?Xe.setMode(m.LINE_LOOP):Xe.setMode(m.LINE_STRIP)}else D.isPoints?Xe.setMode(m.POINTS):D.isSprite&&Xe.setMode(m.TRIANGLES);if(D.isBatchedMesh)if(D._multiDrawInstances!==null)Vn("WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),Xe.renderMultiDrawInstances(D._multiDrawStarts,D._multiDrawCounts,D._multiDrawCount,D._multiDrawInstances);else if(Ge.get("WEBGL_multi_draw"))Xe.renderMultiDraw(D._multiDrawStarts,D._multiDrawCounts,D._multiDrawCount);else{const Te=D._multiDrawStarts,We=D._multiDrawCounts,ye=D._multiDrawCount,mt=de?F.get(de).bytesPerElement:1,Wt=a.get(I).currentProgram.getUniforms();for(let _t=0;_t<ye;_t++)Wt.setValue(m,"_gl_DrawID",_t),Xe.render(Te[_t]/mt,We[_t])}else if(D.isInstancedMesh)Xe.renderInstances(Ue,et,D.count);else if(y.isInstancedBufferGeometry){const Te=y._maxInstanceCount!==void 0?y._maxInstanceCount:1/0,We=Math.min(y.instanceCount,Te);Xe.renderInstances(Ue,et,We)}else Xe.render(Ue,et)};function ni(s,E,y){s.transparent===!0&&s.side===bt&&s.forceSinglePass===!1?(s.side=St,s.needsUpdate=!0,cn(s,E,y),s.side=an,s.needsUpdate=!0,cn(s,E,y),s.side=bt):cn(s,E,y)}this.compile=function(s,E,y=null){y===null&&(y=s),C=ie.get(y),C.init(E),N.push(C),y.traverseVisible(function(D){D.isLight&&D.layers.test(E.layers)&&(C.pushLight(D),D.castShadow&&C.pushShadow(D))}),s!==y&&s.traverseVisible(function(D){D.isLight&&D.layers.test(E.layers)&&(C.pushLight(D),D.castShadow&&C.pushShadow(D))}),C.setupLights();const I=new Set;return s.traverse(function(D){if(!(D.isMesh||D.isPoints||D.isLine||D.isSprite))return;const ae=D.material;if(ae)if(Array.isArray(ae))for(let ce=0;ce<ae.length;ce++){const oe=ae[ce];ni(oe,y,D),I.add(oe)}else ni(ae,y,D),I.add(ae)}),C=N.pop(),I},this.compileAsync=function(s,E,y=null){const I=this.compile(s,E,y);return new Promise(D=>{function ae(){if(I.forEach(function(ce){a.get(ce).currentProgram.isReady()&&I.delete(ce)}),I.size===0){D(s);return}setTimeout(ae,10)}Ge.get("KHR_parallel_shader_compile")!==null?ae():setTimeout(ae,10)})};let bn=null;function Za(s){bn&&bn(s)}function ii(){yt.stop()}function ai(){yt.start()}const yt=new za;yt.setAnimationLoop(Za),typeof self<"u"&&yt.setContext(self),this.setAnimationLoop=function(s){bn=s,ee.setAnimationLoop(s),s===null?yt.stop():yt.start()},ee.addEventListener("sessionstart",ii),ee.addEventListener("sessionend",ai),this.render=function(s,E){if(E!==void 0&&E.isCamera!==!0){Qe("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(p===!0)return;const y=ee.enabled===!0&&ee.isPresenting===!0,I=q!==null&&(G===null||y)&&q.begin(c,G);if(s.matrixWorldAutoUpdate===!0&&s.updateMatrixWorld(),E.parent===null&&E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),ee.enabled===!0&&ee.isPresenting===!0&&(q===null||q.isCompositing()===!1)&&(ee.cameraAutoUpdate===!0&&ee.updateCamera(E),E=ee.getCamera()),s.isScene===!0&&s.onBeforeRender(c,s,E,G),C=ie.get(s,N.length),C.init(E),N.push(C),lt.multiplyMatrices(E.projectionMatrix,E.matrixWorldInverse),Ce.setFromProjectionMatrix(lt,di,E.reversedDepth),Ne=this.localClippingEnabled,pe=ue.init(this.clippingPlanes,Ne),A=Q.get(s,T.length),A.init(),T.push(A),ee.enabled===!0&&ee.isPresenting===!0){const ce=c.xr.getDepthSensingMesh();ce!==null&&Cn(ce,E,-1/0,c.sortObjects)}Cn(s,E,0,c.sortObjects),A.finish(),c.sortObjects===!0&&A.sort(nt,je),Le=ee.enabled===!1||ee.isPresenting===!1||ee.hasDepthSensing()===!1,Le&&ne.addToRenderList(A,s),this.info.render.frame++,pe===!0&&ue.beginShadows();const D=C.state.shadowsArray;if(_e.render(D,s,E),pe===!0&&ue.endShadows(),this.info.autoReset===!0&&this.info.reset(),(I&&q.hasRenderPass())===!1){const ce=A.opaque,oe=A.transmissive;if(C.setupLights(),E.isArrayCamera){const de=E.cameras;if(oe.length>0)for(let Se=0,Ae=de.length;Se<Ae;Se++){const Me=de[Se];oi(ce,oe,s,Me)}Le&&ne.render(s);for(let Se=0,Ae=de.length;Se<Ae;Se++){const Me=de[Se];ri(A,s,Me,Me.viewport)}}else oe.length>0&&oi(ce,oe,s,E),Le&&ne.render(s),ri(A,s,E)}G!==null&&W===0&&(v.updateMultisampleRenderTarget(G),v.updateRenderTargetMipmap(G)),I&&q.end(c),s.isScene===!0&&s.onAfterRender(c,s,E),le.resetDefaultState(),z=-1,K=null,N.pop(),N.length>0?(C=N[N.length-1],pe===!0&&ue.setGlobalState(c.clippingPlanes,C.state.camera)):C=null,T.pop(),T.length>0?A=T[T.length-1]:A=null};function Cn(s,E,y,I){if(s.visible===!1)return;if(s.layers.test(E.layers)){if(s.isGroup)y=s.renderOrder;else if(s.isLOD)s.autoUpdate===!0&&s.update(E);else if(s.isLight)C.pushLight(s),s.castShadow&&C.pushShadow(s);else if(s.isSprite){if(!s.frustumCulled||Ce.intersectsSprite(s)){I&&He.setFromMatrixPosition(s.matrixWorld).applyMatrix4(lt);const ce=te.update(s),oe=s.material;oe.visible&&A.push(s,ce,oe,y,He.z,null)}}else if((s.isMesh||s.isLine||s.isPoints)&&(!s.frustumCulled||Ce.intersectsObject(s))){const ce=te.update(s),oe=s.material;if(I&&(s.boundingSphere!==void 0?(s.boundingSphere===null&&s.computeBoundingSphere(),He.copy(s.boundingSphere.center)):(ce.boundingSphere===null&&ce.computeBoundingSphere(),He.copy(ce.boundingSphere.center)),He.applyMatrix4(s.matrixWorld).applyMatrix4(lt)),Array.isArray(oe)){const de=ce.groups;for(let Se=0,Ae=de.length;Se<Ae;Se++){const Me=de[Se],Ue=oe[Me.materialIndex];Ue&&Ue.visible&&A.push(s,ce,Ue,y,He.z,Me)}}else oe.visible&&A.push(s,ce,oe,y,He.z,null)}}const ae=s.children;for(let ce=0,oe=ae.length;ce<oe;ce++)Cn(ae[ce],E,y,I)}function ri(s,E,y,I){const{opaque:D,transmissive:ae,transparent:ce}=s;C.setupLightsView(y),pe===!0&&ue.setGlobalState(c.clippingPlanes,y),I&&me.viewport(B.copy(I)),D.length>0&&ln(D,E,y),ae.length>0&&ln(ae,E,y),ce.length>0&&ln(ce,E,y),me.buffers.depth.setTest(!0),me.buffers.depth.setMask(!0),me.buffers.color.setMask(!0),me.setPolygonOffset(!1)}function oi(s,E,y,I){if((y.isScene===!0?y.overrideMaterial:null)!==null)return;if(C.state.transmissionRenderTarget[I.id]===void 0){const Ue=Ge.has("EXT_color_buffer_half_float")||Ge.has("EXT_color_buffer_float");C.state.transmissionRenderTarget[I.id]=new Pt(1,1,{generateMipmaps:!0,type:Ue?wt:Tt,minFilter:en,samples:qe.samples,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:it.workingColorSpace})}const ae=C.state.transmissionRenderTarget[I.id],ce=I.viewport||B;ae.setSize(ce.z*c.transmissionResolutionScale,ce.w*c.transmissionResolutionScale);const oe=c.getRenderTarget(),de=c.getActiveCubeFace(),Se=c.getActiveMipmapLevel();c.setRenderTarget(ae),c.getClearColor(xe),ge=c.getClearAlpha(),ge<1&&c.setClearColor(16777215,.5),c.clear(),Le&&ne.render(y);const Ae=c.toneMapping;c.toneMapping=At;const Me=I.viewport;if(I.viewport!==void 0&&(I.viewport=void 0),C.setupLightsView(I),pe===!0&&ue.setGlobalState(c.clippingPlanes,I),ln(s,y,I),v.updateMultisampleRenderTarget(ae),v.updateRenderTargetMipmap(ae),Ge.has("WEBGL_multisampled_render_to_texture")===!1){let Ue=!1;for(let ke=0,et=E.length;ke<et;ke++){const tt=E[ke],{object:Xe,geometry:Te,material:We,group:ye}=tt;if(We.side===bt&&Xe.layers.test(I.layers)){const mt=We.side;We.side=St,We.needsUpdate=!0,si(Xe,y,I,Te,We,ye),We.side=mt,We.needsUpdate=!0,Ue=!0}}Ue===!0&&(v.updateMultisampleRenderTarget(ae),v.updateRenderTargetMipmap(ae))}c.setRenderTarget(oe,de,Se),c.setClearColor(xe,ge),Me!==void 0&&(I.viewport=Me),c.toneMapping=Ae}function ln(s,E,y){const I=E.isScene===!0?E.overrideMaterial:null;for(let D=0,ae=s.length;D<ae;D++){const ce=s[D],{object:oe,geometry:de,group:Se}=ce;let Ae=ce.material;Ae.allowOverride===!0&&I!==null&&(Ae=I),oe.layers.test(y.layers)&&si(oe,E,y,de,Ae,Se)}}function si(s,E,y,I,D,ae){s.onBeforeRender(c,E,y,I,D,ae),s.modelViewMatrix.multiplyMatrices(y.matrixWorldInverse,s.matrixWorld),s.normalMatrix.getNormalMatrix(s.modelViewMatrix),D.onBeforeRender(c,E,y,I,s,ae),D.transparent===!0&&D.side===bt&&D.forceSinglePass===!1?(D.side=St,D.needsUpdate=!0,c.renderBufferDirect(y,E,I,D,s,ae),D.side=an,D.needsUpdate=!0,c.renderBufferDirect(y,E,I,D,s,ae),D.side=bt):c.renderBufferDirect(y,E,I,D,s,ae),s.onAfterRender(c,E,y,I,D,ae)}function cn(s,E,y){E.isScene!==!0&&(E=ze);const I=a.get(s),D=C.state.lights,ae=C.state.shadowsArray,ce=D.state.version,oe=he.getParameters(s,D.state,ae,E,y),de=he.getProgramCacheKey(oe);let Se=I.programs;I.environment=s.isMeshStandardMaterial?E.environment:null,I.fog=E.fog,I.envMap=(s.isMeshStandardMaterial?Y:H).get(s.envMap||I.environment),I.envMapRotation=I.environment!==null&&s.envMap===null?E.environmentRotation:s.envMapRotation,Se===void 0&&(s.addEventListener("dispose",Et),Se=new Map,I.programs=Se);let Ae=Se.get(de);if(Ae!==void 0){if(I.currentProgram===Ae&&I.lightsStateVersion===ce)return ci(s,oe),Ae}else oe.uniforms=he.getUniforms(s),s.onBeforeCompile(oe,c),Ae=he.acquireProgram(oe,de),Se.set(de,Ae),I.uniforms=oe.uniforms;const Me=I.uniforms;return(!s.isShaderMaterial&&!s.isRawShaderMaterial||s.clipping===!0)&&(Me.clippingPlanes=ue.uniform),ci(s,oe),I.needsLights=ja(s),I.lightsStateVersion=ce,I.needsLights&&(Me.ambientLightColor.value=D.state.ambient,Me.lightProbe.value=D.state.probe,Me.directionalLights.value=D.state.directional,Me.directionalLightShadows.value=D.state.directionalShadow,Me.spotLights.value=D.state.spot,Me.spotLightShadows.value=D.state.spotShadow,Me.rectAreaLights.value=D.state.rectArea,Me.ltc_1.value=D.state.rectAreaLTC1,Me.ltc_2.value=D.state.rectAreaLTC2,Me.pointLights.value=D.state.point,Me.pointLightShadows.value=D.state.pointShadow,Me.hemisphereLights.value=D.state.hemi,Me.directionalShadowMap.value=D.state.directionalShadowMap,Me.directionalShadowMatrix.value=D.state.directionalShadowMatrix,Me.spotShadowMap.value=D.state.spotShadowMap,Me.spotLightMatrix.value=D.state.spotLightMatrix,Me.spotLightMap.value=D.state.spotLightMap,Me.pointShadowMap.value=D.state.pointShadowMap,Me.pointShadowMatrix.value=D.state.pointShadowMatrix),I.currentProgram=Ae,I.uniformsList=null,Ae}function li(s){if(s.uniformsList===null){const E=s.currentProgram.getUniforms();s.uniformsList=gn.seqWithValue(E.seq,s.uniforms)}return s.uniformsList}function ci(s,E){const y=a.get(s);y.outputColorSpace=E.outputColorSpace,y.batching=E.batching,y.batchingColor=E.batchingColor,y.instancing=E.instancing,y.instancingColor=E.instancingColor,y.instancingMorph=E.instancingMorph,y.skinning=E.skinning,y.morphTargets=E.morphTargets,y.morphNormals=E.morphNormals,y.morphColors=E.morphColors,y.morphTargetsCount=E.morphTargetsCount,y.numClippingPlanes=E.numClippingPlanes,y.numIntersection=E.numClipIntersection,y.vertexAlphas=E.vertexAlphas,y.vertexTangents=E.vertexTangents,y.toneMapping=E.toneMapping}function Qa(s,E,y,I,D){E.isScene!==!0&&(E=ze),v.resetTextureUnits();const ae=E.fog,ce=I.isMeshStandardMaterial?E.environment:null,oe=G===null?c.outputColorSpace:G.isXRRenderTarget===!0?G.texture.colorSpace:xn,de=(I.isMeshStandardMaterial?Y:H).get(I.envMap||ce),Se=I.vertexColors===!0&&!!y.attributes.color&&y.attributes.color.itemSize===4,Ae=!!y.attributes.tangent&&(!!I.normalMap||I.anisotropy>0),Me=!!y.morphAttributes.position,Ue=!!y.morphAttributes.normal,ke=!!y.morphAttributes.color;let et=At;I.toneMapped&&(G===null||G.isXRRenderTarget===!0)&&(et=c.toneMapping);const tt=y.morphAttributes.position||y.morphAttributes.normal||y.morphAttributes.color,Xe=tt!==void 0?tt.length:0,Te=a.get(I),We=C.state.lights;if(pe===!0&&(Ne===!0||s!==K)){const ct=s===K&&I.id===z;ue.setState(I,s,ct)}let ye=!1;I.version===Te.__version?(Te.needsLights&&Te.lightsStateVersion!==We.state.version||Te.outputColorSpace!==oe||D.isBatchedMesh&&Te.batching===!1||!D.isBatchedMesh&&Te.batching===!0||D.isBatchedMesh&&Te.batchingColor===!0&&D.colorTexture===null||D.isBatchedMesh&&Te.batchingColor===!1&&D.colorTexture!==null||D.isInstancedMesh&&Te.instancing===!1||!D.isInstancedMesh&&Te.instancing===!0||D.isSkinnedMesh&&Te.skinning===!1||!D.isSkinnedMesh&&Te.skinning===!0||D.isInstancedMesh&&Te.instancingColor===!0&&D.instanceColor===null||D.isInstancedMesh&&Te.instancingColor===!1&&D.instanceColor!==null||D.isInstancedMesh&&Te.instancingMorph===!0&&D.morphTexture===null||D.isInstancedMesh&&Te.instancingMorph===!1&&D.morphTexture!==null||Te.envMap!==de||I.fog===!0&&Te.fog!==ae||Te.numClippingPlanes!==void 0&&(Te.numClippingPlanes!==ue.numPlanes||Te.numIntersection!==ue.numIntersection)||Te.vertexAlphas!==Se||Te.vertexTangents!==Ae||Te.morphTargets!==Me||Te.morphNormals!==Ue||Te.morphColors!==ke||Te.toneMapping!==et||Te.morphTargetsCount!==Xe)&&(ye=!0):(ye=!0,Te.__version=I.version);let mt=Te.currentProgram;ye===!0&&(mt=cn(I,E,D));let Wt=!1,_t=!1,Zt=!1;const $e=mt.getUniforms(),ft=Te.uniforms;if(me.useProgram(mt.program)&&(Wt=!0,_t=!0,Zt=!0),I.id!==z&&(z=I.id,_t=!0),Wt||K!==s){me.buffers.depth.getReversed()&&s.reversedDepth!==!0&&(s._reversedDepth=!0,s.updateProjectionMatrix()),$e.setValue(m,"projectionMatrix",s.projectionMatrix),$e.setValue(m,"viewMatrix",s.matrixWorldInverse);const dt=$e.map.cameraPosition;dt!==void 0&&dt.setValue(m,Ie.setFromMatrixPosition(s.matrixWorld)),qe.logarithmicDepthBuffer&&$e.setValue(m,"logDepthBufFC",2/(Math.log(s.far+1)/Math.LN2)),(I.isMeshPhongMaterial||I.isMeshToonMaterial||I.isMeshLambertMaterial||I.isMeshBasicMaterial||I.isMeshStandardMaterial||I.isShaderMaterial)&&$e.setValue(m,"isOrthographic",s.isOrthographicCamera===!0),K!==s&&(K=s,_t=!0,Zt=!0)}if(Te.needsLights&&(We.state.directionalShadowMap.length>0&&$e.setValue(m,"directionalShadowMap",We.state.directionalShadowMap,v),We.state.spotShadowMap.length>0&&$e.setValue(m,"spotShadowMap",We.state.spotShadowMap,v),We.state.pointShadowMap.length>0&&$e.setValue(m,"pointShadowMap",We.state.pointShadowMap,v)),D.isSkinnedMesh){$e.setOptional(m,D,"bindMatrix"),$e.setOptional(m,D,"bindMatrixInverse");const ct=D.skeleton;ct&&(ct.boneTexture===null&&ct.computeBoneTexture(),$e.setValue(m,"boneTexture",ct.boneTexture,v))}D.isBatchedMesh&&($e.setOptional(m,D,"batchingTexture"),$e.setValue(m,"batchingTexture",D._matricesTexture,v),$e.setOptional(m,D,"batchingIdTexture"),$e.setValue(m,"batchingIdTexture",D._indirectTexture,v),$e.setOptional(m,D,"batchingColorTexture"),D._colorsTexture!==null&&$e.setValue(m,"batchingColorTexture",D._colorsTexture,v));const gt=y.morphAttributes;if((gt.position!==void 0||gt.normal!==void 0||gt.color!==void 0)&&De.update(D,y,mt),(_t||Te.receiveShadow!==D.receiveShadow)&&(Te.receiveShadow=D.receiveShadow,$e.setValue(m,"receiveShadow",D.receiveShadow)),I.isMeshGouraudMaterial&&I.envMap!==null&&(ft.envMap.value=de,ft.flipEnvMap.value=de.isCubeTexture&&de.isRenderTargetTexture===!1?-1:1),I.isMeshStandardMaterial&&I.envMap===null&&E.environment!==null&&(ft.envMapIntensity.value=E.environmentIntensity),ft.dfgLUT!==void 0&&(ft.dfgLUT.value=dd()),_t&&($e.setValue(m,"toneMappingExposure",c.toneMappingExposure),Te.needsLights&&Ja(ft,Zt),ae&&I.fog===!0&&Re.refreshFogUniforms(ft,ae),Re.refreshMaterialUniforms(ft,I,we,Oe,C.state.transmissionRenderTarget[s.id]),gn.upload(m,li(Te),ft,v)),I.isShaderMaterial&&I.uniformsNeedUpdate===!0&&(gn.upload(m,li(Te),ft,v),I.uniformsNeedUpdate=!1),I.isSpriteMaterial&&$e.setValue(m,"center",D.center),$e.setValue(m,"modelViewMatrix",D.modelViewMatrix),$e.setValue(m,"normalMatrix",D.normalMatrix),$e.setValue(m,"modelMatrix",D.matrixWorld),I.isShaderMaterial||I.isRawShaderMaterial){const ct=I.uniformsGroups;for(let dt=0,Pn=ct.length;dt<Pn;dt++){const Ft=ct[dt];Z.update(Ft,mt),Z.bind(Ft,mt)}}return mt}function Ja(s,E){s.ambientLightColor.needsUpdate=E,s.lightProbe.needsUpdate=E,s.directionalLights.needsUpdate=E,s.directionalLightShadows.needsUpdate=E,s.pointLights.needsUpdate=E,s.pointLightShadows.needsUpdate=E,s.spotLights.needsUpdate=E,s.spotLightShadows.needsUpdate=E,s.rectAreaLights.needsUpdate=E,s.hemisphereLights.needsUpdate=E}function ja(s){return s.isMeshLambertMaterial||s.isMeshToonMaterial||s.isMeshPhongMaterial||s.isMeshStandardMaterial||s.isShadowMaterial||s.isShaderMaterial&&s.lights===!0}this.getActiveCubeFace=function(){return L},this.getActiveMipmapLevel=function(){return W},this.getRenderTarget=function(){return G},this.setRenderTargetTextures=function(s,E,y){const I=a.get(s);I.__autoAllocateDepthBuffer=s.resolveDepthBuffer===!1,I.__autoAllocateDepthBuffer===!1&&(I.__useRenderToTexture=!1),a.get(s.texture).__webglTexture=E,a.get(s.depthTexture).__webglTexture=I.__autoAllocateDepthBuffer?void 0:y,I.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(s,E){const y=a.get(s);y.__webglFramebuffer=E,y.__useDefaultFramebuffer=E===void 0};const er=m.createFramebuffer();this.setRenderTarget=function(s,E=0,y=0){G=s,L=E,W=y;let I=null,D=!1,ae=!1;if(s){const oe=a.get(s);if(oe.__useDefaultFramebuffer!==void 0){me.bindFramebuffer(m.FRAMEBUFFER,oe.__webglFramebuffer),B.copy(s.viewport),V.copy(s.scissor),J=s.scissorTest,me.viewport(B),me.scissor(V),me.setScissorTest(J),z=-1;return}else if(oe.__webglFramebuffer===void 0)v.setupRenderTarget(s);else if(oe.__hasExternalTextures)v.rebindTextures(s,a.get(s.texture).__webglTexture,a.get(s.depthTexture).__webglTexture);else if(s.depthBuffer){const Ae=s.depthTexture;if(oe.__boundDepthTexture!==Ae){if(Ae!==null&&a.has(Ae)&&(s.width!==Ae.image.width||s.height!==Ae.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");v.setupDepthRenderbuffer(s)}}const de=s.texture;(de.isData3DTexture||de.isDataArrayTexture||de.isCompressedArrayTexture)&&(ae=!0);const Se=a.get(s).__webglFramebuffer;s.isWebGLCubeRenderTarget?(Array.isArray(Se[E])?I=Se[E][y]:I=Se[E],D=!0):s.samples>0&&v.useMultisampledRTT(s)===!1?I=a.get(s).__webglMultisampledFramebuffer:Array.isArray(Se)?I=Se[y]:I=Se,B.copy(s.viewport),V.copy(s.scissor),J=s.scissorTest}else B.copy(k).multiplyScalar(we).floor(),V.copy($).multiplyScalar(we).floor(),J=fe;if(y!==0&&(I=er),me.bindFramebuffer(m.FRAMEBUFFER,I)&&me.drawBuffers(s,I),me.viewport(B),me.scissor(V),me.setScissorTest(J),D){const oe=a.get(s.texture);m.framebufferTexture2D(m.FRAMEBUFFER,m.COLOR_ATTACHMENT0,m.TEXTURE_CUBE_MAP_POSITIVE_X+E,oe.__webglTexture,y)}else if(ae){const oe=E;for(let de=0;de<s.textures.length;de++){const Se=a.get(s.textures[de]);m.framebufferTextureLayer(m.FRAMEBUFFER,m.COLOR_ATTACHMENT0+de,Se.__webglTexture,y,oe)}}else if(s!==null&&y!==0){const oe=a.get(s.texture);m.framebufferTexture2D(m.FRAMEBUFFER,m.COLOR_ATTACHMENT0,m.TEXTURE_2D,oe.__webglTexture,y)}z=-1},this.readRenderTargetPixels=function(s,E,y,I,D,ae,ce,oe=0){if(!(s&&s.isWebGLRenderTarget)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let de=a.get(s).__webglFramebuffer;if(s.isWebGLCubeRenderTarget&&ce!==void 0&&(de=de[ce]),de){me.bindFramebuffer(m.FRAMEBUFFER,de);try{const Se=s.textures[oe],Ae=Se.format,Me=Se.type;if(!qe.textureFormatReadable(Ae)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!qe.textureTypeReadable(Me)){Qe("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}E>=0&&E<=s.width-I&&y>=0&&y<=s.height-D&&(s.textures.length>1&&m.readBuffer(m.COLOR_ATTACHMENT0+oe),m.readPixels(E,y,I,D,j.convert(Ae),j.convert(Me),ae))}finally{const Se=G!==null?a.get(G).__webglFramebuffer:null;me.bindFramebuffer(m.FRAMEBUFFER,Se)}}},this.readRenderTargetPixelsAsync=async function(s,E,y,I,D,ae,ce,oe=0){if(!(s&&s.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let de=a.get(s).__webglFramebuffer;if(s.isWebGLCubeRenderTarget&&ce!==void 0&&(de=de[ce]),de)if(E>=0&&E<=s.width-I&&y>=0&&y<=s.height-D){me.bindFramebuffer(m.FRAMEBUFFER,de);const Se=s.textures[oe],Ae=Se.format,Me=Se.type;if(!qe.textureFormatReadable(Ae))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!qe.textureTypeReadable(Me))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const Ue=m.createBuffer();m.bindBuffer(m.PIXEL_PACK_BUFFER,Ue),m.bufferData(m.PIXEL_PACK_BUFFER,ae.byteLength,m.STREAM_READ),s.textures.length>1&&m.readBuffer(m.COLOR_ATTACHMENT0+oe),m.readPixels(E,y,I,D,j.convert(Ae),j.convert(Me),0);const ke=G!==null?a.get(G).__webglFramebuffer:null;me.bindFramebuffer(m.FRAMEBUFFER,ke);const et=m.fenceSync(m.SYNC_GPU_COMMANDS_COMPLETE,0);return m.flush(),await or(m,et,4),m.bindBuffer(m.PIXEL_PACK_BUFFER,Ue),m.getBufferSubData(m.PIXEL_PACK_BUFFER,0,ae),m.deleteBuffer(Ue),m.deleteSync(et),ae}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(s,E=null,y=0){const I=Math.pow(2,-y),D=Math.floor(s.image.width*I),ae=Math.floor(s.image.height*I),ce=E!==null?E.x:0,oe=E!==null?E.y:0;v.setTexture2D(s,0),m.copyTexSubImage2D(m.TEXTURE_2D,y,0,0,ce,oe,D,ae),me.unbindTexture()};const tr=m.createFramebuffer(),nr=m.createFramebuffer();this.copyTextureToTexture=function(s,E,y=null,I=null,D=0,ae=null){ae===null&&(D!==0?(Vn("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),ae=D,D=0):ae=0);let ce,oe,de,Se,Ae,Me,Ue,ke,et;const tt=s.isCompressedTexture?s.mipmaps[ae]:s.image;if(y!==null)ce=y.max.x-y.min.x,oe=y.max.y-y.min.y,de=y.isBox3?y.max.z-y.min.z:1,Se=y.min.x,Ae=y.min.y,Me=y.isBox3?y.min.z:0;else{const gt=Math.pow(2,-D);ce=Math.floor(tt.width*gt),oe=Math.floor(tt.height*gt),s.isDataArrayTexture?de=tt.depth:s.isData3DTexture?de=Math.floor(tt.depth*gt):de=1,Se=0,Ae=0,Me=0}I!==null?(Ue=I.x,ke=I.y,et=I.z):(Ue=0,ke=0,et=0);const Xe=j.convert(E.format),Te=j.convert(E.type);let We;E.isData3DTexture?(v.setTexture3D(E,0),We=m.TEXTURE_3D):E.isDataArrayTexture||E.isCompressedArrayTexture?(v.setTexture2DArray(E,0),We=m.TEXTURE_2D_ARRAY):(v.setTexture2D(E,0),We=m.TEXTURE_2D),m.pixelStorei(m.UNPACK_FLIP_Y_WEBGL,E.flipY),m.pixelStorei(m.UNPACK_PREMULTIPLY_ALPHA_WEBGL,E.premultiplyAlpha),m.pixelStorei(m.UNPACK_ALIGNMENT,E.unpackAlignment);const ye=m.getParameter(m.UNPACK_ROW_LENGTH),mt=m.getParameter(m.UNPACK_IMAGE_HEIGHT),Wt=m.getParameter(m.UNPACK_SKIP_PIXELS),_t=m.getParameter(m.UNPACK_SKIP_ROWS),Zt=m.getParameter(m.UNPACK_SKIP_IMAGES);m.pixelStorei(m.UNPACK_ROW_LENGTH,tt.width),m.pixelStorei(m.UNPACK_IMAGE_HEIGHT,tt.height),m.pixelStorei(m.UNPACK_SKIP_PIXELS,Se),m.pixelStorei(m.UNPACK_SKIP_ROWS,Ae),m.pixelStorei(m.UNPACK_SKIP_IMAGES,Me);const $e=s.isDataArrayTexture||s.isData3DTexture,ft=E.isDataArrayTexture||E.isData3DTexture;if(s.isDepthTexture){const gt=a.get(s),ct=a.get(E),dt=a.get(gt.__renderTarget),Pn=a.get(ct.__renderTarget);me.bindFramebuffer(m.READ_FRAMEBUFFER,dt.__webglFramebuffer),me.bindFramebuffer(m.DRAW_FRAMEBUFFER,Pn.__webglFramebuffer);for(let Ft=0;Ft<de;Ft++)$e&&(m.framebufferTextureLayer(m.READ_FRAMEBUFFER,m.COLOR_ATTACHMENT0,a.get(s).__webglTexture,D,Me+Ft),m.framebufferTextureLayer(m.DRAW_FRAMEBUFFER,m.COLOR_ATTACHMENT0,a.get(E).__webglTexture,ae,et+Ft)),m.blitFramebuffer(Se,Ae,ce,oe,Ue,ke,ce,oe,m.DEPTH_BUFFER_BIT,m.NEAREST);me.bindFramebuffer(m.READ_FRAMEBUFFER,null),me.bindFramebuffer(m.DRAW_FRAMEBUFFER,null)}else if(D!==0||s.isRenderTargetTexture||a.has(s)){const gt=a.get(s),ct=a.get(E);me.bindFramebuffer(m.READ_FRAMEBUFFER,tr),me.bindFramebuffer(m.DRAW_FRAMEBUFFER,nr);for(let dt=0;dt<de;dt++)$e?m.framebufferTextureLayer(m.READ_FRAMEBUFFER,m.COLOR_ATTACHMENT0,gt.__webglTexture,D,Me+dt):m.framebufferTexture2D(m.READ_FRAMEBUFFER,m.COLOR_ATTACHMENT0,m.TEXTURE_2D,gt.__webglTexture,D),ft?m.framebufferTextureLayer(m.DRAW_FRAMEBUFFER,m.COLOR_ATTACHMENT0,ct.__webglTexture,ae,et+dt):m.framebufferTexture2D(m.DRAW_FRAMEBUFFER,m.COLOR_ATTACHMENT0,m.TEXTURE_2D,ct.__webglTexture,ae),D!==0?m.blitFramebuffer(Se,Ae,ce,oe,Ue,ke,ce,oe,m.COLOR_BUFFER_BIT,m.NEAREST):ft?m.copyTexSubImage3D(We,ae,Ue,ke,et+dt,Se,Ae,ce,oe):m.copyTexSubImage2D(We,ae,Ue,ke,Se,Ae,ce,oe);me.bindFramebuffer(m.READ_FRAMEBUFFER,null),me.bindFramebuffer(m.DRAW_FRAMEBUFFER,null)}else ft?s.isDataTexture||s.isData3DTexture?m.texSubImage3D(We,ae,Ue,ke,et,ce,oe,de,Xe,Te,tt.data):E.isCompressedArrayTexture?m.compressedTexSubImage3D(We,ae,Ue,ke,et,ce,oe,de,Xe,tt.data):m.texSubImage3D(We,ae,Ue,ke,et,ce,oe,de,Xe,Te,tt):s.isDataTexture?m.texSubImage2D(m.TEXTURE_2D,ae,Ue,ke,ce,oe,Xe,Te,tt.data):s.isCompressedTexture?m.compressedTexSubImage2D(m.TEXTURE_2D,ae,Ue,ke,tt.width,tt.height,Xe,tt.data):m.texSubImage2D(m.TEXTURE_2D,ae,Ue,ke,ce,oe,Xe,Te,tt);m.pixelStorei(m.UNPACK_ROW_LENGTH,ye),m.pixelStorei(m.UNPACK_IMAGE_HEIGHT,mt),m.pixelStorei(m.UNPACK_SKIP_PIXELS,Wt),m.pixelStorei(m.UNPACK_SKIP_ROWS,_t),m.pixelStorei(m.UNPACK_SKIP_IMAGES,Zt),ae===0&&E.generateMipmaps&&m.generateMipmap(We),me.unbindTexture()},this.initRenderTarget=function(s){a.get(s).__webglFramebuffer===void 0&&v.setupRenderTarget(s)},this.initTexture=function(s){s.isCubeTexture?v.setTextureCube(s,0):s.isData3DTexture?v.setTexture3D(s,0):s.isDataArrayTexture||s.isCompressedArrayTexture?v.setTexture2DArray(s,0):v.setTexture2D(s,0),me.unbindTexture()},this.resetState=function(){L=0,W=0,G=null,me.reset(),le.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return di}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(n){this._outputColorSpace=n;const t=this.getContext();t.drawingBufferColorSpace=it._getDrawingBufferColorSpace(n),t.unpackColorSpace=it._getUnpackColorSpace()}}export{ea as P,pd as W};

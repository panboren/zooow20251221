import { d as defineEventHandler } from '../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const randomNumber_get = defineEventHandler(() => {
  const randomNum = Math.floor(Math.random() * 37) + 1;
  return {
    success: true,
    data: {
      random: randomNum,
      message: `\u968F\u673A\u751F\u6210\u6570\u5B57: ${randomNum}`
    }
  };
});

export { randomNumber_get as default };
//# sourceMappingURL=random-number.get.mjs.map
